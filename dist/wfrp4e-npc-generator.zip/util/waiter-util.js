var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import DialogUtil from './dialog-util.js';
export default class WaiterUtil {
    static show(title, msg, renderCallback) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.dialogInstance != null) {
                yield this.hide(false);
            }
            this.dialogInstance = new Dialog({
                title: game.i18n.localize(title),
                content: `<form> 
              <div class="form-group">
              ${DialogUtil.getLabelScript(msg)}
              </div>
          </form>
            `,
                buttons: {},
                render: (_html) => {
                    setTimeout(() => __awaiter(this, void 0, void 0, function* () {
                        renderCallback();
                    }));
                },
            });
            this.dialogInstance.render(true);
        });
    }
    static hide(asyncClose = true) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            if (this.dialogInstance != null) {
                asyncClose
                    ? setTimeout(() => __awaiter(this, void 0, void 0, function* () {
                        var _b;
                        yield ((_b = this.dialogInstance) === null || _b === void 0 ? void 0 : _b.close());
                    }))
                    : yield ((_a = this.dialogInstance) === null || _a === void 0 ? void 0 : _a.close());
            }
        });
    }
}
WaiterUtil.dialogInstance = null;
//# sourceMappingURL=waiter-util.js.map
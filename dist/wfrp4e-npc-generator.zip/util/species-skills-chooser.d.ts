export default class SpeciesSkillsChooser {
    static selectSpeciesSkills(initMajors: string[], initMinors: string[], speciesKey: string, subSpeciesKey: string, callback: (major: string[], minor: string[]) => void, undo: () => void): Promise<void>;
}

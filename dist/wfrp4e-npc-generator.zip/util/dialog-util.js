import { GenerateEffectOptionEnum } from './generate-effect-option.enum.js';
export default class DialogUtil {
    static getDialogButtons(id, yesCallback, previousCallback) {
        const buttons = {
            yes: {
                icon: `<i class="fas fa-check" id="yes-icon-${id}"></i>`,
                label: game.i18n.localize('WFRP4NPCGEN.common.button.OK'),
                callback: (html) => {
                    if (yesCallback != null) {
                        yesCallback(html);
                    }
                },
            },
            no: {
                icon: `<i class="fas fa-times" id="no-icon-${id}"></i>`,
                label: game.i18n.localize('WFRP4NPCGEN.common.button.Cancel'),
            },
        };
        if (previousCallback != null) {
            buttons.undo = {
                icon: `<i class="fas fa-undo" id="undo-icon-${id}"></i>`,
                label: game.i18n.localize('WFRP4NPCGEN.common.button.Undo'),
                callback: (html) => {
                    previousCallback(html);
                },
            };
        }
        return buttons;
    }
    static getButtonScript(label, onclick) {
        return `
        <button type="button" onclick="${onclick}">
            ${game.i18n.localize(label)} 
        </button>
        `;
    }
    static getLabelScript(label, style = null) {
        const styleStr = style != null ? ` style="${style}"` : '';
        return `
        <label${styleStr}>
            ${game.i18n.localize(label)}          
        </label> 
        `;
    }
    static getSelectScript(id, options, initValue) {
        const finalInitValue = initValue != null && Object.keys(options).includes(initValue)
            ? initValue
            : '';
        return `
        <select id="${id}" value="${finalInitValue}">
            ${Object.entries(options).map(([key, value]) => {
            const selected = finalInitValue === key ? ' selected="selected"' : '';
            return `<option${selected} id="${id}-${key}" value="${key}">${game.i18n.localize(value)}</option>`;
        })}
        </select>
        `;
    }
    static getInputScript(options) {
        var _a, _b;
        const hasDataList = (options === null || options === void 0 ? void 0 : options.dataListId) != null &&
            (options === null || options === void 0 ? void 0 : options.options) != null &&
            ((_a = options === null || options === void 0 ? void 0 : options.options) === null || _a === void 0 ? void 0 : _a.length) > 0;
        const onInputStr = (options === null || options === void 0 ? void 0 : options.onInput) != null ? ` oninput="${options.onInput}"` : '';
        const onClickStr = (options === null || options === void 0 ? void 0 : options.onClick) != null ? ` onclick="${options.onClick}"` : '';
        const inputListId = hasDataList ? ` list="${options.dataListId}"` : '';
        const initValueStr = (options === null || options === void 0 ? void 0 : options.initValue) != null ? ` value="${options.initValue}"` : '';
        const styleStr = (options === null || options === void 0 ? void 0 : options.style) != null ? ` style="${options.style}"` : '';
        const classesStr = (options === null || options === void 0 ? void 0 : options.classes) != null ? ` class="${options.classes}"` : '';
        const checkedStr = (options === null || options === void 0 ? void 0 : options.checked) ? ' checked' : '';
        const input = `
        <input${onInputStr}${onClickStr}${inputListId}${styleStr}${classesStr}${checkedStr}${initValueStr} type="${options === null || options === void 0 ? void 0 : options.type}" id="${options === null || options === void 0 ? void 0 : options.id}" name="${options === null || options === void 0 ? void 0 : options.name}" />
      `;
        const dataList = hasDataList
            ? `
    <datalist id="${options === null || options === void 0 ? void 0 : options.dataListId}">
    ${(_b = options === null || options === void 0 ? void 0 : options.options) === null || _b === void 0 ? void 0 : _b.map((val) => `<option value="${val}"></option>`).join('')}
    </datalist>
    `
            : '';
        return `
          ${input}
          ${dataList}
          `;
    }
    static getToArrayScript() {
        return `
        function toArray(obj) {
           const array = [];
           for (let i = 0; i < obj.length; i++) { 
              array[i] = obj[i];
           }
           return array;
        }
    `;
    }
    static getNameRandomScript() {
        return `
        function generateName(speciesKey) {
            const nameGen = game.wfrp4e.names;
            return nameGen.generateName({ species: speciesKey });
        }
    `;
    }
    static getEffectSelectScript(dialogId, id, initValue) {
        return this.getSelectScript(`${id}-${dialogId}`, {
            [GenerateEffectOptionEnum.NONE]: `WFRP4NPCGEN.options.effects.${GenerateEffectOptionEnum.NONE}`,
            [GenerateEffectOptionEnum.DEFAULT_DISABLED]: `WFRP4NPCGEN.options.effects.${GenerateEffectOptionEnum.DEFAULT_DISABLED}`,
            [GenerateEffectOptionEnum.DEFAULT_ENABLED]: `WFRP4NPCGEN.options.effects.${GenerateEffectOptionEnum.DEFAULT_ENABLED}`,
        }, initValue);
    }
}
//# sourceMappingURL=dialog-util.js.map
import { ItemData } from '@league-of-foundry-developers/foundry-vtt-types/src/foundry/common/data/data.mjs';
export default class MagicsChooser {
    static selectMagics(initSpells: ItemData[], initPrayers: ItemData[], callback: (spells: ItemData[], prayers: ItemData[]) => void, undo?: () => void): Promise<void>;
    private static getCorrectedLore;
}

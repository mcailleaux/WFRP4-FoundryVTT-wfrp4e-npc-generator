var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import ReferentialUtil from './referential-util.js';
import StringUtil from './string-util.js';
import CompendiumUtil from './compendium-util.js';
export default class TranslateErrorDetect {
    static findActorBySkillIncludes(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const actorsMap = yield CompendiumUtil.getCompendiumActors();
            let result = [];
            for (let [_key, actors] of Object.entries(actorsMap)) {
                for (let actor of actors) {
                    if (StringUtil.arrayIncludesDeburrIgnoreCase(actor.data.skills.map((s) => s.name), name)) {
                        result.push(actor);
                    }
                }
            }
            return result;
        });
    }
    static detectTrappingsTranslateError(callback) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            const careers = yield ReferentialUtil.getCareerEntities(false);
            const trappings = yield ReferentialUtil.getTrappingEntities(false);
            const errors = {
                notFounds: [],
                resolved: [],
            };
            for (let c of careers) {
                const careerData = (_a = c === null || c === void 0 ? void 0 : c.data) === null || _a === void 0 ? void 0 : _a.data;
                const careerGroup = (_b = careerData === null || careerData === void 0 ? void 0 : careerData.careergroup) === null || _b === void 0 ? void 0 : _b.value;
                const cData = (_c = c.data) === null || _c === void 0 ? void 0 : _c.data;
                for (let t of cData === null || cData === void 0 ? void 0 : cData.trappings) {
                    const results = yield ReferentialUtil.findTrappings(t, trappings);
                    if (results.length === 0 ||
                        results.length > 1 ||
                        (results.length === 1 &&
                            !StringUtil.equalsDeburrIgnoreCase(results[0].name.trim(), t))) {
                        if (results.length === 0) {
                            errors.notFounds.push(`[NOT_FOUND] : ${t} from career ${c.name} (${careerGroup})`);
                        }
                        else {
                            errors.resolved.push(`[RESOLVED BY] : ${t} -> ${results
                                .map((t) => t.name)
                                .join(' && ')} from career ${c.name} (${careerGroup})`);
                        }
                    }
                }
            }
            callback(errors);
        });
    }
    static detectRandomCareerTranslateError(callback) {
        return __awaiter(this, void 0, void 0, function* () {
            const randomCareers = game.wfrp4e.tables.career.rows.map((row) => row.name);
            const careers = yield ReferentialUtil.getCareerEntities(false);
            const errors = [];
            randomCareers.forEach((rc) => {
                let cs = careers.filter((c) => {
                    var _a, _b, _c;
                    return StringUtil.includesDeburrIgnoreCase((_c = (_b = (_a = c.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.careergroup) === null || _c === void 0 ? void 0 : _c.value, rc);
                });
                if (cs.length !== 4) {
                    const strictCareer = careers.find((c) => StringUtil.equalsDeburrIgnoreCase(c.name, rc));
                    if (strictCareer != null) {
                        cs = careers.filter((c) => {
                            var _a, _b, _c, _d, _e, _f;
                            return StringUtil.equalsDeburrIgnoreCase((_c = (_b = (_a = c.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.careergroup) === null || _c === void 0 ? void 0 : _c.value, (_f = (_e = (_d = strictCareer.data) === null || _d === void 0 ? void 0 : _d.data) === null || _e === void 0 ? void 0 : _e.careergroup) === null || _f === void 0 ? void 0 : _f.value);
                        });
                    }
                }
                if (cs.length !== 4) {
                    errors.push('Random : ' + rc);
                    errors.push(...cs.map((c) => c.name));
                }
            });
            callback(errors);
        });
    }
    static detectSkillsAndTalentsTranslateError(callback) {
        return __awaiter(this, void 0, void 0, function* () {
            const speciesSkillsMap = ReferentialUtil.getSpeciesSkillsMap();
            const speciesTalentsMap = ReferentialUtil.getSpeciesTalentsMap();
            const randomTalents = ReferentialUtil.getRandomTalents();
            const careers = yield ReferentialUtil.getCareerEntities();
            const skills = [];
            const talents = [];
            const errors = [];
            Object.values(speciesSkillsMap).forEach((s) => {
                skills.push(...s);
            });
            Object.values(speciesTalentsMap).forEach((tl) => {
                tl.filter((_t, i) => i !== tl.length - 1).forEach((t) => {
                    if (t.includes(',')) {
                        talents.push(...t.split(','));
                    }
                    else {
                        talents.push(t);
                    }
                });
            });
            talents.push(...randomTalents);
            careers.forEach((career) => {
                var _a;
                const careerData = (_a = career === null || career === void 0 ? void 0 : career.data) === null || _a === void 0 ? void 0 : _a.data;
                if (careerData.skills != null) {
                    skills.push(...careerData.skills);
                }
                if (careerData.talents != null) {
                    talents.push(...careerData.talents);
                }
            });
            for (let skill of skills) {
                const s = skill;
                try {
                    yield ReferentialUtil.findSkill(s);
                }
                catch (e) {
                    errors.push(s);
                    console.warn('Cant find Skill : ' + s);
                }
            }
            for (let talent of talents) {
                const t = talent;
                try {
                    yield ReferentialUtil.findTalent(t);
                }
                catch (e) {
                    errors.push(t);
                    console.warn('Cant find Talent : ' + t);
                }
            }
            callback(errors);
        });
    }
}
//# sourceMappingURL=translate-error-detect.js.map
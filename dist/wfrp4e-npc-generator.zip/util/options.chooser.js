var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import DialogUtil from './dialog-util.js';
import Options from './options.js';
import { getGenerateEffectOptionEnum } from './generate-effect-option.enum.js';
export default class OptionsChooser {
    static selectOptions(initOptions, callback, undo) {
        return __awaiter(this, void 0, void 0, function* () {
            const dialogId = new Date().getTime();
            new Dialog({
                title: game.i18n.localize('WFRP4NPCGEN.options.select.title'),
                content: `<form>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.options.select.withClassTrappings.label')}
              ${DialogUtil.getInputScript({
                    id: `select-with-class-trappings-${dialogId}`,
                    type: 'checkbox',
                    name: 'select-with-class-trappings',
                    initValue: initOptions != null && initOptions.withClassTrappings,
                    checked: initOptions != null && initOptions.withClassTrappings,
                })}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.options.select.withCareerTrappings.label')}
              ${DialogUtil.getInputScript({
                    id: `select-with-career-trappings-${dialogId}`,
                    type: 'checkbox',
                    name: 'select-with-career-trappings',
                    initValue: initOptions != null && initOptions.withCareerTrappings,
                    checked: initOptions != null && initOptions.withCareerTrappings,
                })}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.trappings.money.label')}
              ${DialogUtil.getEffectSelectScript(dialogId, 'generate-effect-money', initOptions === null || initOptions === void 0 ? void 0 : initOptions.generateMoneyEffect)}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.trappings.weapon.label')}
              ${DialogUtil.getEffectSelectScript(dialogId, 'generate-effect-weapon', initOptions === null || initOptions === void 0 ? void 0 : initOptions.generateWeaponEffect)}
              </div>
              </form>            
            `,
                buttons: DialogUtil.getDialogButtons(dialogId, (html) => {
                    const options = new Options();
                    html
                        .find(`#select-with-class-trappings-${dialogId}`)
                        .each((_i, r) => {
                        options.withClassTrappings = r.checked;
                    });
                    html
                        .find(`#select-with-career-trappings-${dialogId}`)
                        .each((_i, r) => {
                        options.withCareerTrappings = r.checked;
                    });
                    html
                        .find(`#generate-effect-money-${dialogId}`)
                        .each((_i, r) => {
                        options.generateMoneyEffect = getGenerateEffectOptionEnum(r.value);
                    });
                    html
                        .find(`#generate-effect-weapon-${dialogId}`)
                        .each((_i, r) => {
                        options.generateWeaponEffect = getGenerateEffectOptionEnum(r.value);
                    });
                    callback(options);
                }, undo),
                default: 'yes',
            }).render(true);
        });
    }
}
//# sourceMappingURL=options.chooser.js.map
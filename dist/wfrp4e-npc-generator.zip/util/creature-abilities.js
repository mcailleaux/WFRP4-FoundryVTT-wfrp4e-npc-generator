export default class CreatureAbilities {
    constructor() {
        this.includeBasicSkills = false;
        this.sizeKey = 'avg';
        this.isSwarm = false;
        this.hasWeaponTrait = false;
        this.hasRangedTrait = false;
        this.hasArmourTrait = false;
        this.speciesKey = 'none';
        this.traits = [];
        this.talents = [];
        this.skills = [];
        this.excludedTraits = [];
    }
}
//# sourceMappingURL=creature-abilities.js.map
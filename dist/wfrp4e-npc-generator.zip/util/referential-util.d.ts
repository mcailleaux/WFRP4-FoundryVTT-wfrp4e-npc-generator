import { ItemData } from '@league-of-foundry-developers/foundry-vtt-types/src/foundry/common/data/data.mjs';
export default class ReferentialUtil {
    static readonly sortedSize: string[];
    private static speciesSkillsMap;
    private static speciesOthersMap;
    private static speciesOriginsMap;
    private static subSpeciesSkillsMap;
    private static subSpeciesOthersMap;
    private static subSpeciesNamesMap;
    private static subSpeciesOriginsMap;
    private static randomTalents;
    private static referentialLoaded;
    private static creatureReferentialLoaded;
    static initReferential(callback: () => void, forCreatures?: boolean): Promise<void>;
    static getClassTrappings(): {
        [key: string]: string;
    };
    static getClassKeyFromCareer(career: ItemData): string | undefined;
    static getSpeciesMap(): {
        [key: string]: string;
    };
    static getSubSpeciesMap(): {
        [key: string]: {
            [subKey: string]: {
                name: string;
                skills: string[];
                talents: any[];
            };
        };
    };
    static getSpeciesSubSpeciesMap(speciesKey: string): {
        [key: string]: {
            name: string;
            skills: string[];
            talents: any[];
        };
    } | null;
    static getOldSpeciesSkillsMap(): {
        [key: string]: string[];
    };
    static getOldSpeciesTalentsMap(): {
        [key: string]: any[];
    };
    static getOldRandomTalents(): string[];
    static getWeaponTypes(): {
        melee: string;
        ranged: string;
    };
    static getWeaponGroups(): string[];
    static getWeaponGroupsKey(group: string): string;
    static getMeleeWeaponGroups(): string[];
    static getRangedWeaponGroups(): string[];
    static getBasicWeaponGroups(): string;
    static getCareerEntities(withWorld?: boolean): Promise<Item[]>;
    static getCareerEntitieNames(withWorld?: boolean): Promise<string[]>;
    static getWorldCareers(): Promise<Item[]>;
    static getWorldEntities(type: string): Promise<Item[]>;
    static getWorldActorEntities(type?: string): Promise<Actor[]>;
    static getTrappingEntities(withWorld?: boolean): Promise<Item[]>;
    static getRandomSpeciesCareers(speciesKey: string, subSpeciesKey?: string): Promise<string[]>;
    static getStatusTiers(): any;
    static getAllBasicSkills(): Promise<any>;
    static findSkill(name: string): Promise<ItemData>;
    static findTalent(name: string): Promise<ItemData>;
    static findPsychology(name: string): Promise<ItemData>;
    static findTrait(name: string, onlyRefTrait?: boolean): Promise<any>;
    static findTrappings(name: string, referentialTrappings?: Item[]): Promise<ItemData[]>;
    static findTrappingsByWords(name: string, referentialTrappings?: Item[]): Promise<ItemData[]>;
    static findTrapping(name: string, referentialTrappings?: Item[], fromWord?: boolean): Promise<ItemData | null>;
    static getSpeciesCharacteristics(speciesKey: string): Promise<any>;
    static getSpeciesMovement(speciesKey: string): Promise<any>;
    static getAllMoneyItems(): Promise<ItemData[]>;
    static getActorsEntities(withWorld?: boolean): Promise<{
        [pack: string]: Actor[];
    }>;
    static getBestiaryEntities(withWorld?: boolean): Promise<{
        [pack: string]: Actor[];
    }>;
    static getSkillEntities(withWorld?: boolean): Promise<Item[]>;
    static getTalentEntities(withWorld?: boolean): Promise<Item[]>;
    static getPsychologyEntities(withWorld?: boolean): Promise<Item[]>;
    static getTraitEntities(withWorld?: boolean): Promise<Item[]>;
    static getSpellEntities(withWorld?: boolean): Promise<Item[]>;
    static getPrayerEntities(withWorld?: boolean): Promise<Item[]>;
    static getPhysicalMutationEntities(withWorld?: boolean): Promise<Item[]>;
    static getMentalMutationEntities(withWorld?: boolean): Promise<Item[]>;
    static getCompendiumActorTraits(): Promise<ItemData[]>;
    static getCompendiumActorSkills(): Promise<ItemData[]>;
    static getCompendiumActorTalents(): Promise<ItemData[]>;
    static getSpeciesSkillsMap(): Promise<{
        [key: string]: string[];
    }>;
    static getSpeciesSkills(key: string): Promise<string[]>;
    static getSubSpeciesSkillsMap(): Promise<{
        [key: string]: {
            [subKey: string]: string[];
        };
    }>;
    static getSubSpeciesSkills(key: string, subKey: string): Promise<string[]>;
    static getSpeciesOthersMap(): Promise<{
        [key: string]: any[];
    }>;
    static getSpeciesOthers(key: string, onlyToChoose?: boolean, onlyAuto?: boolean): Promise<any[]>;
    static getSubSpeciesOthersMap(): Promise<{
        [key: string]: {
            [subKey: string]: any[];
        };
    }>;
    static getSubSpeciesOthers(key: string, subKey: string, onlyToChoose?: boolean, onlyAuto?: boolean): Promise<any[]>;
    static getSubSpeciesNamesMap(): {
        [key: string]: {
            [subKey: string]: string;
        };
    };
    static getSubSpeciesNames(key: string, subKey: string): string;
    static getSpeciesOriginsMap(): Promise<{
        [key: string]: {
            [origin: string]: any[];
        };
    }>;
    static getSpeciesOrigins(key: string, onlyToChoose?: boolean, onlyAuto?: boolean): Promise<{
        [origin: string]: any[];
    }>;
    static getSpeciesOrigin(key: string, origin: string, onlyToChoose?: boolean, onlyAuto?: boolean): Promise<any[]>;
    static getSubSpeciesOriginsMap(): Promise<{
        [key: string]: {
            [subKey: string]: {
                [origin: string]: any[];
            };
        };
    }>;
    static getSubSpeciesOrigins(key: string, subKey: string, onlyToChoose?: boolean, onlyAuto?: boolean): Promise<{
        [origin: string]: any[];
    }>;
    static getSubSpeciesOrigin(key: string, subKey: string, origin: string, onlyToChoose?: boolean, onlyAuto?: boolean): Promise<any[]>;
    static getRandomTalents(): Promise<string[]>;
    private static initSpeciesEntities;
    static resolveName(name: string): string;
    static resolveRandomPrefix(name: string): number;
    private static resolvePrefix;
    private static resolveSearch;
    private static speciesRefFilter;
}

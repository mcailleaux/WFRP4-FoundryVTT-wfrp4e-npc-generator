export default class ReferentialUtil {
    static getClassTrappings(): {
        [key: string]: string;
    };
    static getClassKeyFromCareer(career: Item.Data): string | undefined;
    static getTrappingCategories(): string[];
    static getSpeciesMap(): {
        [key: string]: string;
    };
    static getSpeciesSkillsMap(): {
        [key: string]: string[];
    };
    static getSpeciesTalentsMap(): {
        [key: string]: any[];
    };
    static getRandomTalents(): string[];
    static getWeaponTypes(): {
        melee: string;
        ranged: string;
    };
    static getWeaponGroups(): string[];
    static getWeaponGroupsKey(group: string): string;
    static getMeleeWeaponGroups(): string[];
    static getRangedWeaponGroups(): string[];
    static getBasicWeaponGroups(): string;
    static getCareerIndexes(): Promise<Item[]>;
    static getCareerEntities(withWorld?: boolean): Promise<Item[]>;
    static getTrappingEntities(withWorld?: boolean): Promise<Item[]>;
    static getRandomSpeciesCareers(speciesKey: string): Promise<string[]>;
    static getStatusTiers(): any;
    static getAllBasicSkills(): Promise<any>;
    static findSkill(name: string): Promise<any>;
    static findTalent(name: string): Promise<any>;
    static findTrappings(name: string, referentialTrappings?: Item[]): Promise<Item.Data[]>;
    static findTrappingsByWords(name: string, referentialTrappings?: Item[]): Promise<Item.Data<{}>[]>;
    static findTrapping(name: string, referentialTrappings?: Item[], fromWord?: boolean): Promise<Item.Data | null>;
    static getSpeciesCharacteristics(speciesKey: string): Promise<any>;
    static getSpeciesMovement(speciesKey: string): Promise<any>;
    static getAllMoneyItems(): Promise<Item.Data[]>;
}

export default class CompendiumUtil {
    private static compendiumCareerIndexes;
    private static compendiumCareers;
    private static compendiumTrappings;
    private static compendiumSkillIndexes;
    private static compendiumSkills;
    private static compendiumTalentIndexes;
    private static compendiumTalents;
    static compendiumloaded: boolean;
    static initCompendium(): Promise<void>;
    static getCompendiumCareerIndexes(): Promise<Item<{}>[]>;
    static getCompendiumCareers(): Promise<Item<{}>[]>;
    static getCompendiumTrappings(): Promise<Item<{}>[]>;
    static getCompendiumSkillIndexes(): Promise<Item<{}>[]>;
    static getCompendiumSkills(): Promise<Item<{}>[]>;
    static getCompendiumTalentIndexes(): Promise<Item<{}>[]>;
    static getCompendiumTalents(): Promise<Item<{}>[]>;
}

export default class CompendiumUtil {
    private static compendiumItems;
    private static compendiumActors;
    private static compendiumCareers;
    private static compendiumCareerGroups;
    private static compendiumTrappings;
    private static compendiumBestiary;
    private static compendiumSkills;
    private static compendiumTalents;
    private static compendiumTraits;
    private static compendiumSizeTrait;
    private static compendiumSwarmTrait;
    private static compendiumWeaponTrait;
    private static compendiumArmorTrait;
    private static compendiumRangedTrait;
    private static compendiumSpells;
    private static compendiumPrayers;
    private static compendiumPhysicalMutations;
    private static compendiumMentalMutations;
    private static compendiumLoaded;
    private static creatureCompendiumLoaded;
    static initCompendium(callback: () => void, forCreatures?: boolean): Promise<void>;
    static getCompendiumItems(): Promise<Item<{}>[]>;
    static getCompendiumActors(): Promise<{
        [pack: string]: Actor<{}, Item<{}>>[];
    }>;
    static getCompendiumCareers(): Promise<Item<{}>[]>;
    static getCompendiumCareersGroups(): Promise<string[]>;
    static getTrappingCategories(): string[];
    static getCompendiumTrappings(): Promise<Item<{}>[]>;
    static getCompendiumBestiary(): Promise<{
        [pack: string]: Actor<{}, Item<{}>>[];
    }>;
    static getCompendiumSkills(): Promise<Item<{}>[]>;
    static getCompendiumTalents(): Promise<Item<{}>[]>;
    static getCompendiumTraits(): Promise<Item<{}>[]>;
    static getCompendiumSizeTrait(): Promise<Item<{}>>;
    static getCompendiumSwarmTrait(): Promise<Item<{}>>;
    static getCompendiumWeaponTrait(): Promise<Item<{}>>;
    static getCompendiumArmourTrait(): Promise<Item<{}>>;
    static getCompendiumRangedTrait(): Promise<Item<{}>>;
    static getSizes(): {
        [key: string]: string;
    };
    static getCompendiumSpells(): Promise<Item<{}>[]>;
    static getCompendiumPrayers(): Promise<Item<{}>[]>;
    static getCompendiumPhysicalMutations(): Promise<Item<{}>[]>;
    static getCompendiumMentalMutations(): Promise<Item<{}>[]>;
}

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import DialogUtil from './dialog-util.js';
import ReferentialUtil from './referential-util.js';
import EntityUtil from './entity-util.js';
import { i18n, wfrp4e } from '../constant.js';
export default class TrappingChooser {
    static selectTrappings(initTrappings, callback, undo) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            const dialogId = new Date().getTime();
            const trappings = [
                ...(yield ReferentialUtil.getTrappingEntities(true)).map((t) => t.data),
            ].sort((t1, t2) => {
                return t1.name.localeCompare(t2.name);
            });
            const trappingsMap = {};
            for (let trapping of trappings) {
                const type = (_c = (_b = (_a = trapping.data) === null || _a === void 0 ? void 0 : _a.trappingType) === null || _b === void 0 ? void 0 : _b.value) !== null && _c !== void 0 ? _c : trapping.type;
                const categorie = wfrp4e().config.trappingCategories[type];
                if (trappingsMap[categorie] == null) {
                    trappingsMap[categorie] = [];
                }
                trappingsMap[categorie].push(trapping);
            }
            const trappingsCategorieEntries = Object.entries(wfrp4e().config.trappingCategories);
            const trappingsSortList = [
                'weapon',
                'ammunition',
                'armour',
                'container',
                'clothingAccessories',
                'foodAndDrink',
                'toolsAndKits',
                'booksAndDocuments',
                'tradeTools',
                'drugsPoisonsHerbsDraughts',
                'misc',
                'ingredient',
                'money',
                'others',
            ];
            const trappingsSort = (a, b) => {
                const g1 = a[0];
                const g2 = b[0];
                const entry1 = trappingsCategorieEntries === null || trappingsCategorieEntries === void 0 ? void 0 : trappingsCategorieEntries.find(([_key, value]) => value === g1);
                const entry2 = trappingsCategorieEntries === null || trappingsCategorieEntries === void 0 ? void 0 : trappingsCategorieEntries.find(([_key, value]) => value === g2);
                const key1 = entry1 != null ? entry1[0] : 'others';
                const key2 = entry2 != null ? entry2[0] : 'others';
                return trappingsSortList.indexOf(key1) - trappingsSortList.indexOf(key2);
            };
            const trappingsId = `creature-add-remove-trappings-${dialogId}`;
            new Dialog({
                title: i18n().localize('WFRP4NPCGEN.select.trappings.title'),
                content: `<form>
            <div class="form-group">
          ${DialogUtil.getSelectAddRemoveScript({
                    id: trappingsId,
                    captions: `
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.name.select.label')}
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.select.trappings.quantity.label', 'max-width: 80px;')}
            ${DialogUtil.getLabelScript('', 'max-width: 38px;')}
            `,
                    optionGroups: EntityUtil.toSelectOptionGroup(trappingsMap),
                    sort: trappingsSort,
                    initValues: initTrappings === null || initTrappings === void 0 ? void 0 : initTrappings.map((s) => {
                        var _a;
                        return {
                            key: s._id,
                            value: (_a = s.displayName) !== null && _a !== void 0 ? _a : s.name,
                            count: s.data.quantity.value,
                        };
                    }),
                    withCount: true,
                    initCount: 1,
                })}
          </div>
          </form>
          <script>  
              
              ${DialogUtil.getAddRemoveElementScript()}
                
            </script>
            `,
                buttons: DialogUtil.getDialogButtons(dialogId, (html) => {
                    const resultTrappings = [];
                    html.find(`.${trappingsId}`).each((_i, r) => {
                        const id = r.id;
                        const key = r.value;
                        let count = 0;
                        html.find(`#${id}-count`).each((_i1, r1) => {
                            count = Number(r1.value);
                        });
                        let trapping = (initTrappings.find((t) => t._id === key));
                        if (trapping == null) {
                            trapping = trappings.find((t) => t._id === key);
                        }
                        trapping.data.quantity.value = count;
                        resultTrappings.push(trapping);
                    });
                    callback(resultTrappings);
                }, undo),
                default: 'yes',
            }, {
                resizable: true,
                classes: ['dialog', 'wfrp4e-npc-generator-dialog'],
            }).render(true);
        });
    }
}
//# sourceMappingURL=trapping-chooser.js.map
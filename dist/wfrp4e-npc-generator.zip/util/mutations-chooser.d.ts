import { ItemData } from '@league-of-foundry-developers/foundry-vtt-types/src/foundry/common/data/data.mjs';
export default class MutationsChooser {
    static selectMutations(initPhysicals: ItemData[], initMentals: ItemData[], callback: (physicals: ItemData[], mentals: ItemData[]) => void, undo?: () => void): Promise<void>;
}

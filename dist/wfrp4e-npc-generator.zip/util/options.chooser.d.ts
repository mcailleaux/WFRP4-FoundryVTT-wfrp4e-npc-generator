import Options from './options.js';
export default class OptionsChooser {
    static selectOptions(initOptions: Options, callback: (options: Options) => void, undo: () => void): Promise<void>;
}

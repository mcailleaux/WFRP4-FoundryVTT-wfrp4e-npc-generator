import { IOptions } from './options-int.js';
export default class OptionsChooser {
    static selectOptions(forCreature: boolean, initOptions: IOptions, speciesKey: string, callback: (options: IOptions) => void, undo: () => void): Promise<void>;
}

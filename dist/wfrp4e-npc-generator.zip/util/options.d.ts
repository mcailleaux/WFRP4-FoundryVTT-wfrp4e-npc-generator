import { GenerateEffectOptionEnum } from './generate-effect-option.enum.js';
export default class Options {
    withClassTrappings: boolean;
    withCareerTrappings: boolean;
    generateMoneyEffect: GenerateEffectOptionEnum;
    generateWeaponEffect: GenerateEffectOptionEnum;
}

import { getGenerateEffectOptionEnum, } from './generate-effect-option.enum.js';
import RegisterSettings from './register-settings.js';
export default class Options {
    constructor() {
        this.withClassTrappings = game.settings.get(RegisterSettings.moduleName, 'defaultWithClassTrappings');
        this.withCareerTrappings = game.settings.get(RegisterSettings.moduleName, 'defaultWithCareerTrappings');
        this.generateMoneyEffect = getGenerateEffectOptionEnum(game.settings.get(RegisterSettings.moduleName, 'defaultGenerateMoneyEffect'));
        this.generateWeaponEffect = getGenerateEffectOptionEnum(game.settings.get(RegisterSettings.moduleName, 'defaultGenerateWeaponEffect'));
    }
}
//# sourceMappingURL=options.js.map
import { getGenerateEffectOptionEnum, } from './generate-effect-option.enum.js';
import RegisterSettings from './register-settings.js';
import { settings } from '../constant.js';
export default class Options {
    constructor() {
        this.withClassTrappings = settings().get(RegisterSettings.moduleName, 'defaultWithClassTrappings');
        this.withCareerTrappings = settings().get(RegisterSettings.moduleName, 'defaultWithCareerTrappings');
        this.generateMoneyEffect = getGenerateEffectOptionEnum(settings().get(RegisterSettings.moduleName, 'defaultGenerateMoneyEffect'));
        this.generateWeaponEffect = getGenerateEffectOptionEnum(settings().get(RegisterSettings.moduleName, 'defaultGenerateWeaponEffect'));
        this.withGenPathCareerName = settings().get(RegisterSettings.moduleName, 'defaultWithGenPathCareerName');
        this.withLinkedToken = settings().get(RegisterSettings.moduleName, 'defaultWithLinkedToken');
        this.withInitialMoney = settings().get(RegisterSettings.moduleName, 'defaultWithInitialMoney');
        this.withInitialWeapons = settings().get(RegisterSettings.moduleName, 'defaultWithInitialWeapons');
        this.genPath = settings().get(RegisterSettings.moduleName, 'defaultGenPath');
        this.imagePath = null;
        this.tokenPath = null;
        this.editAbilities = settings().get(RegisterSettings.moduleName, 'defaultEditAbilities');
        this.editTrappings = settings().get(RegisterSettings.moduleName, 'defaultEditTrappings');
        this.addMagics = settings().get(RegisterSettings.moduleName, 'defaultAddMagics');
        this.addMutations = settings().get(RegisterSettings.moduleName, 'defaultAddMutations');
    }
}
//# sourceMappingURL=options.js.map
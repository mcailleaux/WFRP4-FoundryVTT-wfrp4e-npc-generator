import { getGenerateEffectOptionEnum, } from './generate-effect-option.enum.js';
import RegisterSettings from './register-settings.js';
export default class Options {
    constructor() {
        this.withClassTrappings = game.settings.get(RegisterSettings.moduleName, 'defaultWithClassTrappings');
        this.withCareerTrappings = game.settings.get(RegisterSettings.moduleName, 'defaultWithCareerTrappings');
        this.generateMoneyEffect = getGenerateEffectOptionEnum(game.settings.get(RegisterSettings.moduleName, 'defaultGenerateMoneyEffect'));
        this.generateWeaponEffect = getGenerateEffectOptionEnum(game.settings.get(RegisterSettings.moduleName, 'defaultGenerateWeaponEffect'));
        this.withGenPathCareerName = game.settings.get(RegisterSettings.moduleName, 'defaultWithGenPathCareerName');
        this.withLinkedToken = game.settings.get(RegisterSettings.moduleName, 'defaultWithLinkedToken');
        this.withInitialMoney = game.settings.get(RegisterSettings.moduleName, 'defaultWithInitialMoney');
        this.withInitialWeapons = game.settings.get(RegisterSettings.moduleName, 'defaultWithInitialWeapons');
        this.genPath = game.settings.get(RegisterSettings.moduleName, 'defaultGenPath');
        this.imagePath = null;
        this.tokenPath = null;
        this.editAbilities = game.settings.get(RegisterSettings.moduleName, 'defaultEditAbilities');
        this.editTrappings = game.settings.get(RegisterSettings.moduleName, 'defaultEditTrappings');
        this.addMagics = game.settings.get(RegisterSettings.moduleName, 'defaultAddMagics');
        this.addMutations = game.settings.get(RegisterSettings.moduleName, 'defaultAddMutations');
    }
}
//# sourceMappingURL=options.js.map
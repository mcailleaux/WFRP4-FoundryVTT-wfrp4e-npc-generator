/**
 * Used by `deburr` to convert Latin-1 Supplement and Latin Extended-A
 * letters to basic Latin letters.
 *
 * @private
 * @param {string} letter The matched letter to deburr.
 * @returns {string} Returns the deburred letter.
 */
declare const deburrLetter: (key: string) => any;
export default deburrLetter;

export default class NameChooser {
    static selectName(initName: string, speciesKey: string, callback: (name: string) => void, undo: () => void): Promise<void>;
}

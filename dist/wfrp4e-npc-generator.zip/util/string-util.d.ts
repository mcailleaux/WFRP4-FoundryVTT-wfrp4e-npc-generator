export default class StringUtil {
    static includesDeburrIgnoreCase(input: string, include: string): boolean;
    static equalsDeburrIgnoreCase(input: string, include: string): boolean;
    static arrayIncludesDeburrIgnoreCase(array: string[], include: string): boolean;
    static localCompareDeburrIgnoreCase(c1: string, c2: string, asc?: boolean): number;
    static toDeburrLowerCase(value: string): string;
}

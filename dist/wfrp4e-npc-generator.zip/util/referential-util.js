var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import StringUtil from './string-util.js';
import CompendiumUtil from './compendium-util.js';
import EntityUtil from './entity-util.js';
export default class ReferentialUtil {
    static getClassTrappings() {
        const voClassTraping = game.wfrp4e.config.classTrappings;
        const resolvedClassTrapping = {};
        Object.entries(voClassTraping).forEach(([key]) => {
            let useKey = key;
            if (game.i18n.translations[useKey] == null &&
                useKey.endsWith('s')) {
                useKey = useKey.substring(0, useKey.length - 1);
            }
            const localKey = game.i18n.localize(useKey);
            resolvedClassTrapping[localKey] = game.i18n.localize(`WFRP4NPCGEN.trappings.class.${key}`);
        });
        return resolvedClassTrapping;
    }
    static getClassKeyFromCareer(career) {
        var _a, _b;
        const careerClass = (_b = (_a = career.data) === null || _a === void 0 ? void 0 : _a.class) === null || _b === void 0 ? void 0 : _b.value;
        const keys = Object.keys(this.getClassTrappings());
        return keys.find((k) => StringUtil.includesDeburrIgnoreCase(k.trim(), careerClass === null || careerClass === void 0 ? void 0 : careerClass.trim()));
    }
    static getSpeciesMap() {
        return game.wfrp4e.config.species;
    }
    static getSubSpeciesMap() {
        const result = {};
        for (let [key, value] of Object.entries(game.wfrp4e.config.subspecies)) {
            for (let [subKey, subValue] of Object.entries(value)) {
                const content = {
                    name: subValue.name,
                    skills: subValue.skills != null
                        ? subValue.skills
                        : this.getSpeciesSkillsMap()[key],
                    talents: subValue.talents != null
                        ? subValue.talents
                        : this.getSpeciesTalentsMap()[key],
                };
                if (result[key] == null) {
                    result[key] = {};
                }
                result[key][subKey] = content;
            }
        }
        return result;
    }
    static getSpeciesSubSpeciesMap(speciesKey) {
        const subSpecies = this.getSubSpeciesMap();
        return subSpecies != null ? subSpecies[speciesKey] : null;
    }
    static getSpeciesSkillsMap() {
        return game.wfrp4e.config.speciesSkills;
    }
    static getSpeciesTalentsMap() {
        return game.wfrp4e.config.speciesTalents;
    }
    static getRandomTalents() {
        return game.wfrp4e.tables.talents.rows.map((row) => row.name);
    }
    static getWeaponTypes() {
        return {
            melee: game.i18n.localize('WFRP4NPCGEN.trappings.weapon.skill.melee'),
            ranged: game.i18n.localize('WFRP4NPCGEN.trappings.weapon.skill.ranged'),
        };
    }
    static getWeaponGroups() {
        return Object.values(game.wfrp4e.config.weaponGroups);
    }
    static getWeaponGroupsKey(group) {
        for (let key of Object.keys(game.wfrp4e.config.weaponGroups)) {
            if (StringUtil.equalsDeburrIgnoreCase(game.wfrp4e.config.weaponGroups[key], group)) {
                return key;
            }
        }
        return '';
    }
    static getMeleeWeaponGroups() {
        const groups = game.wfrp4e.config.weaponGroups;
        return [
            groups.basic,
            groups.brawling,
            groups.cavalry,
            groups.fencing,
            groups.flail,
            groups.parry,
            groups.polearm,
            groups.twohanded,
        ];
    }
    static getRangedWeaponGroups() {
        const groups = game.wfrp4e.config.weaponGroups;
        return [
            groups.blackpowder,
            groups.bow,
            groups.crossbow,
            groups.engineering,
            groups.entangling,
            groups.explosives,
            groups.sling,
            groups.throwing,
        ];
    }
    static getBasicWeaponGroups() {
        return game.wfrp4e.config.weaponGroups.basic;
    }
    static getCareerEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const careers = yield CompendiumUtil.getCompendiumCareers();
            if (withWorld) {
                const worldCareers = yield this.getWorldCareers();
                if (worldCareers != null && worldCareers.length > 0) {
                    careers.push(...worldCareers);
                }
            }
            return Promise.resolve(careers);
        });
    }
    static getWorldCareers() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const careersGroups = yield CompendiumUtil.getCompendiumCareersGroups();
            const worldCareers = (_b = (_a = game.items) === null || _a === void 0 ? void 0 : _a.entities) === null || _b === void 0 ? void 0 : _b.filter((item) => {
                var _a, _b, _c;
                const group = (_c = (_b = (_a = item === null || item === void 0 ? void 0 : item.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.careergroup) === null || _c === void 0 ? void 0 : _c.value;
                return item.type === 'career' && !careersGroups.includes(group);
            });
            return Promise.resolve(worldCareers);
        });
    }
    static getWorldEntities(type) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const worldEntities = (_b = (_a = game.items) === null || _a === void 0 ? void 0 : _a.entities) === null || _b === void 0 ? void 0 : _b.filter((item) => {
                return item.type === type;
            });
            return Promise.resolve(worldEntities);
        });
    }
    static getWorldActorEntities(type) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const worldEntities = (_a = game.actors) === null || _a === void 0 ? void 0 : _a.filter((actor) => {
                var _a;
                return type != null ? ((_a = actor.data) === null || _a === void 0 ? void 0 : _a.type) === type : true;
            });
            return Promise.resolve(worldEntities);
        });
    }
    static getTrappingEntities(withWorld = true) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const trappings = yield CompendiumUtil.getCompendiumTrappings();
            const finalTrappings = [];
            if (withWorld) {
                const trappingCategories = CompendiumUtil.getTrappingCategories();
                const worldTrappings = (_b = (_a = game.items) === null || _a === void 0 ? void 0 : _a.entities) === null || _b === void 0 ? void 0 : _b.filter((item) => {
                    var _a, _b, _c;
                    return trappingCategories.includes(item.type) ||
                        trappingCategories.includes((_c = (_b = (_a = item === null || item === void 0 ? void 0 : item.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.trappingType) === null || _c === void 0 ? void 0 : _c.value);
                });
                if (worldTrappings != null && worldTrappings.length > 0) {
                    finalTrappings.push(...worldTrappings);
                }
            }
            finalTrappings.push(...trappings);
            return Promise.resolve(finalTrappings);
        });
    }
    static getRandomSpeciesCareers(speciesKey) {
        return __awaiter(this, void 0, void 0, function* () {
            if (speciesKey == null) {
                return [];
            }
            const randomCareers = game.wfrp4e.tables.career.rows
                .filter((row) => {
                var _a, _b;
                let result = ((_a = row === null || row === void 0 ? void 0 : row.range[speciesKey]) === null || _a === void 0 ? void 0 : _a.length) > 0;
                if (!result && speciesKey === 'human') {
                    result = ((_b = row === null || row === void 0 ? void 0 : row.range['human-reiklander']) === null || _b === void 0 ? void 0 : _b.length) > 0;
                }
                return result;
            })
                .map((row) => row.name);
            const careers = yield this.getCareerEntities(false);
            const result = [];
            randomCareers.forEach((rc) => {
                let cs = careers.filter((c) => {
                    var _a, _b, _c;
                    return StringUtil.includesDeburrIgnoreCase((_c = (_b = (_a = c.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.careergroup) === null || _c === void 0 ? void 0 : _c.value, rc);
                });
                if (cs.length !== 4) {
                    const strictCareer = careers.find((c) => StringUtil.equalsDeburrIgnoreCase(c.name, rc));
                    if (strictCareer != null) {
                        cs = careers.filter((c) => {
                            var _a, _b, _c, _d, _e, _f;
                            return StringUtil.equalsDeburrIgnoreCase((_c = (_b = (_a = c.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.careergroup) === null || _c === void 0 ? void 0 : _c.value, (_f = (_e = (_d = strictCareer.data) === null || _d === void 0 ? void 0 : _d.data) === null || _e === void 0 ? void 0 : _e.careergroup) === null || _f === void 0 ? void 0 : _f.value);
                        });
                    }
                }
                if (cs.length === 4) {
                    result.push(...cs.map((c) => c.name));
                }
            });
            return Promise.resolve(result);
        });
    }
    static getStatusTiers() {
        return game.wfrp4e.config.statusTiers;
    }
    static getAllBasicSkills() {
        return __awaiter(this, void 0, void 0, function* () {
            return yield game.wfrp4e.utility.allBasicSkills();
        });
    }
    static findSkill(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const skills = [
                ...(yield this.getWorldEntities('skill')),
                ...(yield this.getSkillEntities(false)),
            ];
            const skill = EntityUtil.find(name, skills);
            if (skill == null) {
                throw ('Could not find skill (or specialization of) ' +
                    name +
                    ' in compendum or world');
            }
            return skill;
        });
    }
    static findTalent(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const talents = [
                ...(yield this.getWorldEntities('talent')),
                ...(yield this.getTalentEntities(false)),
            ];
            const talent = EntityUtil.find(name, talents);
            if (talent == null) {
                throw ('Could not find talent (or specialization of) ' +
                    name +
                    ' in compendum or world');
            }
            return talent;
        });
    }
    static findTrait(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const traits = [
                ...(yield this.getWorldEntities('trait')),
                ...(yield ReferentialUtil.getTraitEntities(false)),
            ];
            const trait = EntityUtil.find(name, traits);
            if (trait == null) {
                throw ('Could not find trait (or specialization of) ' +
                    name +
                    ' in compendum or world');
            }
            if (name.includes('(') && name.includes(')')) {
                const simpleName = StringUtil.getSimpleName(name);
                const groupedName = StringUtil.getGroupName(name);
                trait.name = simpleName;
                trait.data.specification.value = groupedName;
            }
            else {
                trait.name = name;
                trait.displayName = name;
            }
            return trait;
        });
    }
    static findTrappings(name, referentialTrappings) {
        return __awaiter(this, void 0, void 0, function* () {
            let searchName = StringUtil.toDeburrLowerCase(name);
            const trappings = [];
            let trapping = yield this.findTrapping(searchName, referentialTrappings);
            while (trapping != null) {
                trappings.push(trapping);
                const lastSearch = searchName;
                searchName = searchName
                    .replace(StringUtil.toDeburrLowerCase(trapping.name.trim()), '')
                    .replace('(', '')
                    .replace(')', '')
                    .trim();
                if (searchName === lastSearch) {
                    const simpleName = searchName.includes('(') && searchName.includes(')')
                        ? searchName.substring(0, searchName.indexOf('(')).trim()
                        : searchName;
                    if (simpleName !== searchName) {
                        searchName = searchName
                            .replace(StringUtil.toDeburrLowerCase(simpleName), '')
                            .replace('(', '')
                            .replace(')', '')
                            .trim();
                    }
                }
                if (searchName === lastSearch) {
                    const words = trapping.name
                        .trim()
                        .split(' ')
                        .map((word) => word.trim())
                        .filter((word) => word.length > 3);
                    for (let word of words) {
                        searchName = searchName
                            .replace(StringUtil.toDeburrLowerCase(word), '')
                            .trim();
                    }
                }
                if (searchName.length > 3 && lastSearch !== searchName) {
                    trapping = yield this.findTrapping(searchName, referentialTrappings);
                }
                else {
                    trapping = null;
                }
            }
            if (searchName.trim().includes(' ')) {
                trappings.push(...(yield this.findTrappingsByWords(searchName, referentialTrappings)));
            }
            return Promise.resolve(trappings);
        });
    }
    static findTrappingsByWords(name, referentialTrappings) {
        return __awaiter(this, void 0, void 0, function* () {
            const trappings = [];
            if (name != null && name.length > 0) {
                const words = name
                    .split(' ')
                    .map((word) => word.trim())
                    .map((word) => word.replace('(', '').replace(')', ''))
                    .filter((word) => word.length > 3);
                for (let word of words) {
                    const trapping = yield this.findTrapping(word, referentialTrappings, true);
                    if (trapping != null) {
                        trappings.push(trapping);
                    }
                }
            }
            return trappings;
        });
    }
    static findTrapping(name, referentialTrappings, fromWord = false) {
        var _a, _b, _c, _d;
        return __awaiter(this, void 0, void 0, function* () {
            const searchTrappings = referentialTrappings !== null && referentialTrappings !== void 0 ? referentialTrappings : (yield this.getTrappingEntities(true));
            const simpleName = name.includes('(') && name.includes(')')
                ? name.substring(0, name.indexOf('(')).trim()
                : name;
            let trapping = (_c = (_b = (_a = searchTrappings.find((t) => StringUtil.equalsDeburrIgnoreCase(name, t.name))) !== null && _a !== void 0 ? _a : searchTrappings.find((t) => StringUtil.equalsDeburrIgnoreCase(t.name, simpleName))) !== null && _b !== void 0 ? _b : searchTrappings.find((t) => StringUtil.includesDeburrIgnoreCase(t.name, name))) !== null && _c !== void 0 ? _c : searchTrappings.find((t) => StringUtil.includesDeburrIgnoreCase(t.name, simpleName));
            if (trapping == null && !fromWord) {
                trapping = searchTrappings
                    .sort((t1, t2) => {
                    return t2.name.length - t1.name.length;
                })
                    .find((t) => StringUtil.includesDeburrIgnoreCase(name, t.name));
            }
            if (trapping == null) {
                console.warn(`Can't find trapping ${name}${simpleName !== name ? `or ${simpleName}` : ''}`);
            }
            else if (!StringUtil.equalsDeburrIgnoreCase(trapping.name, name)) {
                console.warn(`Trapping ${name} is resolved by ${trapping.name}`);
            }
            return Promise.resolve((_d = trapping === null || trapping === void 0 ? void 0 : trapping.data) !== null && _d !== void 0 ? _d : null);
        });
    }
    static getSpeciesCharacteristics(speciesKey) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield game.wfrp4e.utility.speciesCharacteristics(speciesKey, true);
        });
    }
    static getSpeciesMovement(speciesKey) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield game.wfrp4e.utility.speciesMovement(speciesKey);
        });
    }
    static getAllMoneyItems() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            let moneyItems = (_a = (yield game.wfrp4e.utility.allMoneyItems())) !== null && _a !== void 0 ? _a : [];
            moneyItems = moneyItems
                .map((mi) => {
                mi.data.quantity.value = 0;
                return mi;
            })
                .sort((a, b) => {
                const aData = a.data;
                const bData = b.data;
                return aData.coinValue.value > bData.coinValue.value ? -1 : 1;
            });
            return Promise.resolve(moneyItems);
        });
    }
    static getActorsEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const actors = yield CompendiumUtil.getCompendiumActors();
            if (withWorld) {
                const worldActors = yield this.getWorldActorEntities();
                if (worldActors != null && worldActors.length > 0) {
                    actors[game.world.title] = worldActors;
                }
            }
            return Promise.resolve(actors);
        });
    }
    static getBestiaryEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const bestiary = yield CompendiumUtil.getCompendiumBestiary();
            if (withWorld) {
                const worldActors = yield this.getWorldActorEntities('creature');
                if (worldActors != null && worldActors.length > 0) {
                    bestiary[game.world.title] = worldActors;
                }
            }
            return Promise.resolve(bestiary);
        });
    }
    static getSkillEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const skills = yield CompendiumUtil.getCompendiumSkills();
            if (withWorld) {
                const worldSkills = yield this.getWorldEntities('skill');
                if (worldSkills != null && worldSkills.length > 0) {
                    skills.push(...worldSkills);
                }
            }
            return Promise.resolve(skills);
        });
    }
    static getTalentEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const talents = yield CompendiumUtil.getCompendiumTalents();
            if (withWorld) {
                const worldTalents = yield this.getWorldEntities('talent');
                if (worldTalents != null && worldTalents.length > 0) {
                    talents.push(...worldTalents);
                }
            }
            return Promise.resolve(talents);
        });
    }
    static getTraitEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const traits = yield CompendiumUtil.getCompendiumTraits();
            if (withWorld) {
                const worldTraits = yield this.getWorldEntities('trait');
                if (worldTraits != null && worldTraits.length > 0) {
                    traits.push(...worldTraits);
                }
            }
            return Promise.resolve(traits);
        });
    }
    static getSpellEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const spells = yield CompendiumUtil.getCompendiumSpells();
            if (withWorld) {
                const worldSpells = yield this.getWorldEntities('spell');
                if (worldSpells != null && worldSpells.length > 0) {
                    spells.push(...worldSpells);
                }
            }
            return Promise.resolve(spells);
        });
    }
    static getPrayerEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const prayers = yield CompendiumUtil.getCompendiumPrayers();
            if (withWorld) {
                const worldPrayers = yield this.getWorldEntities('prayer');
                if (worldPrayers != null && worldPrayers.length > 0) {
                    prayers.push(...worldPrayers);
                }
            }
            return Promise.resolve(prayers);
        });
    }
    static getPhysicalMutationEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const physicalMutations = yield CompendiumUtil.getCompendiumPhysicalMutations();
            if (withWorld) {
                const worldPrayers = yield this.getWorldEntities('mutation');
                if (worldPrayers != null && worldPrayers.length > 0) {
                    physicalMutations.push(...worldPrayers.filter((m) => m.data.data.mutationType.value === 'physical'));
                }
            }
            return Promise.resolve(physicalMutations);
        });
    }
    static getMentalMutationEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const mentalMutations = yield CompendiumUtil.getCompendiumMentalMutations();
            if (withWorld) {
                const worldPrayers = yield this.getWorldEntities('mutation');
                if (worldPrayers != null && worldPrayers.length > 0) {
                    mentalMutations.push(...worldPrayers.filter((m) => m.data.data.mutationType.value === 'mental'));
                }
            }
            return Promise.resolve(mentalMutations);
        });
    }
    static getCompendiumActorTraits() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const compendiumActorTraits = [];
            const traits = yield CompendiumUtil.getCompendiumTraits();
            const traitsNames = traits.map((t) => EntityUtil.toMinimalName(t.name).trim());
            const actorsMap = yield this.getActorsEntities();
            for (let [_key, actors] of Object.entries(actorsMap)) {
                for (let actor of actors) {
                    const data = actor.data;
                    const newTraits = (_a = data === null || data === void 0 ? void 0 : data.traits) === null || _a === void 0 ? void 0 : _a.filter((t) => !traitsNames.includes(EntityUtil.toMinimalName(t.name).trim()));
                    if (newTraits != null && newTraits.length > 0) {
                        traitsNames.push(...newTraits.map((t) => EntityUtil.toMinimalName(t.name).trim()));
                        compendiumActorTraits.push(...newTraits);
                    }
                }
            }
            return Promise.resolve(compendiumActorTraits);
        });
    }
    static getCompendiumActorSkills() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const compendiumActorSkills = [];
            const skills = yield CompendiumUtil.getCompendiumSkills();
            const skillsNames = skills.map((t) => EntityUtil.toMinimalName(t.name).trim());
            const actorsMap = yield this.getActorsEntities();
            for (let [_key, actors] of Object.entries(actorsMap)) {
                for (let actor of actors) {
                    const data = actor.data;
                    const newSkills = (_a = data === null || data === void 0 ? void 0 : data.skills) === null || _a === void 0 ? void 0 : _a.filter((t) => !skillsNames.includes(EntityUtil.toMinimalName(t.name).trim()) &&
                        !t.name.trim().startsWith('('));
                    if (newSkills != null && newSkills.length > 0) {
                        skillsNames.push(...newSkills.map((t) => EntityUtil.toMinimalName(t.name).trim()));
                        compendiumActorSkills.push(...newSkills);
                    }
                }
            }
            return Promise.resolve(compendiumActorSkills);
        });
    }
    static getCompendiumActorTalents() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const compendiumActorTalents = [];
            const talents = yield CompendiumUtil.getCompendiumTalents();
            const talentsNames = talents.map((t) => EntityUtil.toMinimalName(t.name).trim());
            const actorsMap = yield this.getActorsEntities();
            for (let [_key, actors] of Object.entries(actorsMap)) {
                for (let actor of actors) {
                    const data = actor.data;
                    const newTalents = (_a = data === null || data === void 0 ? void 0 : data.talents) === null || _a === void 0 ? void 0 : _a.filter((t) => !talentsNames.includes(EntityUtil.toMinimalName(t.name).trim()) &&
                        !t.name.trim().startsWith('('));
                    if (newTalents != null && newTalents.length > 0) {
                        talentsNames.push(...newTalents.map((t) => EntityUtil.toMinimalName(t.name).trim()));
                        compendiumActorTalents.push(...newTalents);
                    }
                }
            }
            return Promise.resolve(compendiumActorTalents);
        });
    }
}
ReferentialUtil.sortedSize = [
    'tiny',
    'ltl',
    'sml',
    'avg',
    'lrg',
    'enor',
    'mnst',
];
//# sourceMappingURL=referential-util.js.map
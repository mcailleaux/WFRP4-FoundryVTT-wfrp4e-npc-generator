var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import StringUtil from './string-util.js';
import CompendiumUtil from './compendium-util.js';
import EntityUtil from './entity-util.js';
import { actors, i18n, items, wfrp4e, world } from '../constant.js';
import { origin, psychologyPrefix, randomTalent, randomTalents, speciesOrigin, speciesOthers, speciesSkills, subSpeciesOrigins, subSpeciesOthers, subSpeciesSkills, traitPrefix, } from '../referential/species-referential.js';
import WaiterUtil from './waiter-util.js';
export default class ReferentialUtil {
    static initReferential(callback, forCreatures = false) {
        return __awaiter(this, void 0, void 0, function* () {
            yield CompendiumUtil.initCompendium(() => __awaiter(this, void 0, void 0, function* () {
                if (!this.referentialLoaded || !this.creatureReferentialLoaded) {
                    yield WaiterUtil.show('WFRP4NPCGEN.compendium.load.title', 'WFRP4NPCGEN.compendium.load.hint', () => __awaiter(this, void 0, void 0, function* () {
                        if (forCreatures) {
                        }
                        else {
                            yield Promise.all([
                                this.getSpeciesSkillsMap(),
                                this.getSpeciesOthersMap(),
                                this.getRandomTalents(),
                            ]);
                            yield Promise.all([
                                this.getSubSpeciesSkillsMap(),
                                this.getSubSpeciesOthersMap(),
                                this.getSpeciesOriginsMap(),
                                this.getSubSpeciesOriginsMap(),
                            ]);
                        }
                        if (!this.referentialLoaded || !this.creatureReferentialLoaded) {
                            yield WaiterUtil.hide();
                        }
                        if (forCreatures) {
                            this.creatureReferentialLoaded = true;
                        }
                        else {
                            this.referentialLoaded = true;
                        }
                        callback();
                    }));
                }
                else {
                    callback();
                }
            }), forCreatures);
        });
    }
    static getClassTrappings() {
        const voClassTraping = wfrp4e().config
            .classTrappings;
        const resolvedClassTrapping = {};
        Object.entries(voClassTraping).forEach(([key]) => {
            let useKey = key;
            if (i18n().translations[useKey] == null && useKey.endsWith('s')) {
                useKey = useKey.substring(0, useKey.length - 1);
            }
            const localKey = i18n().localize(useKey);
            resolvedClassTrapping[localKey] = i18n().localize(`WFRP4NPCGEN.trappings.class.${key}`);
        });
        return resolvedClassTrapping;
    }
    static getClassKeyFromCareer(career) {
        var _a, _b;
        const careerClass = (_b = (_a = career.data) === null || _a === void 0 ? void 0 : _a.class) === null || _b === void 0 ? void 0 : _b.value;
        const keys = Object.keys(this.getClassTrappings());
        return keys.find((k) => StringUtil.includesDeburrIgnoreCase(k.trim(), careerClass === null || careerClass === void 0 ? void 0 : careerClass.trim()));
    }
    static getSpeciesMap() {
        return wfrp4e().config.species;
    }
    static getSubSpeciesMap() {
        const result = {};
        for (let [key, value] of Object.entries(wfrp4e().config.subspecies)) {
            for (let [subKey, subValue] of Object.entries(value)) {
                const content = {
                    name: subValue.name,
                    skills: subValue.skills != null
                        ? subValue.skills
                        : this.getOldSpeciesSkillsMap()[key],
                    talents: subValue.talents != null
                        ? subValue.talents
                        : this.getOldSpeciesTalentsMap()[key],
                };
                if (result[key] == null) {
                    result[key] = {};
                }
                result[key][subKey] = content;
            }
        }
        return result;
    }
    static getSpeciesSubSpeciesMap(speciesKey) {
        const subSpecies = this.getSubSpeciesMap();
        return subSpecies != null ? subSpecies[speciesKey] : null;
    }
    static getOldSpeciesSkillsMap() {
        return wfrp4e().config.speciesSkills;
    }
    static getOldSpeciesTalentsMap() {
        return wfrp4e().config.speciesTalents;
    }
    static getOldRandomTalents() {
        return wfrp4e().tables.talents.rows.map((row) => row.name);
    }
    static getWeaponTypes() {
        return {
            melee: i18n().localize('WFRP4NPCGEN.trappings.weapon.skill.melee'),
            ranged: i18n().localize('WFRP4NPCGEN.trappings.weapon.skill.ranged'),
        };
    }
    static getWeaponGroups() {
        return Object.values(wfrp4e().config.weaponGroups);
    }
    static getWeaponGroupsKey(group) {
        for (let key of Object.keys(wfrp4e().config.weaponGroups)) {
            if (StringUtil.equalsDeburrIgnoreCase(wfrp4e().config.weaponGroups[key], group)) {
                return key;
            }
        }
        return '';
    }
    static getMeleeWeaponGroups() {
        const groups = wfrp4e().config.weaponGroups;
        return [
            groups.basic,
            groups.brawling,
            groups.cavalry,
            groups.fencing,
            groups.flail,
            groups.parry,
            groups.polearm,
            groups.twohanded,
        ];
    }
    static getRangedWeaponGroups() {
        const groups = wfrp4e().config.weaponGroups;
        return [
            groups.blackpowder,
            groups.bow,
            groups.crossbow,
            groups.engineering,
            groups.entangling,
            groups.explosives,
            groups.sling,
            groups.throwing,
        ];
    }
    static getBasicWeaponGroups() {
        return wfrp4e().config.weaponGroups.basic;
    }
    static getCareerEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const careers = yield CompendiumUtil.getCompendiumCareers();
            if (withWorld) {
                const worldCareers = yield this.getWorldCareers();
                if (worldCareers != null && worldCareers.length > 0) {
                    careers.push(...worldCareers);
                }
            }
            return Promise.resolve(careers);
        });
    }
    static getCareerEntitieNames(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const names = (yield this.getCareerEntities(withWorld)).map((c) => { var _a; return (_a = c.name) !== null && _a !== void 0 ? _a : ''; });
            return Promise.resolve(names);
        });
    }
    static getWorldCareers() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const careersGroups = yield CompendiumUtil.getCompendiumCareersGroups();
            const worldCareers = (_b = (_a = items()) === null || _a === void 0 ? void 0 : _a.contents) === null || _b === void 0 ? void 0 : _b.filter((item) => {
                var _a, _b, _c;
                const group = (_c = (_b = (_a = item === null || item === void 0 ? void 0 : item.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.careergroup) === null || _c === void 0 ? void 0 : _c.value;
                return item.type === 'career' && !careersGroups.includes(group);
            });
            return Promise.resolve(worldCareers);
        });
    }
    static getWorldEntities(type) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const worldEntities = (_b = (_a = items()) === null || _a === void 0 ? void 0 : _a.contents) === null || _b === void 0 ? void 0 : _b.filter((item) => {
                return item.type === type;
            });
            return Promise.resolve(worldEntities);
        });
    }
    static getWorldActorEntities(type) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const worldEntities = (_a = actors()) === null || _a === void 0 ? void 0 : _a.filter((actor) => {
                var _a;
                return type != null ? ((_a = actor.data) === null || _a === void 0 ? void 0 : _a.type) === type : true;
            });
            return Promise.resolve(worldEntities);
        });
    }
    static getTrappingEntities(withWorld = true) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const trappings = yield CompendiumUtil.getCompendiumTrappings();
            const finalTrappings = [];
            if (withWorld) {
                const trappingCategories = CompendiumUtil.getTrappingCategories();
                const worldTrappings = (_b = (_a = items()) === null || _a === void 0 ? void 0 : _a.contents) === null || _b === void 0 ? void 0 : _b.filter((item) => {
                    var _a, _b, _c;
                    return trappingCategories.includes(item.type) ||
                        trappingCategories.includes((_c = (_b = (_a = item === null || item === void 0 ? void 0 : item.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.trappingType) === null || _c === void 0 ? void 0 : _c.value);
                });
                if (worldTrappings != null && worldTrappings.length > 0) {
                    finalTrappings.push(...worldTrappings);
                }
            }
            finalTrappings.push(...trappings);
            return Promise.resolve(finalTrappings);
        });
    }
    static getRandomSpeciesCareers(speciesKey, subSpeciesKey) {
        return __awaiter(this, void 0, void 0, function* () {
            if (speciesKey == null) {
                return [];
            }
            const concatKey = subSpeciesKey != null ? `${speciesKey}-${subSpeciesKey}` : speciesKey;
            const humanDefaultKey = 'human-reiklander';
            const randomCareers = wfrp4e()
                .tables.career.rows.filter((row) => {
                var _a, _b, _c;
                let result = ((_a = row === null || row === void 0 ? void 0 : row.range[concatKey]) === null || _a === void 0 ? void 0 : _a.length) > 0;
                if (!result) {
                    result = ((_b = row === null || row === void 0 ? void 0 : row.range[speciesKey]) === null || _b === void 0 ? void 0 : _b.length) > 0;
                }
                if (!result && speciesKey === 'human') {
                    result = ((_c = row === null || row === void 0 ? void 0 : row.range[humanDefaultKey]) === null || _c === void 0 ? void 0 : _c.length) > 0;
                }
                return result;
            })
                .map((row) => {
                var _a, _b, _c;
                let result = (_a = row[concatKey]) === null || _a === void 0 ? void 0 : _a.name;
                if (result == null) {
                    result = (_b = row[speciesKey]) === null || _b === void 0 ? void 0 : _b.name;
                }
                if (result == null && speciesKey === 'human') {
                    result = (_c = row[humanDefaultKey]) === null || _c === void 0 ? void 0 : _c.name;
                }
                return result;
            });
            const careers = yield this.getCareerEntities(false);
            const result = [];
            randomCareers.forEach((rc) => {
                let cs = careers.filter((c) => {
                    var _a, _b, _c;
                    return StringUtil.includesDeburrIgnoreCase((_c = (_b = (_a = c.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.careergroup) === null || _c === void 0 ? void 0 : _c.value, rc);
                });
                if (cs.length !== 4) {
                    const strictCareer = careers.find((c) => { var _a; return StringUtil.equalsDeburrIgnoreCase((_a = c.name) !== null && _a !== void 0 ? _a : '', rc); });
                    if (strictCareer != null) {
                        cs = careers.filter((c) => {
                            var _a, _b, _c, _d, _e, _f;
                            return StringUtil.equalsDeburrIgnoreCase((_c = (_b = (_a = c.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.careergroup) === null || _c === void 0 ? void 0 : _c.value, (_f = (_e = (_d = strictCareer.data) === null || _d === void 0 ? void 0 : _d.data) === null || _e === void 0 ? void 0 : _e.careergroup) === null || _f === void 0 ? void 0 : _f.value);
                        });
                    }
                }
                if (cs.length === 4) {
                    result.push(...cs.map((c) => { var _a; return (_a = c.name) !== null && _a !== void 0 ? _a : ''; }));
                }
            });
            return Promise.resolve(result);
        });
    }
    static getStatusTiers() {
        return wfrp4e().config.statusTiers;
    }
    static getAllBasicSkills() {
        return __awaiter(this, void 0, void 0, function* () {
            return yield wfrp4e().utility.allBasicSkills();
        });
    }
    static findSkill(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const skills = [
                ...(yield this.getWorldEntities('skill')),
                ...(yield this.getSkillEntities(false)),
            ];
            const skill = EntityUtil.find(name, skills.map((i) => i.data));
            if (skill == null) {
                throw ('Could not find skill (or specialization of) ' +
                    name +
                    ' in compendum or world');
            }
            return skill;
        });
    }
    static findTalent(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const talents = [
                ...(yield this.getWorldEntities('talent')),
                ...(yield this.getTalentEntities(false)),
            ];
            const talent = EntityUtil.find(name, talents.map((i) => i.data));
            if (talent == null) {
                throw ('Could not find talent (or specialization of) ' +
                    name +
                    ' in compendum or world');
            }
            return talent;
        });
    }
    static findPsychology(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const psychologies = [
                ...(yield this.getWorldEntities('psychology')),
                ...(yield this.getPsychologyEntities(false)),
            ];
            const psychology = EntityUtil.find(name, psychologies.map((i) => i.data));
            if (psychology == null) {
                throw ('Could not find psychology (or specialization of) ' +
                    name +
                    ' in compendum or world');
            }
            return psychology;
        });
    }
    static findTrait(name, onlyRefTrait = false) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            const traits = [
                ...(yield this.getWorldEntities('trait')),
                ...(yield this.getTraitEntities(false)),
            ];
            const trait = EntityUtil.find(name, traits.map((i) => i.data));
            if (trait == null) {
                throw ('Could not find trait (or specialization of) ' +
                    name +
                    ' in compendum or world');
            }
            if (onlyRefTrait) {
                return trait;
            }
            if (name.includes('(') && name.includes(')')) {
                const simpleName = StringUtil.getSimpleName((_a = trait.name) !== null && _a !== void 0 ? _a : name);
                const groupedName = (_c = StringUtil.getGroupName((_b = trait.name) !== null && _b !== void 0 ? _b : name)) !== null && _c !== void 0 ? _c : StringUtil.getGroupName(name);
                trait.name = simpleName;
                trait.data.specification.value = groupedName;
            }
            else {
                if (trait.name == null) {
                    trait.name = name;
                }
                trait.DisplayName = trait.name;
            }
            return trait;
        });
    }
    static findTrappings(name, referentialTrappings) {
        return __awaiter(this, void 0, void 0, function* () {
            let searchName = StringUtil.toDeburrLowerCase(name);
            const trappings = [];
            let trapping = yield this.findTrapping(searchName, referentialTrappings);
            while (trapping != null) {
                trappings.push(trapping);
                const lastSearch = searchName;
                searchName = searchName
                    .replace(StringUtil.toDeburrLowerCase(trapping.name.trim()), '')
                    .replace('(', '')
                    .replace(')', '')
                    .trim();
                if (searchName === lastSearch) {
                    const simpleName = searchName.includes('(') && searchName.includes(')')
                        ? searchName.substring(0, searchName.indexOf('(')).trim()
                        : searchName;
                    if (simpleName !== searchName) {
                        searchName = searchName
                            .replace(StringUtil.toDeburrLowerCase(simpleName), '')
                            .replace('(', '')
                            .replace(')', '')
                            .trim();
                    }
                }
                if (searchName === lastSearch) {
                    const words = trapping.name
                        .trim()
                        .split(' ')
                        .map((word) => word.trim())
                        .filter((word) => word.length > 3);
                    for (let word of words) {
                        searchName = searchName
                            .replace(StringUtil.toDeburrLowerCase(word), '')
                            .trim();
                    }
                }
                if (searchName.length > 3 && lastSearch !== searchName) {
                    trapping = yield this.findTrapping(searchName, referentialTrappings);
                }
                else {
                    trapping = null;
                }
            }
            if (searchName.trim().includes(' ')) {
                trappings.push(...(yield this.findTrappingsByWords(searchName, referentialTrappings)));
            }
            return Promise.resolve(trappings);
        });
    }
    static findTrappingsByWords(name, referentialTrappings) {
        return __awaiter(this, void 0, void 0, function* () {
            const trappings = [];
            if (name != null && name.length > 0) {
                const words = name
                    .split(' ')
                    .map((word) => word.trim())
                    .map((word) => word.replace('(', '').replace(')', ''))
                    .filter((word) => word.length > 3);
                for (let word of words) {
                    const trapping = yield this.findTrapping(word, referentialTrappings, true);
                    if (trapping != null) {
                        trappings.push(trapping);
                    }
                }
            }
            return trappings;
        });
    }
    static findTrapping(name, referentialTrappings, fromWord = false) {
        var _a, _b, _c, _d, _e;
        return __awaiter(this, void 0, void 0, function* () {
            const searchTrappings = referentialTrappings !== null && referentialTrappings !== void 0 ? referentialTrappings : (yield this.getTrappingEntities(true));
            const simpleName = name.includes('(') && name.includes(')')
                ? name.substring(0, name.indexOf('(')).trim()
                : name;
            let trapping = (_c = (_b = (_a = searchTrappings.find((t) => { var _a; return StringUtil.equalsDeburrIgnoreCase(name, (_a = t.name) !== null && _a !== void 0 ? _a : ''); })) !== null && _a !== void 0 ? _a : searchTrappings.find((t) => { var _a; return StringUtil.equalsDeburrIgnoreCase((_a = t.name) !== null && _a !== void 0 ? _a : '', simpleName); })) !== null && _b !== void 0 ? _b : searchTrappings.find((t) => { var _a; return StringUtil.includesDeburrIgnoreCase((_a = t.name) !== null && _a !== void 0 ? _a : '', name); })) !== null && _c !== void 0 ? _c : searchTrappings.find((t) => { var _a; return StringUtil.includesDeburrIgnoreCase((_a = t.name) !== null && _a !== void 0 ? _a : '', simpleName); });
            if (trapping == null && !fromWord) {
                trapping = searchTrappings
                    .sort((t1, t2) => {
                    var _a, _b;
                    return ((_a = t2.name) !== null && _a !== void 0 ? _a : '').length - ((_b = t1.name) !== null && _b !== void 0 ? _b : '').length;
                })
                    .find((t) => { var _a; return StringUtil.includesDeburrIgnoreCase(name, (_a = t.name) !== null && _a !== void 0 ? _a : ''); });
            }
            if (trapping == null) {
                console.warn(`Can't find trapping ${name}${simpleName !== name ? `or ${simpleName}` : ''}`);
            }
            else if (!StringUtil.equalsDeburrIgnoreCase((_d = trapping.name) !== null && _d !== void 0 ? _d : '', name)) {
                console.warn(`Trapping ${name} is resolved by ${trapping.name}`);
            }
            return Promise.resolve((_e = trapping === null || trapping === void 0 ? void 0 : trapping.data) !== null && _e !== void 0 ? _e : null);
        });
    }
    static getSpeciesCharacteristics(speciesKey) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield wfrp4e().utility.speciesCharacteristics(speciesKey, true);
        });
    }
    static getSpeciesMovement(speciesKey) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield wfrp4e().utility.speciesMovement(speciesKey);
        });
    }
    static getAllMoneyItems() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            let moneyItems = (_a = (yield wfrp4e().utility.allMoneyItems())) !== null && _a !== void 0 ? _a : [];
            moneyItems = moneyItems
                .map((mi) => {
                mi.data.quantity.value = 0;
                return mi;
            })
                .sort((a, b) => {
                const aData = a.data;
                const bData = b.data;
                return aData.coinValue.value > bData.coinValue.value ? -1 : 1;
            });
            return Promise.resolve(moneyItems);
        });
    }
    static getActorsEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const actors = yield CompendiumUtil.getCompendiumActors();
            if (withWorld) {
                const worldActors = yield this.getWorldActorEntities();
                if (worldActors != null && worldActors.length > 0) {
                    actors[world().title] = worldActors;
                }
            }
            return Promise.resolve(actors);
        });
    }
    static getBestiaryEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const bestiary = yield CompendiumUtil.getCompendiumBestiary();
            if (withWorld) {
                const worldActors = yield this.getWorldActorEntities('creature');
                if (worldActors != null && worldActors.length > 0) {
                    bestiary[world().title] = worldActors;
                }
            }
            return Promise.resolve(bestiary);
        });
    }
    static getSkillEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const skills = yield CompendiumUtil.getCompendiumSkills();
            if (withWorld) {
                const worldSkills = yield this.getWorldEntities('skill');
                if (worldSkills != null && worldSkills.length > 0) {
                    skills.push(...worldSkills);
                }
            }
            return Promise.resolve(skills);
        });
    }
    static getTalentEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const talents = yield CompendiumUtil.getCompendiumTalents();
            if (withWorld) {
                const worldTalents = yield this.getWorldEntities('talent');
                if (worldTalents != null && worldTalents.length > 0) {
                    talents.push(...worldTalents);
                }
            }
            return Promise.resolve(talents);
        });
    }
    static getPsychologyEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const psychologies = yield CompendiumUtil.getCompendiumPsychologies();
            if (withWorld) {
                const worldPsychologies = yield this.getWorldEntities('psychology');
                if (worldPsychologies != null && worldPsychologies.length > 0) {
                    psychologies.push(...worldPsychologies);
                }
            }
            return Promise.resolve(psychologies);
        });
    }
    static getTraitEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const traits = yield CompendiumUtil.getCompendiumTraits();
            if (withWorld) {
                const worldTraits = yield this.getWorldEntities('trait');
                if (worldTraits != null && worldTraits.length > 0) {
                    traits.push(...worldTraits);
                }
            }
            return Promise.resolve(traits);
        });
    }
    static getSpellEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const spells = yield CompendiumUtil.getCompendiumSpells();
            if (withWorld) {
                const worldSpells = yield this.getWorldEntities('spell');
                if (worldSpells != null && worldSpells.length > 0) {
                    spells.push(...worldSpells);
                }
            }
            return Promise.resolve(spells);
        });
    }
    static getPrayerEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const prayers = yield CompendiumUtil.getCompendiumPrayers();
            if (withWorld) {
                const worldPrayers = yield this.getWorldEntities('prayer');
                if (worldPrayers != null && worldPrayers.length > 0) {
                    prayers.push(...worldPrayers);
                }
            }
            return Promise.resolve(prayers);
        });
    }
    static getPhysicalMutationEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const physicalMutations = yield CompendiumUtil.getCompendiumPhysicalMutations();
            if (withWorld) {
                const worldPrayers = yield this.getWorldEntities('mutation');
                if (worldPrayers != null && worldPrayers.length > 0) {
                    physicalMutations.push(...worldPrayers.filter((m) => m.data.data.mutationType.value === 'physical'));
                }
            }
            return Promise.resolve(physicalMutations);
        });
    }
    static getMentalMutationEntities(withWorld = true) {
        return __awaiter(this, void 0, void 0, function* () {
            const mentalMutations = yield CompendiumUtil.getCompendiumMentalMutations();
            if (withWorld) {
                const worldPrayers = yield this.getWorldEntities('mutation');
                if (worldPrayers != null && worldPrayers.length > 0) {
                    mentalMutations.push(...worldPrayers.filter((m) => m.data.data.mutationType.value === 'mental'));
                }
            }
            return Promise.resolve(mentalMutations);
        });
    }
    static getCompendiumActorTraits() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const compendiumActorTraits = [];
            const traits = yield CompendiumUtil.getCompendiumTraits();
            const traitsNames = traits.map((t) => { var _a; return EntityUtil.toMinimalName((_a = t.name) !== null && _a !== void 0 ? _a : '').trim(); });
            const actorsMap = yield this.getActorsEntities();
            for (let [_key, actors] of Object.entries(actorsMap)) {
                for (let actor of actors) {
                    const data = actor.data;
                    const newTraits = (_a = data === null || data === void 0 ? void 0 : data.traits) === null || _a === void 0 ? void 0 : _a.filter((t) => !traitsNames.includes(EntityUtil.toMinimalName(t.name).trim()));
                    if (newTraits != null && newTraits.length > 0) {
                        traitsNames.push(...newTraits.map((t) => EntityUtil.toMinimalName(t.name).trim()));
                        compendiumActorTraits.push(...newTraits);
                    }
                }
            }
            return Promise.resolve(compendiumActorTraits);
        });
    }
    static getCompendiumActorSkills() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const compendiumActorSkills = [];
            const skills = yield CompendiumUtil.getCompendiumSkills();
            const skillsNames = skills.map((t) => { var _a; return EntityUtil.toMinimalName((_a = t.name) !== null && _a !== void 0 ? _a : '').trim(); });
            const actorsMap = yield this.getActorsEntities();
            for (let [_key, actors] of Object.entries(actorsMap)) {
                for (let actor of actors) {
                    const data = actor.data;
                    const newSkills = (_a = data === null || data === void 0 ? void 0 : data.skills) === null || _a === void 0 ? void 0 : _a.filter((t) => !skillsNames.includes(EntityUtil.toMinimalName(t.name).trim()) &&
                        !t.name.trim().startsWith('('));
                    if (newSkills != null && newSkills.length > 0) {
                        skillsNames.push(...newSkills.map((t) => EntityUtil.toMinimalName(t.name).trim()));
                        compendiumActorSkills.push(...newSkills);
                    }
                }
            }
            return Promise.resolve(compendiumActorSkills);
        });
    }
    static getCompendiumActorTalents() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const compendiumActorTalents = [];
            const talents = yield CompendiumUtil.getCompendiumTalents();
            const talentsNames = talents.map((t) => { var _a; return EntityUtil.toMinimalName((_a = t.name) !== null && _a !== void 0 ? _a : '').trim(); });
            const actorsMap = yield this.getActorsEntities();
            for (let [_key, actors] of Object.entries(actorsMap)) {
                for (let actor of actors) {
                    const data = actor.data;
                    const newTalents = (_a = data === null || data === void 0 ? void 0 : data.talents) === null || _a === void 0 ? void 0 : _a.filter((t) => !talentsNames.includes(EntityUtil.toMinimalName(t.name).trim()) &&
                        !t.name.trim().startsWith('('));
                    if (newTalents != null && newTalents.length > 0) {
                        talentsNames.push(...newTalents.map((t) => EntityUtil.toMinimalName(t.name).trim()));
                        compendiumActorTalents.push(...newTalents);
                    }
                }
            }
            return Promise.resolve(compendiumActorTalents);
        });
    }
    static getSpeciesSkillsMap() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.speciesSkillsMap == null) {
                this.speciesSkillsMap = {};
                const coreMap = wfrp4e().config.speciesSkills;
                for (let key of Object.keys(coreMap)) {
                    const moduleSkills = speciesSkills[key];
                    if (moduleSkills == null) {
                        console.warn(`Cant find fixed species skills map for ${key}`);
                    }
                    const skills = moduleSkills != null ? moduleSkills : coreMap[key];
                    for (let skill of skills) {
                        try {
                            const refSkill = yield ReferentialUtil.findSkill(skill);
                            if (refSkill != null) {
                                if (this.speciesSkillsMap[key] == null) {
                                    this.speciesSkillsMap[key] = [];
                                }
                                this.speciesSkillsMap[key].push(refSkill.name);
                            }
                        }
                        catch (e) {
                            console.warn(`Cant find Species ${key} Skill: ${skill}`);
                        }
                    }
                }
            }
            return Promise.resolve(this.speciesSkillsMap);
        });
    }
    static getSpeciesSkills(key) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve((_a = (yield this.getSpeciesSkillsMap())[key]) !== null && _a !== void 0 ? _a : []);
        });
    }
    static getSubSpeciesSkillsMap() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            if (this.subSpeciesSkillsMap == null) {
                this.subSpeciesSkillsMap = {};
                const coreMap = wfrp4e().config.subspecies;
                for (let key of Object.keys(coreMap)) {
                    for (let subKey of Object.keys(coreMap[key])) {
                        const moduleSkills = subSpeciesSkills[key] != null
                            ? subSpeciesSkills[key][subKey]
                            : null;
                        if (moduleSkills == null) {
                            console.warn(`Cant find fixed sub species skills map for ${key} - ${subKey}`);
                        }
                        const coreSkills = (_b = (_a = coreMap[key][subKey].skills) !== null && _a !== void 0 ? _a : speciesSkills[key]) !== null && _b !== void 0 ? _b : wfrp4e().config.speciesSkills[key];
                        const skills = moduleSkills != null ? moduleSkills : coreSkills;
                        for (let skill of skills) {
                            try {
                                const refSkill = yield ReferentialUtil.findSkill(skill);
                                if (refSkill != null) {
                                    if (this.subSpeciesSkillsMap[key] == null) {
                                        this.subSpeciesSkillsMap[key] = {};
                                    }
                                    if (this.subSpeciesSkillsMap[key][subKey] == null) {
                                        this.subSpeciesSkillsMap[key][subKey] = [];
                                    }
                                    this.subSpeciesSkillsMap[key][subKey].push(refSkill.name);
                                }
                            }
                            catch (e) {
                                console.warn(`Cant find sub Species ${key} - ${subKey} Skill: ${skill}`);
                            }
                        }
                    }
                }
            }
            return Promise.resolve(this.subSpeciesSkillsMap);
        });
    }
    static getSubSpeciesSkills(key, subKey) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve((_a = (yield this.getSubSpeciesSkillsMap())[key][subKey]) !== null && _a !== void 0 ? _a : []);
        });
    }
    static getSpeciesOthersMap() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.speciesOthersMap == null) {
                this.speciesOthersMap = {};
                yield this.initSpeciesEntities(this.speciesOthersMap, wfrp4e().config.speciesTalents, speciesOthers, 'Talent');
            }
            return Promise.resolve(this.speciesOthersMap);
        });
    }
    static getSpeciesOthers(key, onlyToChoose = false, onlyAuto = false) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve((_b = (_a = (yield this.getSpeciesOthersMap())[key]) === null || _a === void 0 ? void 0 : _a.filter(this.speciesRefFilter(onlyToChoose, onlyAuto))) !== null && _b !== void 0 ? _b : []);
        });
    }
    static getSubSpeciesOthersMap() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.subSpeciesOthersMap == null) {
                this.subSpeciesOthersMap = {};
                for (let key of Object.keys(this.getSpeciesMap())) {
                    if (wfrp4e().config.subspecies[key] != null) {
                        const coreMap = {};
                        for (let subKey of Object.keys(wfrp4e().config.subspecies[key])) {
                            if (wfrp4e().config.subspecies[key][subKey].talents != null) {
                                coreMap[subKey] = wfrp4e().config.subspecies[key][subKey].talents;
                            }
                            else {
                                coreMap[subKey] = yield this.getSpeciesOthers(key);
                            }
                        }
                        const currentSubSpeciesMap = {};
                        yield this.initSpeciesEntities(currentSubSpeciesMap, coreMap, subSpeciesOthers[key], 'Talent');
                        this.subSpeciesOthersMap[key] = currentSubSpeciesMap;
                    }
                }
            }
            return Promise.resolve(this.subSpeciesOthersMap);
        });
    }
    static getSubSpeciesOthers(key, subKey, onlyToChoose = false, onlyAuto = false) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve((_b = (_a = (yield this.getSubSpeciesOthersMap())[key][subKey]) === null || _a === void 0 ? void 0 : _a.filter(this.speciesRefFilter(onlyToChoose, onlyAuto))) !== null && _b !== void 0 ? _b : []);
        });
    }
    static getSubSpeciesNamesMap() {
        if (this.subSpeciesNamesMap == null) {
            this.subSpeciesNamesMap = {};
            const coreMap = wfrp4e().config.subspecies;
            for (let key of Object.keys(coreMap)) {
                this.subSpeciesNamesMap[key] = {};
                for (let subKey of Object.keys(coreMap[key])) {
                    this.subSpeciesNamesMap[key][subKey] = coreMap[key][subKey].name;
                }
            }
        }
        return this.subSpeciesNamesMap;
    }
    static getSubSpeciesNames(key, subKey) {
        var _a;
        return (_a = this.getSubSpeciesNamesMap()[key][subKey]) !== null && _a !== void 0 ? _a : '';
    }
    static getSpeciesOriginsMap() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.speciesOriginsMap == null) {
                this.speciesOriginsMap = {};
                for (let key of Object.keys(this.getSpeciesMap())) {
                    if (speciesOrigin[key] != null) {
                        const currentOriginsMap = {};
                        yield this.initSpeciesEntities(currentOriginsMap, speciesOrigin[key], speciesOrigin[key], 'Origin');
                        this.speciesOriginsMap[key] = currentOriginsMap;
                    }
                }
            }
            return Promise.resolve(this.speciesOriginsMap);
        });
    }
    static getSpeciesOrigins(key, onlyToChoose = false, onlyAuto = false) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            const map = (_a = (yield this.getSpeciesOriginsMap())[key]) !== null && _a !== void 0 ? _a : {};
            const result = {};
            for (let origin of Object.keys(map)) {
                result[origin] =
                    (_c = (_b = map[origin]) === null || _b === void 0 ? void 0 : _b.filter(this.speciesRefFilter(onlyToChoose, onlyAuto))) !== null && _c !== void 0 ? _c : [];
            }
            return Promise.resolve(result);
        });
    }
    static getSpeciesOrigin(key, origin, onlyToChoose = false, onlyAuto = false) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve((_b = (_a = (yield this.getSpeciesOriginsMap())[key][origin]) === null || _a === void 0 ? void 0 : _a.filter(this.speciesRefFilter(onlyToChoose, onlyAuto))) !== null && _b !== void 0 ? _b : []);
        });
    }
    static getSubSpeciesOriginsMap() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.subSpeciesOriginsMap == null) {
                this.subSpeciesOriginsMap = {};
                for (let key of Object.keys(this.getSpeciesMap())) {
                    if (subSpeciesOrigins[key] != null) {
                        for (let subKey of Object.keys(wfrp4e().config.subspecies[key])) {
                            if (subSpeciesOrigins[key][subKey] != null) {
                                const currentOriginsMap = {};
                                yield this.initSpeciesEntities(currentOriginsMap, subSpeciesOrigins[key][subKey], subSpeciesOrigins[key][subKey], 'Origin');
                                if (this.subSpeciesOriginsMap[key] == null) {
                                    this.subSpeciesOriginsMap[key] = {};
                                }
                                this.subSpeciesOriginsMap[key][subKey] = currentOriginsMap;
                            }
                        }
                    }
                    else {
                        this.subSpeciesOriginsMap[key] = {};
                    }
                }
            }
            return Promise.resolve(this.subSpeciesOriginsMap);
        });
    }
    static getSubSpeciesOrigins(key, subKey, onlyToChoose = false, onlyAuto = false) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            const originMap = yield this.getSubSpeciesOriginsMap();
            const map = (_a = (originMap[key] != null ? originMap[key][subKey] : {})) !== null && _a !== void 0 ? _a : {};
            const result = {};
            for (let origin of Object.keys(map)) {
                result[origin] =
                    (_c = (_b = map[origin]) === null || _b === void 0 ? void 0 : _b.filter(this.speciesRefFilter(onlyToChoose, onlyAuto))) !== null && _c !== void 0 ? _c : [];
            }
            return Promise.resolve(result);
        });
    }
    static getSubSpeciesOrigin(key, subKey, origin, onlyToChoose = false, onlyAuto = false) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve((_b = (_a = (yield this.getSubSpeciesOriginsMap())[key][subKey][origin]) === null || _a === void 0 ? void 0 : _a.filter(this.speciesRefFilter(onlyToChoose, onlyAuto))) !== null && _b !== void 0 ? _b : []);
        });
    }
    static getRandomTalents() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.randomTalents == null) {
                this.randomTalents = [];
                for (let talent of randomTalents) {
                    try {
                        const refTalent = yield this.findTalent(talent);
                        this.randomTalents.push(refTalent.name);
                    }
                    catch (e) {
                        console.warn(`Cant find Random Talent : ${talent}`);
                    }
                }
            }
            return Promise.resolve(this.randomTalents);
        });
    }
    static initSpeciesEntities(targetMap, coreMap, moduleMap, logType, onlyModule = false) {
        return __awaiter(this, void 0, void 0, function* () {
            for (let key of Object.keys(coreMap)) {
                const moduleEntities = moduleMap[key];
                if (moduleEntities == null) {
                    console.warn(`Cant find fixed sub species ${logType} map for ${key}`);
                    if (onlyModule) {
                        continue;
                    }
                }
                const entities = moduleEntities != null ? moduleEntities : coreMap[key];
                for (let entity of entities) {
                    const isNumber = typeof entity === 'number';
                    const search = isNumber ? null : this.resolveSearch(entity);
                    const finalEntity = isNumber ? entity : this.resolveName(entity);
                    const prefix = isNumber ? '' : this.resolvePrefix(entity);
                    try {
                        if (isNumber) {
                            if (targetMap[key] == null) {
                                targetMap[key] = [];
                            }
                            targetMap[key].push(finalEntity);
                        }
                        else if (finalEntity.includes(',')) {
                            const multiEntities = finalEntity.split(',').map((t) => t.trim());
                            let finalMultiEntity = '';
                            for (let multiEntity of multiEntities) {
                                const multiSearch = this.resolveSearch(multiEntity);
                                const multiFinalEntity = this.resolveName(multiEntity);
                                const multiPrefix = this.resolvePrefix(multiEntity);
                                const refEntity = multiSearch != null
                                    ? yield multiSearch(multiFinalEntity)
                                    : null;
                                if (refEntity != null) {
                                    if (finalMultiEntity.length > 0) {
                                        finalMultiEntity += ', ';
                                    }
                                    finalMultiEntity += `${multiPrefix}${refEntity.name}`;
                                }
                                if (refEntity == null && multiPrefix.length > 0) {
                                    if (finalMultiEntity.length > 0) {
                                        finalMultiEntity += ', ';
                                    }
                                    finalMultiEntity += `${multiEntity}`;
                                }
                            }
                            if (finalMultiEntity.length > 0) {
                                if (targetMap[key] == null) {
                                    targetMap[key] = [];
                                }
                                targetMap[key].push(finalMultiEntity);
                            }
                        }
                        else if (search == null && prefix.length > 0) {
                            targetMap[key].push(entity);
                        }
                        else {
                            const refTalent = search != null ? yield search(finalEntity) : null;
                            if (refTalent != null) {
                                if (targetMap[key] == null) {
                                    targetMap[key] = [];
                                }
                                targetMap[key].push(`${prefix}${refTalent.name}`);
                            }
                        }
                    }
                    catch (e) {
                        console.warn(`Cant find Species ${key} ${logType}: ${entity}`);
                    }
                }
            }
        });
    }
    static resolveName(name) {
        if (name === null || name === void 0 ? void 0 : name.startsWith(traitPrefix)) {
            return name.replace(traitPrefix, '');
        }
        else if (name === null || name === void 0 ? void 0 : name.startsWith(psychologyPrefix)) {
            return name.replace(psychologyPrefix, '');
        }
        return name;
    }
    static resolveRandomPrefix(name) {
        if (!name.startsWith(randomTalent)) {
            return 0;
        }
        return Number(name.replace(randomTalent, ''));
    }
    static resolvePrefix(name) {
        if (name === null || name === void 0 ? void 0 : name.startsWith(traitPrefix)) {
            return traitPrefix;
        }
        else if (name === null || name === void 0 ? void 0 : name.startsWith(psychologyPrefix)) {
            return psychologyPrefix;
        }
        else if (name === null || name === void 0 ? void 0 : name.startsWith(randomTalent)) {
            return randomTalent;
        }
        else if (name === null || name === void 0 ? void 0 : name.startsWith(origin)) {
            return origin;
        }
        return '';
    }
    static resolveSearch(name) {
        if (name === null || name === void 0 ? void 0 : name.startsWith(traitPrefix)) {
            return (searchValue) => this.findTrait(searchValue, true);
        }
        else if (name === null || name === void 0 ? void 0 : name.startsWith(psychologyPrefix)) {
            return (searchValue) => this.findPsychology(searchValue);
        }
        else if ((name === null || name === void 0 ? void 0 : name.startsWith(randomTalent)) || (name === null || name === void 0 ? void 0 : name.startsWith(origin))) {
            return null;
        }
        return (searchValue) => this.findTalent(searchValue);
    }
    static speciesRefFilter(onlyToChoose, onlyAuto) {
        return (sso) => {
            const strSoo = String(sso);
            const toChooseCondition = typeof sso === 'number' || strSoo.includes(',') || sso === origin;
            if (onlyToChoose) {
                return toChooseCondition;
            }
            else if (onlyAuto) {
                return !toChooseCondition;
            }
            return true;
        };
    }
}
ReferentialUtil.sortedSize = [
    'tiny',
    'ltl',
    'sml',
    'avg',
    'lrg',
    'enor',
    'mnst',
];
ReferentialUtil.referentialLoaded = false;
ReferentialUtil.creatureReferentialLoaded = false;
//# sourceMappingURL=referential-util.js.map
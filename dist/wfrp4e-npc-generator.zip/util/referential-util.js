var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import StringUtil from './string-util.js';
import CompendiumUtil from './compendium-util.js';
export default class ReferentialUtil {
    static getClassTrappings() {
        const voClassTraping = game.wfrp4e.config.classTrappings;
        const resolvedClassTrapping = {};
        Object.entries(voClassTraping).forEach(([key]) => {
            let useKey = key;
            if (game.i18n.translations[useKey] == null &&
                useKey.endsWith('s')) {
                useKey = useKey.substring(0, useKey.length - 1);
            }
            const localKey = game.i18n.localize(useKey);
            resolvedClassTrapping[localKey] = game.i18n.localize(`WFRP4NPCGEN.trappings.class.${key}`);
        });
        return resolvedClassTrapping;
    }
    static getClassKeyFromCareer(career) {
        var _a, _b;
        const careerClass = (_b = (_a = career.data) === null || _a === void 0 ? void 0 : _a.class) === null || _b === void 0 ? void 0 : _b.value;
        const keys = Object.keys(this.getClassTrappings());
        return keys.find((k) => StringUtil.includesDeburrIgnoreCase(k.trim(), careerClass === null || careerClass === void 0 ? void 0 : careerClass.trim()));
    }
    static getTrappingCategories() {
        return Object.keys(game.wfrp4e.config.trappingCategories);
    }
    static getSpeciesMap() {
        return game.wfrp4e.config.species;
    }
    static getSpeciesSkillsMap() {
        return game.wfrp4e.config.speciesSkills;
    }
    static getSpeciesTalentsMap() {
        return game.wfrp4e.config.speciesTalents;
    }
    static getRandomTalents() {
        return game.wfrp4e.tables.talents.rows.map((row) => row.name);
    }
    static getWeaponTypes() {
        return {
            melee: game.i18n.localize('WFRP4NPCGEN.trappings.weapon.skill.melee'),
            ranged: game.i18n.localize('WFRP4NPCGEN.trappings.weapon.skill.ranged'),
        };
    }
    static getWeaponGroups() {
        return Object.values(game.wfrp4e.config.weaponGroups);
    }
    static getWeaponGroupsKey(group) {
        for (let key of Object.keys(game.wfrp4e.config.weaponGroups)) {
            if (StringUtil.equalsDeburrIgnoreCase(game.wfrp4e.config.weaponGroups[key], group)) {
                return key;
            }
        }
        return '';
    }
    static getMeleeWeaponGroups() {
        const groups = game.wfrp4e.config.weaponGroups;
        return [
            groups.basic,
            groups.brawling,
            groups.cavalry,
            groups.fencing,
            groups.flail,
            groups.parry,
            groups.polearm,
            groups.twohanded,
        ];
    }
    static getRangedWeaponGroups() {
        const groups = game.wfrp4e.config.weaponGroups;
        return [
            groups.blackpowder,
            groups.bow,
            groups.crossbow,
            groups.engineering,
            groups.entangling,
            groups.explosives,
            groups.sling,
            groups.throwing,
        ];
    }
    static getBasicWeaponGroups() {
        return game.wfrp4e.config.weaponGroups.basic;
    }
    static getCareerIndexes() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const careers = yield CompendiumUtil.getCompendiumCareerIndexes();
            const worldCareers = (_b = (_a = game.items) === null || _a === void 0 ? void 0 : _a.entities) === null || _b === void 0 ? void 0 : _b.filter((item) => item.type === 'career');
            if (worldCareers != null && worldCareers.length > 0) {
                careers.push(...worldCareers);
            }
            return Promise.resolve(careers);
        });
    }
    static getCareerEntities(withWorld = true) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const careers = yield CompendiumUtil.getCompendiumCareers();
            if (withWorld) {
                const worldCareers = (_b = (_a = game.items) === null || _a === void 0 ? void 0 : _a.entities) === null || _b === void 0 ? void 0 : _b.filter((item) => item.type === 'career');
                if (worldCareers != null && worldCareers.length > 0) {
                    careers.push(...worldCareers);
                }
            }
            return Promise.resolve(careers);
        });
    }
    static getTrappingEntities(withWorld = true) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const trappings = yield CompendiumUtil.getCompendiumTrappings();
            if (withWorld) {
                const trappingCategories = this.getTrappingCategories();
                const worldTrappings = (_b = (_a = game.items) === null || _a === void 0 ? void 0 : _a.entities) === null || _b === void 0 ? void 0 : _b.filter((item) => trappingCategories.includes(item.type));
                if (worldTrappings != null && worldTrappings.length > 0) {
                    trappings.push(...worldTrappings);
                }
            }
            return Promise.resolve(trappings);
        });
    }
    static getRandomSpeciesCareers(speciesKey) {
        return __awaiter(this, void 0, void 0, function* () {
            if (speciesKey == null) {
                return [];
            }
            const randomCareers = game.wfrp4e.tables.career.rows
                .filter((row) => { var _a; return ((_a = row === null || row === void 0 ? void 0 : row.range[speciesKey]) === null || _a === void 0 ? void 0 : _a.length) > 0; })
                .map((row) => row.name);
            const careers = yield this.getCareerEntities(false);
            const result = [];
            randomCareers.forEach((rc) => {
                let cs = careers.filter((c) => {
                    var _a, _b, _c;
                    return StringUtil.includesDeburrIgnoreCase((_c = (_b = (_a = c.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.careergroup) === null || _c === void 0 ? void 0 : _c.value, rc);
                });
                if (cs.length !== 4) {
                    const strictCareer = careers.find((c) => StringUtil.equalsDeburrIgnoreCase(c.name, rc));
                    if (strictCareer != null) {
                        cs = careers.filter((c) => {
                            var _a, _b, _c, _d, _e, _f;
                            return StringUtil.equalsDeburrIgnoreCase((_c = (_b = (_a = c.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.careergroup) === null || _c === void 0 ? void 0 : _c.value, (_f = (_e = (_d = strictCareer.data) === null || _d === void 0 ? void 0 : _d.data) === null || _e === void 0 ? void 0 : _e.careergroup) === null || _f === void 0 ? void 0 : _f.value);
                        });
                    }
                }
                if (cs.length === 4) {
                    result.push(...cs.map((c) => c.name));
                }
            });
            return Promise.resolve(result);
        });
    }
    static getStatusTiers() {
        return game.wfrp4e.config.statusTiers;
    }
    static getAllBasicSkills() {
        return __awaiter(this, void 0, void 0, function* () {
            return yield game.wfrp4e.utility.allBasicSkills();
        });
    }
    static findSkill(name) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield game.wfrp4e.utility.findSkill(name);
        });
    }
    static findTalent(name) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield game.wfrp4e.utility.findTalent(name);
        });
    }
    static findTrappings(name, referentialTrappings) {
        return __awaiter(this, void 0, void 0, function* () {
            let searchName = StringUtil.toDeburrLowerCase(name);
            const trappings = [];
            let trapping = yield this.findTrapping(searchName, referentialTrappings);
            while (trapping != null) {
                trappings.push(trapping);
                const lastSearch = searchName;
                searchName = searchName
                    .replace(StringUtil.toDeburrLowerCase(trapping.name.trim()), '')
                    .replace('(', '')
                    .replace(')', '')
                    .trim();
                if (searchName === lastSearch) {
                    const simpleName = searchName.includes('(') && searchName.includes(')')
                        ? searchName.substring(0, searchName.indexOf('(')).trim()
                        : searchName;
                    if (simpleName !== searchName) {
                        searchName = searchName
                            .replace(StringUtil.toDeburrLowerCase(simpleName), '')
                            .replace('(', '')
                            .replace(')', '')
                            .trim();
                    }
                }
                if (searchName === lastSearch) {
                    const words = trapping.name
                        .trim()
                        .split(' ')
                        .map((word) => word.trim())
                        .filter((word) => word.length > 3);
                    for (let word of words) {
                        searchName = searchName
                            .replace(StringUtil.toDeburrLowerCase(word), '')
                            .trim();
                    }
                }
                if (searchName.length > 3 && lastSearch !== searchName) {
                    trapping = yield this.findTrapping(searchName, referentialTrappings);
                }
                else {
                    trapping = null;
                }
            }
            if (searchName.trim().includes(' ')) {
                trappings.push(...(yield this.findTrappingsByWords(searchName, referentialTrappings)));
            }
            return Promise.resolve(trappings);
        });
    }
    static findTrappingsByWords(name, referentialTrappings) {
        return __awaiter(this, void 0, void 0, function* () {
            const trappings = [];
            if (name != null && name.length > 0) {
                const words = name
                    .split(' ')
                    .map((word) => word.trim())
                    .map((word) => word.replace('(', '').replace(')', ''))
                    .filter((word) => word.length > 3);
                for (let word of words) {
                    const trapping = yield this.findTrapping(word, referentialTrappings, true);
                    if (trapping != null) {
                        trappings.push(trapping);
                    }
                }
            }
            return trappings;
        });
    }
    static findTrapping(name, referentialTrappings, fromWord = false) {
        var _a, _b, _c, _d;
        return __awaiter(this, void 0, void 0, function* () {
            const searchTrappings = referentialTrappings !== null && referentialTrappings !== void 0 ? referentialTrappings : (yield this.getTrappingEntities(true));
            const simpleName = name.includes('(') && name.includes(')')
                ? name.substring(0, name.indexOf('(')).trim()
                : name;
            let trapping = (_c = (_b = (_a = searchTrappings.find((t) => StringUtil.equalsDeburrIgnoreCase(name, t.name))) !== null && _a !== void 0 ? _a : searchTrappings.find((t) => StringUtil.equalsDeburrIgnoreCase(t.name, simpleName))) !== null && _b !== void 0 ? _b : searchTrappings.find((t) => StringUtil.includesDeburrIgnoreCase(t.name, name))) !== null && _c !== void 0 ? _c : searchTrappings.find((t) => StringUtil.includesDeburrIgnoreCase(t.name, simpleName));
            if (trapping == null && !fromWord) {
                trapping = searchTrappings
                    .sort((t1, t2) => {
                    return t2.name.length - t1.name.length;
                })
                    .find((t) => StringUtil.includesDeburrIgnoreCase(name, t.name));
            }
            if (trapping == null) {
                console.warn(`Can't find trapping ${name}${simpleName !== name ? `or ${simpleName}` : ''}`);
            }
            else if (!StringUtil.equalsDeburrIgnoreCase(trapping.name, name)) {
                console.warn(`Trapping ${name} is resolved by ${trapping.name}`);
            }
            return Promise.resolve((_d = trapping === null || trapping === void 0 ? void 0 : trapping.data) !== null && _d !== void 0 ? _d : null);
        });
    }
    static getSpeciesCharacteristics(speciesKey) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield game.wfrp4e.utility.speciesCharacteristics(speciesKey, true);
        });
    }
    static getSpeciesMovement(speciesKey) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield game.wfrp4e.utility.speciesMovement(speciesKey);
        });
    }
    static getAllMoneyItems() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            let moneyItems = (_a = (yield game.wfrp4e.utility.allMoneyItems())) !== null && _a !== void 0 ? _a : [];
            moneyItems = moneyItems
                .map((mi) => {
                mi.data.quantity.value = 0;
                return mi;
            })
                .sort((a, b) => {
                const aData = a.data;
                const bData = b.data;
                return aData.coinValue.value > bData.coinValue.value ? -1 : 1;
            });
            return Promise.resolve(moneyItems);
        });
    }
}
//# sourceMappingURL=referential-util.js.map
export default class GenerationProfiles {
    constructor() {
        this.human = {
            profiles: [],
        };
        this.halfling = {
            profiles: [],
        };
        this.dwarf = {
            profiles: [],
        };
        this.welf = {
            profiles: [],
        };
        this.helf = {
            profiles: [],
        };
        this.creature = {
            profiles: [],
        };
    }
}
//# sourceMappingURL=generation-profiles.js.map
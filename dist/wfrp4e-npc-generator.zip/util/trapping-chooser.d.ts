import { ItemData } from '@league-of-foundry-developers/foundry-vtt-types/src/foundry/common/data/data.mjs';
export default class TrappingChooser {
    static selectTrappings(initTrappings: ItemData[], callback: (trappings: ItemData[]) => void, undo?: () => void): Promise<void>;
}

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import ReferentialUtil from './referential-util.js';
import StringUtil from './string-util.js';
import RandomUtil from './random-util.js';
export default class TrappingUtil {
    static generateMoney(actor) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j;
        return __awaiter(this, void 0, void 0, function* () {
            if (actor == null) {
                return;
            }
            const actorStatus = (_d = (_c = (_b = (_a = actor.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.details) === null || _c === void 0 ? void 0 : _c.status) === null || _d === void 0 ? void 0 : _d.value;
            const statusTiers = ReferentialUtil.getStatusTiers();
            const status = actorStatus === null || actorStatus === void 0 ? void 0 : actorStatus.split(' ')[0];
            const tierStr = actorStatus === null || actorStatus === void 0 ? void 0 : actorStatus.split(' ')[1];
            const tier = tierStr != null && Number.isNumeric(tierStr) ? Number(tierStr) : -1;
            let statusKey = null;
            (_e = Object.entries(statusTiers)) === null || _e === void 0 ? void 0 : _e.forEach(([key, value]) => {
                if (value === status) {
                    statusKey = key;
                }
            });
            if (tier < 0 || statusKey == null) {
                return;
            }
            let gold = 0;
            let silver = 0;
            let brass;
            if (statusKey === 'g') {
                gold = tier;
                silver = new Roll('5d10').roll().total;
                brass = new Roll('10d10').roll().total;
            }
            else if (statusKey === 's') {
                silver = new Roll(`${tier}d10`).roll().total;
                brass = new Roll('10d10').roll().total;
            }
            else {
                brass = new Roll(`${2 * tier}d10`).roll().total;
            }
            const moneyItems = yield ReferentialUtil.getAllMoneyItems();
            let coins = (_g = (_f = actor.data) === null || _f === void 0 ? void 0 : _f.money) === null || _g === void 0 ? void 0 : _g.coins;
            let gCoin = coins.find((c) => { var _a, _b; return ((_b = (_a = c.data) === null || _a === void 0 ? void 0 : _a.coinValue) === null || _b === void 0 ? void 0 : _b.value) === 240; });
            let sCoin = coins.find((c) => { var _a, _b; return ((_b = (_a = c.data) === null || _a === void 0 ? void 0 : _a.coinValue) === null || _b === void 0 ? void 0 : _b.value) === 12; });
            let bCoin = coins.find((c) => { var _a, _b; return ((_b = (_a = c.data) === null || _a === void 0 ? void 0 : _a.coinValue) === null || _b === void 0 ? void 0 : _b.value) === 1; });
            const isGoldCreate = gCoin == null;
            const isSilverCreate = sCoin == null;
            const isBrassCreate = bCoin == null;
            const createGCoin = moneyItems[0];
            const createSCoin = moneyItems[1];
            const createBCoin = moneyItems[2];
            if (gold > 0 || isGoldCreate) {
                if (isGoldCreate) {
                    createGCoin.data.quantity.value = gold;
                    yield actor.createOwnedItem(createGCoin);
                }
                else {
                    yield actor.updateOwnedItem({
                        _id: gCoin._id,
                        [this.UPDATE_QUANTITY_KEY]: gold,
                    });
                }
            }
            if (silver > 0 || isSilverCreate) {
                if (isSilverCreate) {
                    createSCoin.data.quantity.value = silver;
                    yield actor.createOwnedItem(createSCoin);
                }
                else {
                    yield actor.updateOwnedItem({
                        _id: sCoin._id,
                        [this.UPDATE_QUANTITY_KEY]: silver,
                    });
                }
            }
            if (brass > 0 || isBrassCreate) {
                if (isBrassCreate) {
                    createBCoin.data.quantity.value = brass;
                    yield actor.createOwnedItem(createBCoin);
                }
                else {
                    yield actor.updateOwnedItem({
                        _id: bCoin._id,
                        [this.UPDATE_QUANTITY_KEY]: brass,
                    });
                }
            }
            let money = duplicate((_j = (_h = actor.data) === null || _h === void 0 ? void 0 : _h.money) === null || _j === void 0 ? void 0 : _j.coins);
            money = game.wfrp4e.market.consolidateMoney(money);
            yield actor.updateOwnedItem(money);
        });
    }
    static generateWeapons(actor) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
        return __awaiter(this, void 0, void 0, function* () {
            if (actor == null) {
                return;
            }
            const groups = [];
            const weaponSkills = (_b = (_a = actor.data) === null || _a === void 0 ? void 0 : _a.skills) === null || _b === void 0 ? void 0 : _b.filter((i) => i.name.includes('(') &&
                (StringUtil.includesDeburrIgnoreCase(i.name, ReferentialUtil.getWeaponTypes().melee) ||
                    StringUtil.includesDeburrIgnoreCase(i.name, ReferentialUtil.getWeaponTypes().ranged))).sort((s1, s2) => {
                const s1HaveAny = StringUtil.includesDeburrIgnoreCase(s1.name, game.i18n.localize('WFRP4NPCGEN.item.any'));
                const s2HaveAny = StringUtil.includesDeburrIgnoreCase(s2.name, game.i18n.localize('WFRP4NPCGEN.item.any'));
                if (s1HaveAny && s2HaveAny) {
                    return 0;
                }
                else if (s1HaveAny) {
                    return 1;
                }
                else if (s2HaveAny) {
                    return -1;
                }
                return 0;
            });
            for (let skill of weaponSkills) {
                const isMelee = StringUtil.includesDeburrIgnoreCase(skill.name, ReferentialUtil.getWeaponTypes().melee);
                let group = skill.name.substring(skill.name.indexOf('(') + 1, skill.name.indexOf(')'));
                let replaceSkill = false;
                if (!StringUtil.arrayIncludesDeburrIgnoreCase(ReferentialUtil.getWeaponGroups(), group)) {
                    group = RandomUtil.getRandomValue(isMelee
                        ? ReferentialUtil.getMeleeWeaponGroups()
                        : ReferentialUtil.getRangedWeaponGroups(), groups);
                    if (group == null) {
                        group = ReferentialUtil.getBasicWeaponGroups();
                    }
                    console.warn(`Unknown weapon group from skill ${skill.name}, resolved by random ${group}`);
                    replaceSkill = true;
                }
                const existingCount = (_e = (_d = (_c = actor.data) === null || _c === void 0 ? void 0 : _c.weapons) === null || _d === void 0 ? void 0 : _d.filter((w) => StringUtil.equalsDeburrIgnoreCase(w.weaponGroup, group))) === null || _e === void 0 ? void 0 : _e.length;
                const ignore = (StringUtil.equalsDeburrIgnoreCase(group, ReferentialUtil.getBasicWeaponGroups()) &&
                    existingCount > 1) ||
                    existingCount > 0;
                if (!ignore && !groups.includes(group)) {
                    groups.push(group);
                    if (replaceSkill) {
                        yield actor.updateOwnedItem({
                            _id: skill._id,
                            [this.UPDATE_SKILL_NAME_KEY]: `${isMelee
                                ? ReferentialUtil.getWeaponTypes().melee
                                : ReferentialUtil.getWeaponTypes().ranged} (${group})`,
                        });
                    }
                }
            }
            if (groups.length > 0) {
                const weapons = (yield ReferentialUtil.getTrappingEntities(true)).filter((w) => w.type === 'weapon');
                for (let group of groups) {
                    const randomWeapon = RandomUtil.getRandomValue(weapons.filter((w) => {
                        var _a, _b;
                        return StringUtil.equalsDeburrIgnoreCase((_b = (_a = w.data.data) === null || _a === void 0 ? void 0 : _a.weaponGroup) === null || _b === void 0 ? void 0 : _b.value, ReferentialUtil.getWeaponGroupsKey(group));
                    }));
                    yield actor.createOwnedItem(randomWeapon.data);
                }
            }
            if (((_g = (_f = actor.data) === null || _f === void 0 ? void 0 : _f.weapons) === null || _g === void 0 ? void 0 : _g.length) > 0) {
                const ammunitions = (yield ReferentialUtil.getTrappingEntities(true)).filter((w) => w.type === 'ammunition');
                for (let weapons of (_h = actor.data) === null || _h === void 0 ? void 0 : _h.weapons) {
                    const ammunitionGroup = (_k = (_j = weapons.data) === null || _j === void 0 ? void 0 : _j.ammunitionGroup) === null || _k === void 0 ? void 0 : _k.value;
                    if (ammunitionGroup != null) {
                        const randomAmmunition = RandomUtil.getRandomValue(ammunitions.filter((w) => {
                            var _a, _b;
                            return StringUtil.equalsDeburrIgnoreCase((_b = (_a = w.data.data) === null || _a === void 0 ? void 0 : _a.ammunitionType) === null || _b === void 0 ? void 0 : _b.value, ammunitionGroup);
                        }));
                        if (randomAmmunition != null) {
                            const quantity = (_m = (_l = randomAmmunition.data.data) === null || _l === void 0 ? void 0 : _l.quantity) === null || _m === void 0 ? void 0 : _m.value;
                            if (quantity != null && quantity < 10) {
                                randomAmmunition.data.data.quantity.value = 10;
                            }
                            yield actor.createOwnedItem(randomAmmunition.data);
                        }
                    }
                }
            }
        });
    }
}
TrappingUtil.UPDATE_QUANTITY_KEY = 'data.quantity.value';
TrappingUtil.UPDATE_SKILL_NAME_KEY = 'name';
//# sourceMappingURL=trapping-util.js.map
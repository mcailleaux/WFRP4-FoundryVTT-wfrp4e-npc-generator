import { ItemData } from '@league-of-foundry-developers/foundry-vtt-types/src/foundry/common/data/data.mjs';
import { DocumentData } from '@league-of-foundry-developers/foundry-vtt-types/src/foundry/common/abstract/module.mjs.js';
export default class EntityUtil {
    static match(item: any, ref: Item & any): boolean;
    static toSelectOption(items: (ItemData & any)[]): {
        [key: string]: string;
    };
    static toSelectOptionGroup(items: {
        [group: string]: (ItemData & any)[];
    }): {
        [group: string]: {
            [key: string]: string;
        };
    };
    static toMinimalName(value: string): string;
    static find(name: string, entities: ItemData[]): ItemData | null;
    static hasGroupName(name: string): boolean;
    static toRecords<E, F extends object>(arrays: (DocumentData<E, F> & any)[]): Record<string, unknown>[];
}

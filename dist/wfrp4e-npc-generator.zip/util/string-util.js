// @ts-ignore
import deburr from './lodash/deburr.js';
export default class StringUtil {
    static includesDeburrIgnoreCase(input, include) {
        if (input == null || input.length === 0 || include == null) {
            return false;
        }
        return deburr(input).toLowerCase().includes(deburr(include).toLowerCase());
    }
    static equalsDeburrIgnoreCase(input, include) {
        if (input == null || input.length === 0 || include == null) {
            return false;
        }
        return deburr(input).toLowerCase() === deburr(include).toLowerCase();
    }
    static arrayIncludesDeburrIgnoreCase(array, include) {
        if (array == null || array.length === 0 || include == null) {
            return false;
        }
        return array
            .map((s) => deburr(s).toLowerCase())
            .includes(deburr(include).toLowerCase());
    }
    static localCompareDeburrIgnoreCase(c1, c2, asc = true) {
        const fc1 = deburr(c1 !== null && c1 !== void 0 ? c1 : '')
            .toLowerCase()
            .trim();
        const fc2 = deburr(c2 !== null && c2 !== void 0 ? c2 : '')
            .toLowerCase()
            .trim();
        return asc ? fc1.localeCompare(fc2) : fc2.localeCompare(fc1);
    }
    static toDeburrLowerCase(value) {
        return deburr(value).toLowerCase();
    }
    static getSimpleName(name) {
        return (name === null || name === void 0 ? void 0 : name.includes('(')) && (name === null || name === void 0 ? void 0 : name.includes(')'))
            ? name.substring(0, name.indexOf('(')).trim()
            : name;
    }
    static getGroupName(name) {
        return (name === null || name === void 0 ? void 0 : name.includes('(')) && (name === null || name === void 0 ? void 0 : name.includes(')'))
            ? name.substring(name.indexOf('(') + 1, name.indexOf(')')).trim()
            : name;
    }
}
//# sourceMappingURL=string-util.js.map
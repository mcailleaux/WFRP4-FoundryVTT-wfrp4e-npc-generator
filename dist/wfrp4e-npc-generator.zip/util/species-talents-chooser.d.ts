export default class SpeciesTalentsChooser {
    static selectSpeciesTalents(initTalents: string[], speciesKey: string, callback: (speciesTalents: string[]) => void, undo: () => void): Promise<void>;
}

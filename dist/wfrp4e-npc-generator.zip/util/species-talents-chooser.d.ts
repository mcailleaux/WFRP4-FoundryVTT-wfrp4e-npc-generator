export default class SpeciesTalentsChooser {
    static selectSpeciesTalents(initTalents: string[], initTraits: string[], speciesKey: string, subSpeciesKey: string, callback: (speciesTalents: string[], speciesTraits: string[]) => void, undo: () => void): Promise<void>;
}

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import ReferentialUtil from './referential-util.js';
import DialogUtil from './dialog-util.js';
import EntityUtil from './entity-util.js';
export default class MutationsChooser {
    static selectMutations(initPhysicals, initMentals, callback, undo) {
        return __awaiter(this, void 0, void 0, function* () {
            const dialogId = new Date().getTime();
            const physicals = [
                ...(yield ReferentialUtil.getPhysicalMutationEntities(true)).map((t) => t.data),
            ].sort((t1, t2) => {
                return t1.name.localeCompare(t2.name);
            });
            const mentals = [
                ...(yield ReferentialUtil.getMentalMutationEntities(true)).map((t) => t.data),
            ].sort((t1, t2) => {
                return t1.name.localeCompare(t2.name);
            });
            const physicalsId = `creature-add-remove-physicals-${dialogId}`;
            const mentalsId = `creature-add-remove-mentals-${dialogId}`;
            new Dialog({
                title: game.i18n.localize('WFRP4NPCGEN.select.mutations.title'),
                content: `<form>
            <div class="form-group">
            ${DialogUtil.getSelectAddRemoveScript({
                    id: physicalsId,
                    title: 'WFRP4NPCGEN.select.mutations.physicals.title',
                    captions: `
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.name.select.label')}           
            ${DialogUtil.getLabelScript('', 'max-width: 38px;')}
            `,
                    options: EntityUtil.toSelectOption(physicals),
                    initValues: initPhysicals === null || initPhysicals === void 0 ? void 0 : initPhysicals.map((s) => {
                        var _a;
                        return {
                            key: s._id,
                            value: (_a = s.displayName) !== null && _a !== void 0 ? _a : s.name,
                        };
                    }),
                })}
          </div>
          <div class="form-group">
          ${DialogUtil.getSelectAddRemoveScript({
                    id: mentalsId,
                    title: 'WFRP4NPCGEN.select.mutations.mentals.title',
                    captions: `
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.name.select.label')}           
            ${DialogUtil.getLabelScript('', 'max-width: 38px;')}
            `,
                    options: EntityUtil.toSelectOption(mentals),
                    initValues: initMentals === null || initMentals === void 0 ? void 0 : initMentals.map((s) => {
                        var _a;
                        return {
                            key: s._id,
                            value: (_a = s.displayName) !== null && _a !== void 0 ? _a : s.name,
                        };
                    }),
                })}
          </div>
          </form>
          <script>  
              
              ${DialogUtil.getAddRemoveElementScript()}
                
            </script>
            `,
                buttons: DialogUtil.getDialogButtons(dialogId, (html) => {
                    const resultPhysicals = [];
                    html.find(`.${physicalsId}`).each((_i, r) => {
                        const key = r.value;
                        const physical = (physicals.find((t) => t._id === key));
                        resultPhysicals.push(physical);
                    });
                    const resultMentals = [];
                    html.find(`.${mentalsId}`).each((_i, r) => {
                        const key = r.value;
                        const mental = (mentals.find((t) => t._id === key));
                        resultMentals.push(mental);
                    });
                    callback(resultPhysicals, resultMentals);
                }, undo),
                default: 'yes',
            }, {
                resizable: true,
                classes: ['dialog', 'wfrp4e-npc-generator-dialog'],
            }).render(true);
        });
    }
}
//# sourceMappingURL=mutations-chooser.js.map
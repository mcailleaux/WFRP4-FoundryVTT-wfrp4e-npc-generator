/// <reference types="jquery" />
import { GenerateEffectOptionEnum } from './generate-effect-option.enum.js';
export default class DialogUtil {
    static getDialogButtons(id: number, yesCallback: (html?: JQuery) => void, previousCallback?: (html?: JQuery) => void): any;
    static getButtonScript(label: string, onclick: string): string;
    static getLabelScript(label: string, style?: string): string;
    static getSelectScript(id: string, options: {
        [key: string]: string;
    }, initValue?: string): string;
    static getInputScript(options: {
        id: string;
        type: string;
        initValue?: string | number | boolean;
        name?: string;
        onInput?: string;
        onClick?: string;
        dataListId?: string;
        options?: string[];
        classes?: string;
        style?: string;
        checked?: boolean;
    }): string;
    static getToArrayScript(): string;
    static getNameRandomScript(): string;
    static getEffectSelectScript(dialogId: number, id: string, initValue: GenerateEffectOptionEnum): string;
}

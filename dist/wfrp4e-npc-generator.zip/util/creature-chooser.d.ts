export default class CreatureChooser {
    static selectCreature(initCreature: string, callback: (creature: Actor) => void): Promise<void>;
}

export default class WaiterUtil {
    private static dialogInstance;
    static show(title: string, msg: string, renderCallback: () => void): Promise<void>;
    static hide(asyncClose?: boolean): Promise<void>;
}

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import RegisterSettings from './register-settings.js';
import ReferentialUtil from './referential-util.js';
import NameChooser from './name-chooser.js';
export default class GenerationProfilesForm extends FormApplication {
    constructor(object, options = {}) {
        super(object, options);
    }
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            id: 'generation-profiles',
            title: game.i18n.localize('WFRP4NPCGEN.settings.generationProfiles.name'),
            template: `modules/${RegisterSettings.moduleName}/templates/generation-profiles.html`,
            width: 800,
            height: 'auto',
            resizable: true,
            closeOnSubmit: true,
        });
    }
    getData() {
        if (this.data == null) {
            const profiles = duplicate(game.settings.get(RegisterSettings.moduleName, 'generationProfiles'));
            if (profiles.creature == null) {
                profiles.creature = {
                    profiles: [],
                };
            }
            const speciesMap = ReferentialUtil.getSpeciesMap();
            Object.entries(speciesMap).forEach(([key, label]) => {
                if (profiles[key] == null) {
                    profiles[key] = {
                        profiles: [],
                    };
                }
                profiles[key].species = label;
            });
            if (profiles.creature != null) {
                profiles.creature.species = game.i18n.localize('WFRP4NPCGEN.options.select.profiles.creature.label');
            }
            Object.entries(profiles).forEach(([key, value]) => {
                value.profiles.forEach((profile) => {
                    profile.id = `${key}-${profile.name}`;
                    profile.idGenPath = `${key}-${profile.name}-genPath`;
                    profile.idImagePath = `${key}-${profile.name}-imagePath`;
                    profile.idTokenPath = `${key}-${profile.name}-tokenPath`;
                });
            });
            this.data = profiles;
        }
        return {
            species: this.data,
        };
    }
    activateListeners(html) {
        html.find('.generation-profiles-add-button').on('click', (event) => {
            var _a;
            const species = (_a = event === null || event === void 0 ? void 0 : event.currentTarget) === null || _a === void 0 ? void 0 : _a.value;
            NameChooser.selectName('', species, false, (name) => {
                const existingName = this.data[species].profiles.find((p) => p.id === `${species}-${name}`);
                if (existingName == null) {
                    this.data[species].profiles.push({
                        id: `${species}-${name}`,
                        idGenPath: `${species}-${name}-genPath`,
                        idImagePath: `${species}-${name}-imagePath`,
                        idTokenPath: `${species}-${name}-tokenPath`,
                        name: name,
                        genPath: game.settings.get(RegisterSettings.moduleName, species === 'creature'
                            ? 'defaultCreatureGenPath'
                            : 'defaultGenPath'),
                        imagePath: '',
                        tokenPath: '',
                    });
                    this.render();
                }
            });
        });
        html.find('.generation-profiles-edit-button').on('click', (event) => {
            var _a;
            const id = (_a = event === null || event === void 0 ? void 0 : event.currentTarget) === null || _a === void 0 ? void 0 : _a.value;
            if (id != null && id.includes('-')) {
                const species = id.substring(0, id.indexOf('-'));
                const name = id.substring(id.indexOf('-') + 1, id.length);
                const editedName = this.data[species].profiles.find((p) => p.id === `${species}-${name}`);
                NameChooser.selectName(name, species, false, (newName) => {
                    const existingName = this.data[species].profiles.find((p) => p.id === `${species}-${newName}`);
                    if (existingName == null && editedName != null) {
                        editedName.name = newName;
                        editedName.id = `${species}-${newName}`;
                        editedName.idGenPath = `${species}-${newName}-genPath`;
                        editedName.idImagePath = `${species}-${newName}-imagePath`;
                        editedName.idTokenPath = `${species}-${newName}-tokenPath`;
                        this.render();
                    }
                });
            }
        });
        html.find('.generation-profiles-delete-button').on('click', (event) => {
            var _a;
            const id = (_a = event === null || event === void 0 ? void 0 : event.currentTarget) === null || _a === void 0 ? void 0 : _a.value;
            if (id != null && id.includes('-')) {
                const species = id.substring(0, id.indexOf('-'));
                if (this.data[species] != null) {
                    const indexToRemove = this.data[species].profiles.findIndex((p) => p.id === id);
                    if (indexToRemove >= 0) {
                        this.data[species].profiles.splice(indexToRemove, 1);
                        this.render();
                    }
                }
            }
        });
        html.find('.generation-profiles-input-genPath').on('input', (event) => {
            this.performInputChange(event, 'genPath');
        });
        html.find('.generation-profiles-input-imagePath').on('input', (event) => {
            this.performInputChange(event, 'imagePath');
        });
        html.find('.generation-profiles-input-tokenPath').on('input', (event) => {
            this.performInputChange(event, 'tokenPath');
        });
        html.find('.generation-profiles-input-imagePath').on('change', (event) => {
            this.performInputChange(event, 'imagePath');
        });
        html.find('.generation-profiles-input-tokenPath').on('change', (event) => {
            this.performInputChange(event, 'tokenPath');
        });
        super.activateListeners(html);
    }
    _getSubmitData(_updateData) {
        return this.data;
    }
    _updateObject(_event, formData) {
        return __awaiter(this, void 0, void 0, function* () {
            const generationProfiles = duplicate(formData);
            Object.entries(generationProfiles).forEach(([key, value]) => {
                delete generationProfiles[key].species;
                value.profiles.forEach((profile) => {
                    delete profile.id;
                    delete profile.idGenPath;
                    delete profile.idImagePath;
                    delete profile.idTokenPath;
                });
            });
            yield game.settings.set(RegisterSettings.moduleName, 'generationProfiles', generationProfiles);
        });
    }
    close(options) {
        this.data = null;
        return super.close(options);
    }
    performInputChange(event, attr) {
        var _a, _b;
        const id = (_a = event === null || event === void 0 ? void 0 : event.currentTarget) === null || _a === void 0 ? void 0 : _a.id;
        const value = (_b = event === null || event === void 0 ? void 0 : event.currentTarget) === null || _b === void 0 ? void 0 : _b.value;
        if (id != null && id.includes('-')) {
            const species = id.substring(0, id.indexOf('-'));
            const startName = id.indexOf('-') + 1;
            const name = id.substring(startName, id.indexOf('-', startName));
            const existing = this.data[species].profiles.find((p) => p.id === `${species}-${name}`);
            if (existing != null) {
                existing[attr] = value;
            }
        }
    }
}
//# sourceMappingURL=generation-profiles-form.js.map
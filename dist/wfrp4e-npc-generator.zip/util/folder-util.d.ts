export default class FolderUtil {
    static createNamedFolder(name: string, parent?: Folder | null): Promise<Folder | null>;
}

export default class CareerChooser {
    static selectCareer(initCareers: string[], speciesKey: string, callback: (item: Item[]) => void, undo: () => void): Promise<void>;
}

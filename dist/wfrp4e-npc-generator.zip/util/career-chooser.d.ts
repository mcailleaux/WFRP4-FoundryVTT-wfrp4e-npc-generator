export default class CareerChooser {
    static selectCareer(initCareer: string, speciesKey: string, callback: (item: Item) => void, undo: () => void): Promise<void>;
}

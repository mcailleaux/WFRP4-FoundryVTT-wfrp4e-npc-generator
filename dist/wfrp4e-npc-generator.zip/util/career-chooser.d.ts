export default class CareerChooser {
    static selectCareer(initCareers: string[], speciesKey: string, subSpeciesKey: string, callback: (item: Item[]) => void, undo: () => void): Promise<void>;
}

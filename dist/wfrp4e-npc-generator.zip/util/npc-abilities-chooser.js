var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import ReferentialUtil from './referential-util.js';
import EntityUtil from './entity-util.js';
import DialogUtil from './dialog-util.js';
import StringUtil from './string-util.js';
import RandomUtil from './random-util.js';
import { i18n } from '../constant.js';
export default class NpcAbilitiesChooser {
    static selectNpcAbilities(initSkills, initTalents, initTraits, callback, undo) {
        return __awaiter(this, void 0, void 0, function* () {
            const dialogId = new Date().getTime();
            const correctDataName = (data, key = 'name') => {
                if (data[key].includes('*')) {
                    data[key] = data[key].replace(/\*/g, '');
                }
                if (data[key].includes('(') && !data[key].includes(')')) {
                    data[key] = data[key] + ')';
                }
            };
            const initSkillsNames = initSkills.map((s) => s.name);
            const skills = [
                ...initSkills.sort((s1, s2) => {
                    return s1.name.localeCompare(s2.name);
                }),
                ...[
                    ...(yield ReferentialUtil.getSkillEntities(true))
                        .filter((s) => {
                        var _a;
                        return !StringUtil.arrayIncludesDeburrIgnoreCase(initSkillsNames, (_a = s.name) !== null && _a !== void 0 ? _a : '');
                    })
                        .map((s) => {
                        const data = duplicate(s.data);
                        data._id = RandomUtil.getRandomId();
                        return data;
                    }),
                    ...(yield ReferentialUtil.getCompendiumActorSkills())
                        .filter((s) => {
                        return !StringUtil.arrayIncludesDeburrIgnoreCase(initSkillsNames, s.name);
                    })
                        .map((s) => {
                        const data = duplicate(s);
                        correctDataName(data);
                        data._id = RandomUtil.getRandomId();
                        return data;
                    }),
                ].sort((s1, s2) => {
                    return s1.name.localeCompare(s2.name);
                }),
            ];
            const initTalentsNames = initTalents.map((t) => t.name);
            const talents = [
                ...initTalents.sort((t1, t2) => {
                    return t1.name.localeCompare(t2.name);
                }),
                ...[
                    ...(yield ReferentialUtil.getTalentEntities(true))
                        .filter((t) => {
                        var _a;
                        return !StringUtil.arrayIncludesDeburrIgnoreCase(initTalentsNames, (_a = t.name) !== null && _a !== void 0 ? _a : '');
                    })
                        .map((t) => {
                        const data = duplicate(t.data);
                        data._id = RandomUtil.getRandomId();
                        return data;
                    }),
                    ...(yield ReferentialUtil.getCompendiumActorTalents())
                        .filter((t) => {
                        return !StringUtil.arrayIncludesDeburrIgnoreCase(initTalentsNames, t.name);
                    })
                        .map((t) => {
                        const data = duplicate(t);
                        correctDataName(data);
                        data._id = RandomUtil.getRandomId();
                        return data;
                    }),
                ].sort((t1, t2) => {
                    return t1.name.localeCompare(t2.name);
                }),
            ];
            const initTraitsNames = initTraits.map((t) => t.name);
            const initTraitsDisplayNames = initTraits.map((t) => t.DisplayName);
            const traits = [
                ...initTraits.sort((t1, t2) => {
                    return t1.DisplayName.localeCompare(t2.DisplayName);
                }),
                ...[
                    ...(yield ReferentialUtil.getTraitEntities(true))
                        .filter((t) => {
                        var _a;
                        return !StringUtil.arrayIncludesDeburrIgnoreCase(initTraitsNames, (_a = t.name) !== null && _a !== void 0 ? _a : '');
                    })
                        .map((t) => {
                        const data = duplicate(t.data);
                        data._id = RandomUtil.getRandomId();
                        return data;
                    }),
                    ...(yield ReferentialUtil.getCompendiumActorTraits())
                        .filter((t) => {
                        return !StringUtil.arrayIncludesDeburrIgnoreCase(initTraitsDisplayNames, t.DisplayName);
                    })
                        .map((t) => {
                        const data = duplicate(t);
                        correctDataName(data);
                        correctDataName(data, 'DisplayName');
                        data._id = RandomUtil.getRandomId();
                        return data;
                    }),
                ].sort((t1, t2) => {
                    return t1.name.localeCompare(t2.name);
                }),
            ];
            const skillsId = `npc-abilities-add-remove-skills-${dialogId}`;
            const talentsId = `npc-abilities-add-remove-talents-${dialogId}`;
            const traitsId = `npc-abilities-add-remove-traits-${dialogId}`;
            new Dialog({
                title: i18n().localize('WFRP4NPCGEN.creatures.abilities.select.title'),
                content: `<form>     
            <div class="form-group">
          ${DialogUtil.getSelectAddRemoveScript({
                    id: skillsId,
                    title: 'WFRP4NPCGEN.creatures.abilities.select.skills.title',
                    captions: `
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.name.select.label')}
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.advances.label', 'max-width: 80px;')}
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.group.label', 'max-width: 80px;')}
            ${DialogUtil.getLabelScript('', 'max-width: 38px;')}
            `,
                    options: EntityUtil.toSelectOption(skills),
                    initValues: initSkills === null || initSkills === void 0 ? void 0 : initSkills.map((s) => {
                        var _a, _b, _c, _d;
                        return {
                            key: s._id,
                            value: (_a = s.displayName) !== null && _a !== void 0 ? _a : s.name,
                            count: s.data.advances.value,
                            withText: EntityUtil.hasGroupName((_b = s.displayName) !== null && _b !== void 0 ? _b : s.name),
                            text: EntityUtil.hasGroupName((_c = s.displayName) !== null && _c !== void 0 ? _c : s.name)
                                ? StringUtil.getGroupName((_d = s.displayName) !== null && _d !== void 0 ? _d : s.name)
                                : '',
                        };
                    }),
                    withCount: true,
                    withText: true,
                })}
          </div>
          <div class="form-group">
          ${DialogUtil.getSelectAddRemoveScript({
                    id: talentsId,
                    title: 'WFRP4NPCGEN.creatures.abilities.select.talents.title',
                    captions: `
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.name.select.label')}
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.advances.label', 'max-width: 80px;')}
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.group.label', 'max-width: 80px;')}
            ${DialogUtil.getLabelScript('', 'max-width: 38px;')}
            `,
                    options: EntityUtil.toSelectOption(talents),
                    initValues: initTalents === null || initTalents === void 0 ? void 0 : initTalents.map((t) => {
                        var _a, _b, _c, _d;
                        return {
                            key: t._id,
                            value: (_a = t.displayName) !== null && _a !== void 0 ? _a : t.name,
                            count: t.data.advances.value,
                            withText: EntityUtil.hasGroupName((_b = t.displayName) !== null && _b !== void 0 ? _b : t.name),
                            text: EntityUtil.hasGroupName((_c = t.displayName) !== null && _c !== void 0 ? _c : t.name)
                                ? StringUtil.getGroupName((_d = t.displayName) !== null && _d !== void 0 ? _d : t.name)
                                : '',
                        };
                    }),
                    initCount: 1,
                    withCount: true,
                    withText: true,
                })}
          </div>                                   
            <div class="form-group">
            ${DialogUtil.getSelectAddRemoveScript({
                    id: traitsId,
                    title: 'WFRP4NPCGEN.creatures.abilities.select.traits.title',
                    captions: `
                ${DialogUtil.getLabelScript('WFRP4NPCGEN.name.select.label')}
                ${DialogUtil.getLabelScript('', 'max-width: 38px;')}
                            `,
                    options: EntityUtil.toSelectOption(traits),
                    initValues: initTraits === null || initTraits === void 0 ? void 0 : initTraits.map((t) => {
                        var _a;
                        return {
                            key: t._id,
                            value: (_a = t.DisplayName) !== null && _a !== void 0 ? _a : t.name,
                        };
                    }),
                })}
          </div>
          
          
              
          </form>
          <script>  
              
              ${DialogUtil.getAddRemoveElementScript()}
                
            </script>
            `,
                buttons: DialogUtil.getDialogButtons(dialogId, (html) => {
                    const resultSkills = [];
                    const resultTalents = [];
                    const resultTraits = [];
                    html.find(`.${traitsId}`).each((_i, r) => {
                        const key = r.value;
                        const trait = traits.find((t) => t._id === key);
                        resultTraits.push(trait);
                    });
                    html.find(`.${skillsId}`).each((_i, r) => {
                        const id = r.id;
                        const key = r.value;
                        let count = 0;
                        let text = '';
                        html.find(`#${id}-count`).each((_i1, r1) => {
                            count = Number(r1.value);
                        });
                        html.find(`#${id}-text`).each((_i1, r1) => {
                            text = r1.value;
                        });
                        const skill = skills.find((s) => s._id === key);
                        skill.data.advances.value = count;
                        if (text != null && text.length > 0) {
                            skill.name = `${StringUtil.getSimpleName(skill.name)} (${text})`;
                        }
                        resultSkills.push(skill);
                    });
                    html.find(`.${talentsId}`).each((_i, r) => {
                        const id = r.id;
                        const key = r.value;
                        let count = 0;
                        let text = '';
                        html.find(`#${id}-count`).each((_i1, r1) => {
                            count = Number(r1.value);
                        });
                        html.find(`#${id}-text`).each((_i1, r1) => {
                            text = r1.value;
                        });
                        const talent = talents.find((t) => t._id === key);
                        talent.data.advances.value = count;
                        if (text != null && text.length > 0) {
                            talent.name = `${StringUtil.getSimpleName(talent.name)} (${text})`;
                        }
                        resultTalents.push(talent);
                    });
                    callback(resultSkills, resultTalents, resultTraits);
                }, undo),
                default: 'yes',
            }, {
                resizable: true,
                classes: ['dialog', 'wfrp4e-npc-generator-dialog'],
            }).render(true);
        });
    }
}
//# sourceMappingURL=npc-abilities-chooser.js.map
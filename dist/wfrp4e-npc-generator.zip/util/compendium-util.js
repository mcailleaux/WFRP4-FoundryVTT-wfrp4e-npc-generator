var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import DialogUtil from './dialog-util.js';
export default class CompendiumUtil {
    static initCompendium() {
        return __awaiter(this, void 0, void 0, function* () {
            let loadDialog;
            if (!this.compendiumloaded) {
                loadDialog = new Dialog({
                    title: game.i18n.localize('WFRP4NPCGEN.compendium.load.title'),
                    content: `<form> 
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.compendium.load.hint')}}
              </div>
          </form>
            `,
                    buttons: {},
                });
                loadDialog.render(true);
            }
            yield this.getCompendiumCareerIndexes();
            yield this.getCompendiumCareers();
            yield this.getCompendiumTrappings();
            yield this.getCompendiumSkillIndexes();
            yield this.getCompendiumSkills();
            yield this.getCompendiumTalentIndexes();
            yield this.getCompendiumTalents();
            if (!this.compendiumloaded && loadDialog != null) {
                yield loadDialog.close();
            }
            this.compendiumloaded = true;
        });
    }
    static getCompendiumCareerIndexes() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumCareerIndexes == null) {
                this.compendiumCareerIndexes = [];
                const careersPacks = game.packs.filter((p) => p.metadata.tags && p.metadata.tags.includes('career'));
                for (let pack of careersPacks) {
                    this.compendiumCareerIndexes.push(...(yield pack.getIndex()));
                }
            }
            return Promise.resolve(this.compendiumCareerIndexes);
        });
    }
    static getCompendiumCareers() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumCareers == null) {
                this.compendiumCareers = [];
                const careersPacks = game.packs.filter((p) => p.metadata.tags && p.metadata.tags.includes('career'));
                for (let pack of careersPacks) {
                    this.compendiumCareers.push(...(yield pack.getContent()));
                }
            }
            return Promise.resolve(this.compendiumCareers);
        });
    }
    static getCompendiumTrappings() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumTrappings == null) {
                this.compendiumTrappings = [];
                const trappingsPacks = game.packs.filter((p) => p.metadata.tags && p.metadata.tags.includes('trapping'));
                for (let pack of trappingsPacks) {
                    this.compendiumTrappings.push(...(yield pack.getContent()));
                }
            }
            return Promise.resolve(this.compendiumTrappings);
        });
    }
    static getCompendiumSkillIndexes() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumSkillIndexes == null) {
                this.compendiumSkillIndexes = [];
                const skillPacks = game.packs.filter((p) => p.metadata.tags && p.metadata.tags.includes('skill'));
                for (let pack of skillPacks) {
                    this.compendiumSkillIndexes.push(...(yield pack.getIndex()));
                }
            }
            return Promise.resolve(this.compendiumSkillIndexes);
        });
    }
    static getCompendiumSkills() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumSkills == null) {
                this.compendiumSkills = [];
                const skillPacks = game.packs.filter((p) => p.metadata.tags && p.metadata.tags.includes('skill'));
                for (let pack of skillPacks) {
                    this.compendiumSkills.push(...(yield pack.getContent()));
                }
            }
            return Promise.resolve(this.compendiumSkills);
        });
    }
    static getCompendiumTalentIndexes() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumTalentIndexes == null) {
                this.compendiumTalentIndexes = [];
                const skillPacks = game.packs.filter((p) => p.metadata.tags && p.metadata.tags.includes('talent'));
                for (let pack of skillPacks) {
                    this.compendiumTalentIndexes.push(...(yield pack.getIndex()));
                }
            }
            return Promise.resolve(this.compendiumTalentIndexes);
        });
    }
    static getCompendiumTalents() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumTalents == null) {
                this.compendiumTalents = [];
                const skillPacks = game.packs.filter((p) => p.metadata.tags && p.metadata.tags.includes('talent'));
                for (let pack of skillPacks) {
                    this.compendiumTalents.push(...(yield pack.getContent()));
                }
            }
            return Promise.resolve(this.compendiumTalents);
        });
    }
}
CompendiumUtil.compendiumloaded = false;
//# sourceMappingURL=compendium-util.js.map
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import WaiterUtil from './waiter-util.js';
import { i18n, modules, notifications, packs, wfrp4e } from '../constant.js';
export default class CompendiumUtil {
    static initCompendium(callback, forCreatures = false) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.compendiumLoaded || !this.creatureCompendiumLoaded) {
                yield WaiterUtil.show('WFRP4NPCGEN.compendium.load.title', 'WFRP4NPCGEN.compendium.load.hint', () => __awaiter(this, void 0, void 0, function* () {
                    if (forCreatures) {
                        yield Promise.all([
                            this.getCompendiumItems(),
                            this.getCompendiumActors(),
                        ]);
                        yield Promise.all([
                            this.getCompendiumTrappings(),
                            this.getCompendiumBestiary(),
                            this.getCompendiumSkills(),
                            this.getCompendiumTalents(),
                            this.getCompendiumTraits(),
                        ]);
                        yield Promise.all([
                            this.getCompendiumSizeTrait(),
                            this.getCompendiumSwarmTrait(),
                            this.getCompendiumWeaponTrait(),
                            this.getCompendiumArmourTrait(),
                            this.getCompendiumRangedTrait(),
                        ]);
                    }
                    else {
                        yield this.getCompendiumItems();
                        yield Promise.all([
                            this.getCompendiumCareers(),
                            this.getCompendiumTrappings(),
                        ]);
                        yield this.getCompendiumCareersGroups();
                    }
                    if (!this.compendiumLoaded || !this.creatureCompendiumLoaded) {
                        yield WaiterUtil.hide();
                    }
                    if (forCreatures) {
                        this.creatureCompendiumLoaded = true;
                    }
                    else {
                        this.compendiumLoaded = true;
                    }
                    callback();
                }));
            }
            else {
                callback();
            }
        });
    }
    static getCompendiumItems() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumItems == null) {
                this.compendiumItems = [];
                const itemsPacks = packs().filter((p) => p.metadata.entity === 'Item');
                const loaders = [];
                for (let pack of itemsPacks) {
                    loaders.push(this.loadCompendiumDocuments(pack));
                }
                const contents = yield Promise.all(loaders);
                for (let items of contents) {
                    this.compendiumItems.push(...items);
                }
            }
            return Promise.resolve(this.compendiumItems);
        });
    }
    static getCompendiumActors() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumActors == null) {
                this.compendiumActors = {};
                const moduleOrder = [
                    'wfrp4e-core',
                    'wfrp4e-starter-set',
                    'wfrp4e-ua1',
                    'wfrp4e-rnhd',
                    'wfrp4e-eis',
                    'wfrp4e-dotr',
                    'wfrp4e-middenheim',
                    'wfrp4e-archives1',
                    'wfrp4e-unofficial-grimoire',
                    'nations-of-mankind-wfrp4e',
                    'ogre-kingdom-wfrp4e',
                    'the-dwarf-empire-wfrp4e',
                    'others',
                ];
                const packSort = (a, b) => {
                    var _a, _b;
                    const g1 = (_a = a === null || a === void 0 ? void 0 : a.metadata) === null || _a === void 0 ? void 0 : _a.package;
                    const g2 = (_b = b === null || b === void 0 ? void 0 : b.metadata) === null || _b === void 0 ? void 0 : _b.package;
                    const key1 = moduleOrder.includes(g1) ? g1 : 'others';
                    const key2 = moduleOrder.includes(g2) ? g2 : 'others';
                    return moduleOrder.indexOf(key1) - moduleOrder.indexOf(key2);
                };
                const actorsPacks = packs()
                    .filter((p) => p.metadata.entity === 'Actor')
                    .sort(packSort);
                const packLoader = (pack) => {
                    return new Promise((resolve) => __awaiter(this, void 0, void 0, function* () {
                        var _a, _b, _c;
                        const module = modules().get(pack.metadata.package);
                        let key = pack.metadata.label;
                        if (key === pack.metadata.name) {
                            key =
                                (_c = (_b = (_a = module === null || module === void 0 ? void 0 : module.packs) === null || _a === void 0 ? void 0 : _a.find((p) => p.name === pack.metadata.name)) === null || _b === void 0 ? void 0 : _b.label) !== null && _c !== void 0 ? _c : pack.metadata.label;
                        }
                        console.info(`Start to load ${key} compendium`);
                        const actors = (yield this.loadCompendiumDocuments(pack)).sort((c1, c2) => {
                            var _a, _b;
                            return (_a = c1.name) === null || _a === void 0 ? void 0 : _a.localeCompare((_b = c2.name) !== null && _b !== void 0 ? _b : '');
                        });
                        if (actors.length > 0) {
                            this.compendiumActors[key] = actors;
                        }
                        console.info(`End to load ${key} compendium`);
                        resolve(true);
                    }));
                };
                const loaders = [];
                for (let pack of actorsPacks) {
                    loaders.push(packLoader(pack));
                }
                yield Promise.all(loaders);
            }
            return Promise.resolve(this.compendiumActors);
        });
    }
    static getCompendiumCareers() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumCareers == null) {
                this.compendiumCareers = [];
                this.compendiumCareers.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'career'));
            }
            return Promise.resolve(this.compendiumCareers);
        });
    }
    static getCompendiumCareersGroups() {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumCareerGroups == null) {
                this.compendiumCareerGroups = [];
                const careers = yield this.getCompendiumCareers();
                for (let career of careers) {
                    const group = (_c = (_b = (_a = career === null || career === void 0 ? void 0 : career.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.careergroup) === null || _c === void 0 ? void 0 : _c.value;
                    if (group != null && !this.compendiumCareerGroups.includes(group)) {
                        this.compendiumCareerGroups.push(group);
                    }
                }
            }
            return Promise.resolve(this.compendiumCareerGroups);
        });
    }
    static getTrappingCategories() {
        return Object.keys(wfrp4e().config.trappingCategories);
    }
    static getCompendiumTrappings() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumTrappings == null) {
                this.compendiumTrappings = [];
                const trappingCategories = CompendiumUtil.getTrappingCategories();
                this.compendiumTrappings.push(...(yield this.getCompendiumItems()).filter((t) => {
                    var _a, _b, _c;
                    const type = (_c = (_b = (_a = t === null || t === void 0 ? void 0 : t.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.trappingType) === null || _c === void 0 ? void 0 : _c.value;
                    return (trappingCategories.includes(t.type) ||
                        trappingCategories.includes(type));
                }));
            }
            return Promise.resolve(this.compendiumTrappings);
        });
    }
    static getCompendiumBestiary() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumBestiary == null) {
                this.compendiumBestiary = {};
                const actorsMap = yield this.getCompendiumActors();
                for (let [key, actors] of Object.entries(actorsMap)) {
                    const creatures = actors.filter((c) => { var _a; return ((_a = c.data) === null || _a === void 0 ? void 0 : _a.type) === 'creature'; });
                    if (creatures.length > 0) {
                        this.compendiumBestiary[key] = creatures;
                    }
                }
            }
            return Promise.resolve(this.compendiumBestiary);
        });
    }
    static getCompendiumSkills() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumSkills == null) {
                this.compendiumSkills = [];
                this.compendiumSkills.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'skill'));
            }
            return Promise.resolve(this.compendiumSkills);
        });
    }
    static getCompendiumTalents() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumTalents == null) {
                this.compendiumTalents = [];
                this.compendiumTalents.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'talent'));
            }
            return Promise.resolve(this.compendiumTalents);
        });
    }
    static getCompendiumTraits() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumTraits == null) {
                this.compendiumTraits = [];
                this.compendiumTraits.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'trait'));
            }
            return Promise.resolve(this.compendiumTraits);
        });
    }
    static getCompendiumPsychologies() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumPsychologies == null) {
                this.compendiumPsychologies = [];
                this.compendiumPsychologies.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'psychology'));
            }
            return Promise.resolve(this.compendiumPsychologies);
        });
    }
    static getCompendiumSizeTrait() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumSizeTrait == null) {
                this.compendiumSizeTrait = ((yield this.getCompendiumTraits()).find((t) => {
                    var _a, _b, _c;
                    return t.data.name === 'Size' ||
                        ((_c = (_b = (_a = t.data) === null || _a === void 0 ? void 0 : _a.flags) === null || _b === void 0 ? void 0 : _b.babele) === null || _c === void 0 ? void 0 : _c.originalName) === 'Size';
                }));
            }
            return Promise.resolve(this.compendiumSizeTrait);
        });
    }
    static getCompendiumSwarmTrait() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumSwarmTrait == null) {
                this.compendiumSwarmTrait = ((yield this.getCompendiumTraits()).find((t) => {
                    var _a, _b, _c;
                    return t.data.name === 'Swarm' ||
                        ((_c = (_b = (_a = t.data) === null || _a === void 0 ? void 0 : _a.flags) === null || _b === void 0 ? void 0 : _b.babele) === null || _c === void 0 ? void 0 : _c.originalName) === 'Swarm';
                }));
            }
            return Promise.resolve(this.compendiumSwarmTrait);
        });
    }
    static getCompendiumWeaponTrait() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumWeaponTrait == null) {
                this.compendiumWeaponTrait = ((yield this.getCompendiumTraits()).find((t) => {
                    var _a, _b, _c;
                    return t.data.name === 'Weapon' ||
                        ((_c = (_b = (_a = t.data) === null || _a === void 0 ? void 0 : _a.flags) === null || _b === void 0 ? void 0 : _b.babele) === null || _c === void 0 ? void 0 : _c.originalName) === 'Weapon';
                }));
            }
            return Promise.resolve(this.compendiumWeaponTrait);
        });
    }
    static getCompendiumArmourTrait() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumArmorTrait == null) {
                this.compendiumArmorTrait = ((yield this.getCompendiumTraits()).find((t) => {
                    var _a, _b, _c;
                    return t.data.name === 'Armour' ||
                        ((_c = (_b = (_a = t.data) === null || _a === void 0 ? void 0 : _a.flags) === null || _b === void 0 ? void 0 : _b.babele) === null || _c === void 0 ? void 0 : _c.originalName) === 'Armour';
                }));
            }
            return Promise.resolve(this.compendiumArmorTrait);
        });
    }
    static getCompendiumRangedTrait() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumRangedTrait == null) {
                this.compendiumRangedTrait = ((yield this.getCompendiumTraits()).find((t) => {
                    var _a, _b, _c, _d;
                    return t.data.name.startsWith('Ranged') ||
                        ((_d = (_c = (_b = (_a = t.data) === null || _a === void 0 ? void 0 : _a.flags) === null || _b === void 0 ? void 0 : _b.babele) === null || _c === void 0 ? void 0 : _c.originalName) === null || _d === void 0 ? void 0 : _d.startsWith('Ranged'));
                }));
            }
            return Promise.resolve(this.compendiumRangedTrait);
        });
    }
    static getSizes() {
        return wfrp4e().config.actorSizes;
    }
    static getCompendiumSpells() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumSpells == null) {
                this.compendiumSpells = [];
                this.compendiumSpells.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'spell'));
            }
            return Promise.resolve(this.compendiumSpells);
        });
    }
    static getCompendiumPrayers() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumPrayers == null) {
                this.compendiumPrayers = [];
                this.compendiumPrayers.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'prayer'));
            }
            return Promise.resolve(this.compendiumPrayers);
        });
    }
    static getCompendiumPhysicalMutations() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumPhysicalMutations == null) {
                this.compendiumPhysicalMutations = [];
                this.compendiumPhysicalMutations.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'mutation' &&
                    c.data.data.mutationType.value === 'physical'));
            }
            return Promise.resolve(this.compendiumPhysicalMutations);
        });
    }
    static getCompendiumMentalMutations() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumMentalMutations == null) {
                this.compendiumMentalMutations = [];
                this.compendiumMentalMutations.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'mutation' &&
                    c.data.data.mutationType.value === 'mental'));
            }
            return Promise.resolve(this.compendiumMentalMutations);
        });
    }
    static loadCompendiumDocuments(pack) {
        return new Promise((resolve) => __awaiter(this, void 0, void 0, function* () {
            var _a;
            try {
                const docs = (_a = (yield (pack === null || pack === void 0 ? void 0 : pack.getDocuments()))) !== null && _a !== void 0 ? _a : [];
                resolve(docs);
            }
            catch (e) {
                console.error(e);
                const title = pack.title;
                const collection = pack.collection;
                const message = i18n().format('WFRP4NPCGEN.notification.compendium.load.error', {
                    title: title,
                    collection: collection,
                });
                console.warn(message);
                notifications().warn(message);
                resolve([]);
            }
        }));
    }
}
CompendiumUtil.compendiumLoaded = false;
CompendiumUtil.creatureCompendiumLoaded = false;
//# sourceMappingURL=compendium-util.js.map
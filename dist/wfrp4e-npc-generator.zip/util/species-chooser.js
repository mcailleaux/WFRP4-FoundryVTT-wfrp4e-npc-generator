var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import RandomUtil from './random-util.js';
import DialogUtil from './dialog-util.js';
import ReferentialUtil from './referential-util.js';
import { i18n } from '../constant.js';
export default class SpeciesChooser {
    static selectSpecies(initSpeciesKey, initSubSpeciesKey, initCityBorn, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            const dialogId = new Date().getTime();
            const speciesMap = ReferentialUtil.getSpeciesMap();
            const subSpeciesMap = ReferentialUtil.getSubSpeciesMap();
            const defaultSpeciesKey = initSpeciesKey != null ? initSpeciesKey : 'human';
            const initSubSpeciesMap = ReferentialUtil.getSpeciesSubSpeciesMap(defaultSpeciesKey);
            const initSubSpeciesLabelsMap = initSubSpeciesMap != null ? {} : {};
            if (initSubSpeciesMap != null && initSubSpeciesLabelsMap != null) {
                initSubSpeciesLabelsMap['none'] = '';
                for (let [key, value] of Object.entries(initSubSpeciesMap)) {
                    initSubSpeciesLabelsMap[key] = value.name;
                }
            }
            const initSubSpeciesContainerClass = initSubSpeciesMap != null ? '' : 'select-subspecies-no-subspecies';
            new Dialog({
                title: i18n().localize('WFRP4NPCGEN.species.select.title'),
                content: `<form>
              <div class="form-group">
              ${DialogUtil.getButtonScript('WFRP4NPCGEN.common.button.Random', 'random()')}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.species.select.label')}
              ${DialogUtil.getSelectScript(`select-species-${dialogId}`, speciesMap, defaultSpeciesKey, 'speciesChange()')}
              </div>
              <div id="select-subspecies-random-${dialogId}" class="form-group ${initSubSpeciesContainerClass}">
              ${DialogUtil.getButtonScript('WFRP4NPCGEN.common.button.Random', 'randomSubSpecies()')}
              </div>
              <div id="select-subspecies-container-${dialogId}" class="form-group ${initSubSpeciesContainerClass}">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.subspecies.select.label')}
              ${DialogUtil.getSelectScript(`select-subspecies-${dialogId}`, initSubSpeciesLabelsMap, initSubSpeciesKey)}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.cityborn.select.label')}
              ${DialogUtil.getInputScript({
                    id: `select-cityborn-${dialogId}`,
                    type: 'text',
                    initValue: initCityBorn,
                    name: 'select-cityborn',
                })}
              </div>
          </form>
          <script>  
          
                function speciesChange() {
                  const subSpecies = \{
                      ${Object.entries(subSpeciesMap)
                    .map(([key, value]) => `"${key}": {${Object.entries(value)
                    .map(([subKey, subValue]) => `"${subKey}": "${i18n().localize(subValue.name)}"`)
                    .join(',')}}`)
                    .join(',')}
                  \};
                  
                  
                  const speciesKey = document.getElementById('select-species-${dialogId}').value;
                  const selectSubSpecies = document.getElementById('select-subspecies-${dialogId}');
                  const selectSubSpeciesContainer = document.getElementById('select-subspecies-container-${dialogId}');
                  const selectSubSpeciesRandom = document.getElementById('select-subspecies-random-${dialogId}');
                  selectSubSpecies.value = null;
                  selectSubSpecies.innerHTML = '';
                  
                  if (subSpecies[speciesKey] != null) {
                      subSpecies[speciesKey]['none'] = '';
                      for(let [key, value] of Object.entries(subSpecies[speciesKey])) {
                          
                          const option = document.createElement('option');
                          
                          if (key === 'none') {
                              option.setAttribute('selected', 'selected');
                              selectSubSpecies.value = key;
                          }
                          
                          option.setAttribute('id', 'select-subspecies-${dialogId}-' + key);
                          option.setAttribute('value', key);
                          option.innerHTML = value;
                          
                          selectSubSpecies.append(option);
                          
                      }
                     selectSubSpeciesContainer.classList.remove('select-subspecies-no-subspecies');
                     selectSubSpeciesRandom.classList.remove('select-subspecies-no-subspecies');
                  } else {
                     selectSubSpeciesContainer.classList.add('select-subspecies-no-subspecies'); 
                     selectSubSpeciesRandom.classList.add('select-subspecies-no-subspecies'); 
                  }
                  
              }
          
              function random() {
                  const speciesKeys = [${Object.keys(speciesMap)
                    .map((key) => `"${key}"`)
                    .join(',')}];
                  const randomSpeciesKey = getRandomValue(speciesKeys);
                  if (randomSpeciesKey != null) {
                      document.getElementById('select-species-${dialogId}').value = randomSpeciesKey;
                  }
                  speciesChange();
              }
          
              function randomSubSpecies() {
                    const subSpeciesKeys = \{
                      ${Object.entries(subSpeciesMap)
                    .map(([key, value]) => `"${key}": [${Object.keys(value)
                    .map((subKey) => `"${subKey}"`)
                    .join(',')}]`)
                    .join(',')}
                  \};
                    const speciesKey = document.getElementById('select-species-${dialogId}').value;
                                                  
                  const randomSubSpeciesKey = getRandomValue(subSpeciesKeys[speciesKey]);
                  if (randomSubSpeciesKey != null) {
                      document.getElementById('select-subspecies-${dialogId}').value = randomSubSpeciesKey;
                  }
              }
              
              
              
              ${RandomUtil.getRandomValueScript()}
                
            </script>
            <style>
            .select-subspecies-no-subspecies {
                display: none !important;
            }
            </style>
            `,
                buttons: DialogUtil.getDialogButtons(dialogId, (html) => {
                    const speciesKey = (html.find(`#select-species-${dialogId}`).val());
                    let speciesValue = speciesMap[speciesKey];
                    const subSpeciesKeyStr = (html.find(`#select-subspecies-${dialogId}`).val());
                    const subSpeciesKey = subSpeciesKeyStr != null && subSpeciesKeyStr != 'none'
                        ? subSpeciesKeyStr
                        : null;
                    if (subSpeciesKey != null) {
                        speciesValue +=
                            ' (' + subSpeciesMap[speciesKey][subSpeciesKey].name + ')';
                    }
                    const cityBorn = (html.find(`#select-cityborn-${dialogId}`).val());
                    callback(speciesKey, speciesValue, subSpeciesKey, cityBorn === null || cityBorn === void 0 ? void 0 : cityBorn.trim());
                }),
                default: 'yes',
            }, {
                resizable: true,
                classes: ['dialog', 'wfrp4e-npc-generator-dialog'],
            }).render(true);
        });
    }
}
//# sourceMappingURL=species-chooser.js.map
export default class RandomUtil {
    static getRandomBoolean() {
        return this.getRandomPositiveNumber(2) === 0;
    }
    static getRandomPositiveNumber(max) {
        return Math.floor(this.random() * max);
    }
    static getRandomValue(array, exclude) {
        if (array == null || array.length === 0) {
            return null;
        }
        if (exclude != null && exclude.length > 0) {
            return this.getRandomValue(array.filter((elm) => !exclude.includes(elm)));
        }
        return array[Math.floor(this.random() * array.length)];
    }
    static getRandomValues(array, nbr) {
        if (array == null || nbr < 1 || array.length < nbr) {
            return null;
        }
        const indexes = [];
        while (indexes.length < nbr) {
            const idx = Math.floor(this.random() * array.length);
            if (!indexes.includes(idx)) {
                indexes.push(idx);
            }
        }
        return indexes.map((idx) => array[idx]);
    }
    static getRandomValueScript() {
        return `
         function getRandomValue(array) {
             if (array == null || array.length === 0) {
                return null;
             }
             let random = 0;
             for (let i = 0; i < 10; i++) {
                 random = Math.random();
             }
             return array[Math.floor(random * array.length)];
         }
    `;
    }
    static getRandomValuesScript() {
        return `
         function getRandomValues(array, nbr) {
              if (array == null || nbr < 1 || array.length < nbr) {
                return null;
              }
              const indexes = [];
              while (indexes.length < nbr) {
                let random = 0;
                for (let i = 0; i < 10; i++) {
                   random = Math.random();
                }
                const idx = Math.floor(random * array.length);
                if (!indexes.includes(idx)) {
                  indexes.push(idx);
                }
              }
              return indexes.map((idx) => array[idx]);
         }
    `;
    }
    static random() {
        let random = 0;
        for (let i = 0; i < 10; i++) {
            random = Math.random();
        }
        return random;
    }
}
//# sourceMappingURL=random-util.js.map
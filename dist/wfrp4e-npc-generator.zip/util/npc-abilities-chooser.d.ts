import { ItemData } from '@league-of-foundry-developers/foundry-vtt-types/src/foundry/common/data/data.mjs';
export default class NpcAbilitiesChooser {
    static selectNpcAbilities(initSkills: ItemData[], initTalents: ItemData[], initTraits: ItemData[], callback: (skills: ItemData[], talents: ItemData[], traits: ItemData[]) => void, undo?: () => void): Promise<void>;
}

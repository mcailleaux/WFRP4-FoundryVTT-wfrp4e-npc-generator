import StringUtil from './string-util.js';
import deburr from './lodash/deburr.js';
import RandomUtil from './random-util.js';
export default class EntityUtil {
    static match(item, ref) {
        return (StringUtil.getSimpleName(item.name) ===
            StringUtil.getSimpleName(ref.name) ||
            StringUtil.getSimpleName(item.name) ===
                StringUtil.getSimpleName(ref.data.originalName));
    }
    static toSelectOption(items) {
        var _a;
        if (items == null) {
            return {};
        }
        const map = {};
        for (let item of items) {
            if (map[item._id] == null) {
                map[item._id] = (_a = item.displayName) !== null && _a !== void 0 ? _a : item.name;
            }
        }
        return map;
    }
    static toSelectOptionGroup(items) {
        if (items == null) {
            return {};
        }
        const map = {};
        for (let group of Object.keys(items)) {
            map[group] = this.toSelectOption(items[group]);
        }
        return map;
    }
    static toMinimalName(value) {
        let result = deburr(value).toLowerCase().trim();
        result = result.replace(/\s/g, '');
        result = result.replace(/\(/g, '');
        result = result.replace(/\)/g, '');
        return result;
    }
    static find(name, entities) {
        var _a, _b, _c;
        if (name == null || (entities === null || entities === void 0 ? void 0 : entities.length) <= 0) {
            return null;
        }
        const matchName = StringUtil.toDeburrLowerCase(name).trim();
        let findByVo = false;
        let findByVoExactMatch = false;
        const hasBabele = (_c = ((_b = (_a = game === null || game === void 0 ? void 0 : game.babele) === null || _a === void 0 ? void 0 : _a.modules) === null || _b === void 0 ? void 0 : _b.length) > 0) !== null && _c !== void 0 ? _c : false;
        let result = entities.find((e) => (!hasBabele || e.data.hasTranslation) &&
            StringUtil.equalsDeburrIgnoreCase(e.name.trim(), matchName));
        if (result == null) {
            result = entities.find((e) => {
                var _a;
                return StringUtil.equalsDeburrIgnoreCase((_a = e.data.originalName) === null || _a === void 0 ? void 0 : _a.trim(), matchName);
            });
            findByVo = result != null;
            findByVoExactMatch = result != null;
        }
        if (result == null) {
            const simpleMatchName = StringUtil.toDeburrLowerCase(StringUtil.getSimpleName(name)).trim();
            result = entities.find((e) => (!hasBabele || e.data.hasTranslation) &&
                StringUtil.equalsDeburrIgnoreCase(StringUtil.getSimpleName(e.name).trim(), simpleMatchName));
            if (result == null) {
                result = entities.find((e) => {
                    var _a;
                    return StringUtil.equalsDeburrIgnoreCase((_a = StringUtil.getSimpleName(e.data.originalName)) === null || _a === void 0 ? void 0 : _a.trim(), simpleMatchName);
                });
                findByVo = result != null;
            }
        }
        if (result != null) {
            const data = duplicate(result.data);
            data._id = RandomUtil.getRandomId();
            if (findByVo) {
                if (!findByVoExactMatch && name.includes('(')) {
                    const tradSimpleName = StringUtil.getSimpleName(data.name).trim();
                    const groupName = StringUtil.getGroupName(name).trim();
                    data.name = `${tradSimpleName} (${groupName})`;
                }
            }
            else {
                data.name = name;
            }
            return data;
        }
        return null;
    }
    static hasGroupName(name) {
        return (name === null || name === void 0 ? void 0 : name.includes('(')) && (name === null || name === void 0 ? void 0 : name.includes(')'));
    }
}
//# sourceMappingURL=entity-util.js.map
import StringUtil from './string-util.js';
import deburr from './lodash/deburr.js';
import RandomUtil from './random-util.js';
import { babele, i18n } from '../constant.js';
export default class EntityUtil {
    static match(item, ref) {
        var _a, _b, _c;
        return (StringUtil.getSimpleName(item.name) ===
            StringUtil.getSimpleName(ref.name) ||
            StringUtil.getSimpleName(item.name) ===
                StringUtil.getSimpleName((_c = (_b = (_a = ref.data) === null || _a === void 0 ? void 0 : _a.flags) === null || _b === void 0 ? void 0 : _b.babele) === null || _c === void 0 ? void 0 : _c.originalName));
    }
    static toSelectOption(items) {
        var _a, _b, _c;
        if (items == null) {
            return {};
        }
        const map = {};
        for (let item of items) {
            if (map[item._id] == null) {
                try {
                    map[item._id] = (_b = (_a = item.displayName) !== null && _a !== void 0 ? _a : item.DisplayName) !== null && _b !== void 0 ? _b : item.name;
                }
                catch (e) {
                    map[item._id] = (_c = item.displayName) !== null && _c !== void 0 ? _c : item.name;
                }
            }
        }
        return map;
    }
    static toSelectOptionGroup(items) {
        if (items == null) {
            return {};
        }
        const map = {};
        for (let group of Object.keys(items)) {
            map[group] = this.toSelectOption(items[group]);
        }
        return map;
    }
    static toMinimalName(value) {
        let result = deburr(value).toLowerCase().trim();
        result = result.replace(/\s/g, '');
        result = result.replace(/\(/g, '');
        result = result.replace(/\)/g, '');
        return result;
    }
    static find(name, entities) {
        var _a, _b, _c, _d, _e, _f;
        if (name == null || (entities === null || entities === void 0 ? void 0 : entities.length) <= 0) {
            return null;
        }
        const matchName = StringUtil.toDeburrLowerCase(name).trim();
        let findByVo = false;
        let findByVoExactMatch = false;
        const hasBabele = (_c = ((_b = (_a = babele()) === null || _a === void 0 ? void 0 : _a.modules) === null || _b === void 0 ? void 0 : _b.length) > 0) !== null && _c !== void 0 ? _c : false;
        let result = entities.find((e) => {
            var _a, _b;
            return (!hasBabele || ((_b = (_a = e.flags) === null || _a === void 0 ? void 0 : _a.babele) === null || _b === void 0 ? void 0 : _b.hasTranslation)) &&
                StringUtil.equalsDeburrIgnoreCase(e.name.trim(), matchName);
        });
        if (result == null) {
            result = entities.find((e) => {
                var _a, _b, _c;
                return StringUtil.equalsDeburrIgnoreCase((_c = (_b = (_a = e.flags) === null || _a === void 0 ? void 0 : _a.babele) === null || _b === void 0 ? void 0 : _b.originalName) === null || _c === void 0 ? void 0 : _c.trim(), matchName);
            });
            findByVo = result != null;
            findByVoExactMatch = result != null;
        }
        if (result == null) {
            const simpleMatchName = StringUtil.toDeburrLowerCase(StringUtil.getSimpleName(name)).trim();
            result = entities.find((e) => {
                var _a, _b;
                return (!hasBabele || ((_b = (_a = e.flags) === null || _a === void 0 ? void 0 : _a.babele) === null || _b === void 0 ? void 0 : _b.hasTranslation)) &&
                    StringUtil.equalsDeburrIgnoreCase(StringUtil.getSimpleName(e.name).trim(), simpleMatchName);
            });
            if (result == null) {
                result = entities.find((e) => {
                    var _a, _b, _c;
                    return StringUtil.equalsDeburrIgnoreCase((_c = StringUtil.getSimpleName((_b = (_a = e.flags) === null || _a === void 0 ? void 0 : _a.babele) === null || _b === void 0 ? void 0 : _b.originalName)) === null || _c === void 0 ? void 0 : _c.trim(), simpleMatchName);
                });
                findByVo = result != null;
            }
        }
        if (result == null) {
            result = entities.find((e) => {
                var _a, _b;
                return hasBabele &&
                    !((_b = (_a = e.flags) === null || _a === void 0 ? void 0 : _a.babele) === null || _b === void 0 ? void 0 : _b.hasTranslation) &&
                    StringUtil.equalsDeburrIgnoreCase(e.name.trim(), matchName);
            });
            findByVo = result != null;
            findByVoExactMatch = result != null;
        }
        if (result == null) {
            const simpleMatchName = StringUtil.toDeburrLowerCase(StringUtil.getSimpleName(name)).trim();
            result = entities.find((e) => {
                var _a, _b;
                return hasBabele &&
                    !((_b = (_a = e.flags) === null || _a === void 0 ? void 0 : _a.babele) === null || _b === void 0 ? void 0 : _b.hasTranslation) &&
                    StringUtil.equalsDeburrIgnoreCase(StringUtil.getSimpleName(e.name).trim(), simpleMatchName);
            });
            findByVo = result != null;
        }
        if (result != null) {
            const data = duplicate(result);
            const originalName = (_f = (_e = (_d = result.flags) === null || _d === void 0 ? void 0 : _d.babele) === null || _e === void 0 ? void 0 : _e.originalName) === null || _f === void 0 ? void 0 : _f.trim();
            const originalSimpleName = originalName != null && name.includes('(')
                ? StringUtil.getSimpleName(originalName)
                : null;
            data._id = RandomUtil.getRandomId();
            const simpleVoSameHasTranslate = originalSimpleName != null &&
                StringUtil.equalsDeburrIgnoreCase(originalSimpleName, StringUtil.getSimpleName(data.name));
            if (findByVo || simpleVoSameHasTranslate) {
                if (!findByVoExactMatch && name.includes('(')) {
                    const tradSimpleName = StringUtil.getSimpleName(data.name).trim();
                    let groupName = StringUtil.getGroupName(name).trim();
                    data.name = `${tradSimpleName} (${i18n().localize(groupName)})`;
                }
            }
            else {
                data.name = name;
            }
            return data;
        }
        return null;
    }
    static hasGroupName(name) {
        return (name === null || name === void 0 ? void 0 : name.includes('(')) && (name === null || name === void 0 ? void 0 : name.includes(')'));
    }
    static toRecords(arrays) {
        return arrays.map((d) => (d.toObject != null ? d.toObject() : d));
    }
}
//# sourceMappingURL=entity-util.js.map
export default class CreatureAbilities {
    includeBasicSkills: boolean;
    sizeKey: string;
    isSwarm: boolean;
    hasWeaponTrait: boolean;
    hasRangedTrait: boolean;
    hasArmourTrait: boolean;
    weaponDamage: string;
    rangedRange: string;
    rangedDamage: string;
    armourValue: string;
    speciesKey: string;
    traits: Item.Data[];
    talents: Item.Data[];
    skills: Item.Data[];
}

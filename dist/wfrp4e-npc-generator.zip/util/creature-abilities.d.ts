import { ItemData } from '@league-of-foundry-developers/foundry-vtt-types/src/foundry/common/data/data.mjs';
export default class CreatureAbilities {
    includeBasicSkills: boolean;
    sizeKey: string;
    isSwarm: boolean;
    hasWeaponTrait: boolean;
    hasRangedTrait: boolean;
    hasArmourTrait: boolean;
    weaponDamage: string;
    rangedRange: string;
    rangedDamage: string;
    armourValue: string;
    speciesKey: string;
    traits: ItemData[];
    talents: ItemData[];
    skills: ItemData[];
    excludedTraits: string[];
}

import { GenerateEffectOptionEnum, getGenerateEffectOptionEnum, } from './generate-effect-option.enum.js';
import RegisterSettings from './register-settings.js';
import { settings } from '../constant.js';
export default class OptionsCreature {
    constructor() {
        this.withClassTrappings = false;
        this.withCareerTrappings = false;
        this.generateMoneyEffect = getGenerateEffectOptionEnum(settings().get(RegisterSettings.moduleName, 'defaultCreatureGenerateMoneyEffect'));
        this.generateWeaponEffect = GenerateEffectOptionEnum.NONE;
        this.withGenPathCareerName = false;
        this.withLinkedToken = settings().get(RegisterSettings.moduleName, 'defaultCreatureWithLinkedToken');
        this.withInitialMoney = settings().get(RegisterSettings.moduleName, 'defaultCreatureWithInitialMoney');
        this.withInitialWeapons = false;
        this.genPath = settings().get(RegisterSettings.moduleName, 'defaultCreatureGenPath');
        this.imagePath = null;
        this.tokenPath = null;
        this.editAbilities = false;
        this.editTrappings = settings().get(RegisterSettings.moduleName, 'defaultCreatureEditTrappings');
        this.addMagics = settings().get(RegisterSettings.moduleName, 'defaultCreatureAddMagics');
        this.addMutations = settings().get(RegisterSettings.moduleName, 'defaultCreatureAddMutations');
    }
}
//# sourceMappingURL=options-creature.js.map
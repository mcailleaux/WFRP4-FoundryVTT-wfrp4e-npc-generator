import { ActorData, ItemData } from '@league-of-foundry-developers/foundry-vtt-types/src/foundry/common/data/data.mjs';
export default class CreatureTemplate {
    creatureData: ActorData & any;
    size: string;
    swarm: ItemData & any;
    weapon: ItemData & any;
    ranged: ItemData & any;
    armour: ItemData & any;
    isSwarm: boolean;
    hasWeaponTrait: boolean;
    hasArmourTrait: boolean;
    weaponDamage: string;
    rangedRange: string;
    rangedDamage: string;
    armourValue: string;
    excludedTraits: string[];
}

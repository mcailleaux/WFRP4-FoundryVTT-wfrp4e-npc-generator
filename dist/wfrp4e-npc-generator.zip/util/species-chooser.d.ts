export default class SpeciesChooser {
    static selectSpecies(initSpeciesKey: string, callback: (speciesKey: string, speciesValue: string) => void): Promise<void>;
}

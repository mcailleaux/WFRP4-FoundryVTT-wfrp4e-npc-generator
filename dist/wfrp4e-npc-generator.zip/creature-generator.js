var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import CompendiumUtil from './util/compendium-util.js';
import CheckDependencies from './check-dependencies.js';
import CreatureModel from './creature-model.js';
import CreatureChooser from './util/creature-chooser.js';
import NameChooser from './util/name-chooser.js';
import ReferentialUtil from './util/referential-util.js';
import TranslateErrorDetect from './util/translate-error-detect.js';
import StringUtil from './util/string-util.js';
import EntityUtil from './util/entity-util.js';
import CreatureAbilitiesChooser from './util/creature-abilities-chooser.js';
import CreatureAbilities from './util/creature-abilities.js';
import CreatureTemplate from './util/creature-template.js';
import OptionsChooser from './util/options.chooser.js';
import WaiterUtil from './util/waiter-util.js';
import TrappingChooser from './util/trapping-chooser.js';
import MagicsChooser from './util/magics-chooser.js';
import MutationsChooser from './util/mutations-chooser.js';
import CreatureBuilder from './creature-builder.js';
import RandomUtil from './util/random-util.js';
export default class CreatureGenerator {
    static generateCreature(callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.compendium.initCompendium(() => __awaiter(this, void 0, void 0, function* () {
                yield this.generateCreatureModel((model) => __awaiter(this, void 0, void 0, function* () {
                    const actorData = yield CreatureBuilder.buildCreatureData(model);
                    const actor = yield CreatureBuilder.createCreature(model, actorData);
                    ui.notifications.info(game.i18n.format('WFRP4NPCGEN.notification.creature.created', {
                        name: actor.name,
                    }));
                    yield WaiterUtil.hide();
                    if (callback != null) {
                        callback(model, actorData, actor);
                    }
                }));
            }), true);
        });
    }
    static generateCreatureModel(callback) {
        return __awaiter(this, void 0, void 0, function* () {
            const creatureModel = new CreatureModel();
            CheckDependencies.check((canRun) => {
                if (canRun) {
                    this.selectCreature(creatureModel, callback);
                }
            });
        });
    }
    static selectCreature(model, callback) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            yield this.creatureChooser.selectCreature((_a = model.creatureTemplate.creatureData) === null || _a === void 0 ? void 0 : _a._id, (creature) => __awaiter(this, void 0, void 0, function* () {
                var _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u;
                model.creatureTemplate = new CreatureTemplate();
                model.abilities = new CreatureAbilities();
                model.trappings = [];
                model.spells = [];
                model.prayers = [];
                model.physicalMutations = [];
                model.mentalMutations = [];
                model.creatureTemplate.creatureData = creature;
                const swarm = yield this.compendium.getCompendiumSwarmTrait();
                const weapon = yield this.compendium.getCompendiumWeaponTrait();
                const armour = yield this.compendium.getCompendiumArmourTrait();
                const ranged = yield this.compendium.getCompendiumRangedTrait();
                const size = yield this.compendium.getCompendiumSizeTrait();
                model.creatureTemplate.size = (_d = (_c = (_b = creature.data) === null || _b === void 0 ? void 0 : _b.details) === null || _c === void 0 ? void 0 : _c.size) === null || _d === void 0 ? void 0 : _d.value;
                model.creatureTemplate.swarm = (_e = duplicate(creature.traits)) === null || _e === void 0 ? void 0 : _e.find((t) => EntityUtil.match(t, swarm));
                model.creatureTemplate.isSwarm =
                    model.creatureTemplate.swarm != null &&
                        model.creatureTemplate.swarm.included;
                model.creatureTemplate.weapon = (_f = duplicate(creature.traits)) === null || _f === void 0 ? void 0 : _f.find((t) => EntityUtil.match(t, weapon));
                model.creatureTemplate.hasWeaponTrait =
                    model.creatureTemplate.weapon != null &&
                        model.creatureTemplate.weapon.included;
                model.creatureTemplate.armour = (_g = duplicate(creature.traits)) === null || _g === void 0 ? void 0 : _g.find((t) => EntityUtil.match(t, armour));
                model.creatureTemplate.hasArmourTrait =
                    model.creatureTemplate.armour != null &&
                        model.creatureTemplate.armour.included;
                model.creatureTemplate.ranged = (_h = duplicate(creature.traits)) === null || _h === void 0 ? void 0 : _h.find((t) => EntityUtil.match(t, ranged));
                if (model.creatureTemplate.armour != null) {
                    model.creatureTemplate.armourValue = StringUtil.getGroupName(model.creatureTemplate.armour.displayName);
                }
                if (model.creatureTemplate.weapon != null) {
                    model.creatureTemplate.weaponDamage =
                        model.creatureTemplate.weapon.data.specification.value;
                }
                if (model.creatureTemplate.ranged != null) {
                    model.creatureTemplate.rangedRange = StringUtil.getGroupName(model.creatureTemplate.ranged.name);
                    model.creatureTemplate.rangedDamage =
                        model.creatureTemplate.ranged.data.specification.value;
                    if ((_j = model.creatureTemplate.rangedDamage) === null || _j === void 0 ? void 0 : _j.includes('+')) {
                        model.creatureTemplate.rangedDamage = model.creatureTemplate.rangedDamage.replace('+', '');
                    }
                }
                model.abilities.includeBasicSkills = ((_k = creature.basicSkills) === null || _k === void 0 ? void 0 : _k.length) > 0;
                model.abilities.sizeKey = (_o = (_m = (_l = creature.data) === null || _l === void 0 ? void 0 : _l.details) === null || _m === void 0 ? void 0 : _m.size) === null || _o === void 0 ? void 0 : _o.value;
                model.abilities.isSwarm = model.creatureTemplate.isSwarm;
                model.abilities.hasWeaponTrait = model.creatureTemplate.hasWeaponTrait;
                model.abilities.hasArmourTrait =
                    model.creatureTemplate.armour != null &&
                        model.creatureTemplate.armour.included;
                model.abilities.hasRangedTrait =
                    model.creatureTemplate.ranged != null &&
                        model.creatureTemplate.ranged.included;
                model.abilities.weaponDamage = model.creatureTemplate.weaponDamage;
                model.abilities.rangedRange = model.creatureTemplate.rangedRange;
                model.abilities.rangedDamage = model.creatureTemplate.rangedDamage;
                model.abilities.armourValue = model.creatureTemplate.armourValue;
                const traits = creature.traits.filter((t) => {
                    return (!EntityUtil.match(t, swarm) &&
                        !EntityUtil.match(t, weapon) &&
                        !EntityUtil.match(t, armour) &&
                        !EntityUtil.match(t, ranged) &&
                        !EntityUtil.match(t, size));
                });
                const compendiumTraits = yield ReferentialUtil.getTraitEntities(true);
                for (let trait of traits) {
                    const finalTrait = duplicate((_q = (_p = compendiumTraits.find((t) => t.data.name === trait.displayName ||
                        t.data.originalName === trait.displayName)) === null || _p === void 0 ? void 0 : _p.data) !== null && _q !== void 0 ? _q : trait);
                    finalTrait.displayName = trait.displayName;
                    finalTrait.included = trait.included;
                    model.abilities.traits.push(finalTrait);
                }
                const skills = creature.skills.filter((s) => {
                    return s.data.advances.value > 0;
                });
                const compendiumSkills = yield ReferentialUtil.getSkillEntities(true);
                for (let skill of skills) {
                    const finalSkill = (_s = (_r = compendiumSkills.find((s) => s.data.name === skill.name || s.data.originalName === skill.name)) === null || _r === void 0 ? void 0 : _r.data) !== null && _s !== void 0 ? _s : skill;
                    finalSkill.data.advances.value = skill.data.advances.value;
                    model.abilities.skills.push(duplicate(finalSkill));
                }
                const talents = creature.talents;
                const compendiumTalents = yield ReferentialUtil.getTalentEntities(true);
                for (let talent of talents) {
                    const finalTalent = (_u = (_t = compendiumTalents.find((t) => t.data.name === talent.name ||
                        t.data.originalName === talent.name)) === null || _t === void 0 ? void 0 : _t.data) !== null && _u !== void 0 ? _u : talent;
                    finalTalent.data.advances.value = talent.data.advances.value;
                    model.abilities.talents.push(duplicate(finalTalent));
                }
                for (let inventory of Object.values(creature.inventory)) {
                    model.trappings.push(...inventory.items);
                }
                const spells = yield ReferentialUtil.getSpellEntities();
                const prayers = yield ReferentialUtil.getPrayerEntities();
                const physicals = yield ReferentialUtil.getPhysicalMutationEntities();
                const mentals = yield ReferentialUtil.getMentalMutationEntities();
                model.spells = [
                    ...creature.petty.map((p) => {
                        const spell = spells.find((s) => s.name === p.name);
                        return spell != null ? duplicate(spell.data) : p;
                    }),
                    ...creature.grimoire.map((g) => {
                        const spell = spells.find((s) => s.name === g.name);
                        return spell != null ? duplicate(spell.data) : g;
                    }),
                ];
                model.prayers = [
                    ...creature.blessings.map((b) => {
                        const prayer = prayers.find((p) => p.name === b.name);
                        return prayer != null ? duplicate(prayer.data) : b;
                    }),
                    ...creature.miracles.map((m) => {
                        const prayer = prayers.find((p) => p.name === m.name);
                        return prayer != null ? duplicate(prayer.data) : m;
                    }),
                ];
                model.physicalMutations = creature.mutations
                    .filter((m) => m.data.mutationType.value === 'physical')
                    .map((m) => {
                    const mutation = physicals.find((p) => p.name === m.name);
                    return mutation != null ? duplicate(mutation.data) : m;
                });
                model.mentalMutations = creature.mutations
                    .filter((m) => m.data.mutationType.value === 'mental')
                    .map((m) => {
                    const mutation = mentals.find((p) => p.name === m.name);
                    return mutation != null ? duplicate(mutation.data) : m;
                });
                yield this.selectCreatureAbilities(model, callback);
            }));
        });
    }
    static selectCreatureAbilities(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.creatureAbilitiesChooser.selectCreatureAbilities(model.abilities, (abilities) => {
                model.abilities = abilities;
                this.selectName(model, callback);
            }, () => {
                this.selectCreature(model, callback);
            });
        });
    }
    static selectName(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            if (model.name == null) {
                const swarm = yield this.compendium.getCompendiumSwarmTrait();
                const swarmLabel = model.abilities.isSwarm ? `, ${swarm.name}` : '';
                model.name = `${model.creatureTemplate.creatureData.name} (${this.compendium.getSizes()[model.abilities.sizeKey]}${swarmLabel})`;
            }
            yield this.nameChooser.selectName(model.name, model.abilities.speciesKey, model.abilities.speciesKey != 'none', (name) => {
                model.name = name;
                this.selectOptions(model, callback);
            }, () => {
                this.selectCreatureAbilities(model, callback);
            });
        });
    }
    static selectOptions(model, callback) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            model.options.imagePath = (_a = model.creatureTemplate.creatureData.img) !== null && _a !== void 0 ? _a : '';
            model.options.tokenPath = (_c = (_b = model.creatureTemplate.creatureData.token) === null || _b === void 0 ? void 0 : _b.img) !== null && _c !== void 0 ? _c : '';
            yield this.optionsChooser.selectOptions(true, model.options, 'creature', (options) => {
                model.options = options;
                this.finalize(model, callback);
            }, () => {
                this.selectName(model, callback);
            });
        });
    }
    static finalize(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield WaiterUtil.show('WFRP4NPCGEN.creature.generation.inprogress.title', 'WFRP4NPCGEN.creature.generation.inprogress.hint', () => __awaiter(this, void 0, void 0, function* () {
                console.log('Prepare Basic skills');
                yield this.addBasicSkill(model);
                console.log('Prepare Basic Chars');
                yield this.addBasicChars(model);
                console.log('Prepare Swarm');
                yield this.addSwarm(model);
                console.log('Prepare Size');
                yield this.addSize(model);
                console.log('Prepare Weapon');
                yield this.addWeapon(model);
                console.log('Prepare Ranged');
                yield this.addRanged(model);
                console.log('Prepare Armour');
                yield this.addArmour(model);
                yield this.editTrappings(model, callback);
            }));
        });
    }
    static editTrappings(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            if (model.options.editTrappings) {
                yield WaiterUtil.hide(false);
                yield this.trappingChooser.selectTrappings(model.trappings, (trappings) => __awaiter(this, void 0, void 0, function* () {
                    model.trappings = trappings;
                    yield this.editMagics(model, callback);
                }));
            }
            else {
                yield this.editMagics(model, callback);
            }
        });
    }
    static editMagics(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            if (model.options.addMagics) {
                const undo = model.options.editTrappings
                    ? () => {
                        this.editTrappings(model, callback);
                    }
                    : undefined;
                yield WaiterUtil.hide(false);
                yield this.magicsChooser.selectMagics(model.spells, model.prayers, (spells, prayers) => __awaiter(this, void 0, void 0, function* () {
                    model.spells = spells;
                    model.prayers = prayers;
                    yield this.editMutations(model, callback);
                }), undo);
            }
            else {
                yield this.editMutations(model, callback);
            }
        });
    }
    static editMutations(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            if (model.options.addMutations) {
                const undo = model.options.addMagics
                    ? () => {
                        this.editMagics(model, callback);
                    }
                    : model.options.editTrappings
                        ? () => {
                            this.editTrappings(model, callback);
                        }
                        : undefined;
                yield WaiterUtil.hide(false);
                yield this.mutationsChooser.selectMutations(model.physicalMutations, model.mentalMutations, (physicals, mentals) => __awaiter(this, void 0, void 0, function* () {
                    yield WaiterUtil.show('WFRP4NPCGEN.creature.generation.inprogress.title', 'WFRP4NPCGEN.creature.generation.inprogress.hint', () => __awaiter(this, void 0, void 0, function* () {
                        model.physicalMutations = physicals;
                        model.mentalMutations = mentals;
                        callback(model);
                    }));
                }), undo);
            }
            else {
                yield WaiterUtil.show('WFRP4NPCGEN.creature.generation.inprogress.title', 'WFRP4NPCGEN.creature.generation.inprogress.hint', () => __awaiter(this, void 0, void 0, function* () {
                    callback(model);
                }));
            }
        });
    }
    static addBasicSkill(model) {
        return __awaiter(this, void 0, void 0, function* () {
            if (model.abilities.includeBasicSkills) {
                const skills = yield this.referential.getAllBasicSkills();
                for (let skill of skills) {
                    const existingSkill = model.abilities.skills.find((s) => s.name === skill.name);
                    if (existingSkill == null) {
                        model.abilities.skills.push(skill);
                    }
                }
            }
        });
    }
    static addBasicChars(model) {
        return __awaiter(this, void 0, void 0, function* () {
            Object.entries(model.creatureTemplate.creatureData.data.characteristics).forEach(([key, char]) => {
                let initial = char.value;
                if (initial > 0) {
                    const positive = RandomUtil.getRandomBoolean();
                    const amplitude = RandomUtil.getRandomPositiveNumber(6);
                    const adjust = (positive ? 1 : -1) * RandomUtil.getRandomPositiveNumber(amplitude);
                    initial = Math.max(1, initial + adjust);
                }
                model.chars[key] = {
                    initial: initial,
                    advances: 0,
                };
            });
            if (model.creatureTemplate.isSwarm) {
                model.chars.ws.initial -= 10;
            }
            const fromSize = ReferentialUtil.sortedSize.indexOf(model.creatureTemplate.size);
            const toSize = ReferentialUtil.sortedSize.indexOf(model.abilities.sizeKey);
            const sizeRatio = Math.abs(toSize - fromSize);
            const smallToBig = toSize > fromSize;
            if (sizeRatio > 0) {
                model.chars.s.initial += sizeRatio * 10 * (smallToBig ? 1 : -1);
                model.chars.t.initial += sizeRatio * 10 * (smallToBig ? 1 : -1);
                model.chars.ag.initial += sizeRatio * 5 * (smallToBig ? -1 : 1);
            }
            Object.entries(model.chars).forEach(([_key, char]) => {
                if (char.initial < 0) {
                    char.initial = 0;
                }
            });
        });
    }
    static addSwarm(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const swarm = duplicate((yield this.compendium.getCompendiumSwarmTrait()).data);
            if (model.abilities.isSwarm) {
                model.abilities.traits.push(swarm);
                swarm.included = true;
            }
            else if (model.creatureTemplate.swarm != null) {
                swarm.included = false;
                model.abilities.traits.push(swarm);
            }
        });
    }
    static addSize(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const size = duplicate((yield this.compendium.getCompendiumSizeTrait()).data);
            size.data.specification.value = this.compendium.getSizes()[model.abilities.sizeKey];
            size.included = true;
            model.abilities.traits.push(size);
        });
    }
    static addWeapon(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const weapon = duplicate((yield this.compendium.getCompendiumWeaponTrait()).data);
            if (model.abilities.hasWeaponTrait) {
                weapon.data.specification.value = Number.isNumeric(model.abilities.weaponDamage)
                    ? Number(model.abilities.weaponDamage)
                    : 0;
                weapon.included = true;
                model.abilities.traits.push(weapon);
            }
            else if (model.creatureTemplate.weapon != null) {
                weapon.data.specification.value = Number.isNumeric(model.abilities.weaponDamage)
                    ? Number(model.abilities.weaponDamage)
                    : Number.isNumeric(model.creatureTemplate.weaponDamage)
                        ? Number(model.creatureTemplate.weaponDamage)
                        : 0;
                weapon.included = false;
                model.abilities.traits.push(weapon);
            }
        });
    }
    static addRanged(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const ranged = duplicate((yield this.compendium.getCompendiumRangedTrait()).data);
            const defaultRange = StringUtil.getGroupName(ranged.name);
            const defaultDamage = ranged.data.specification.value;
            if (model.abilities.hasRangedTrait) {
                const range = Number.isNumeric(model.abilities.rangedRange)
                    ? model.abilities.rangedRange
                    : defaultRange;
                const damage = Number.isNumeric(model.abilities.rangedDamage)
                    ? model.abilities.rangedDamage
                    : defaultDamage;
                ranged.name = `${StringUtil.getSimpleName(ranged.name).trim()} (${range})`;
                ranged.data.specification.value = damage;
                ranged.included = true;
                model.abilities.traits.push(ranged);
            }
            else if (model.creatureTemplate.ranged != null) {
                const range = Number.isNumeric(model.abilities.rangedRange)
                    ? model.abilities.rangedRange
                    : Number.isNumeric(model.creatureTemplate.rangedRange)
                        ? model.creatureTemplate.rangedRange
                        : defaultRange;
                const damage = Number.isNumeric(model.abilities.rangedDamage)
                    ? model.abilities.rangedDamage
                    : Number.isNumeric(model.creatureTemplate.rangedDamage)
                        ? model.creatureTemplate.rangedDamage
                        : defaultDamage;
                ranged.name = `${StringUtil.getSimpleName(ranged.name).trim()} (${range})`;
                ranged.data.specification.value = damage;
                ranged.included = false;
                model.abilities.traits.push(ranged);
            }
        });
    }
    static addArmour(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const armour = duplicate((yield this.compendium.getCompendiumArmourTrait()).data);
            if (model.abilities.hasArmourTrait) {
                armour.data.specification.value = Number.isNumeric(model.abilities.armourValue)
                    ? Number(model.abilities.armourValue)
                    : 1;
                armour.included = true;
                model.abilities.traits.push(armour);
            }
            else if (model.creatureTemplate.armour != null) {
                armour.data.specification.value = Number.isNumeric(model.abilities.armourValue)
                    ? Number(model.abilities.armourValue)
                    : Number.isNumeric(model.creatureTemplate.armourValue)
                        ? Number(model.creatureTemplate.armourValue)
                        : 0;
                armour.included = false;
                model.abilities.traits.push(armour);
            }
        });
    }
}
CreatureGenerator.creatureChooser = CreatureChooser;
CreatureGenerator.creatureAbilitiesChooser = CreatureAbilitiesChooser;
CreatureGenerator.nameChooser = NameChooser;
CreatureGenerator.optionsChooser = OptionsChooser;
CreatureGenerator.trappingChooser = TrappingChooser;
CreatureGenerator.magicsChooser = MagicsChooser;
CreatureGenerator.mutationsChooser = MutationsChooser;
CreatureGenerator.referential = ReferentialUtil;
CreatureGenerator.compendium = CompendiumUtil;
CreatureGenerator.translateErrorDetect = TranslateErrorDetect;
//# sourceMappingURL=creature-generator.js.map
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import ReferentialUtil from './util/referential-util.js';
import { GenerateEffectOptionEnum } from './util/generate-effect-option.enum.js';
export class ActorBuilder {
    static buildActorData(model, type) {
        return __awaiter(this, void 0, void 0, function* () {
            const moneyItems = yield ReferentialUtil.getAllMoneyItems();
            const actorData = {
                name: model.name,
                type: type,
                flags: {
                    autoCalcRun: true,
                    autoCalcWalk: true,
                    autoCalcWounds: true,
                    autoCalcCritW: true,
                    autoCalcCorruption: true,
                    autoCalcEnc: true,
                    autoCalcSize: true,
                },
                data: {
                    characteristics: model.chars,
                    details: {
                        move: {
                            value: model.move,
                        },
                        species: {
                            value: model.speciesValue,
                        },
                        status: {
                            value: model.status,
                        },
                    },
                },
                items: [...model.careerPath, ...moneyItems, ...model.trappings],
            };
            return Promise.resolve(actorData);
        });
    }
    static createActor(model, data) {
        return __awaiter(this, void 0, void 0, function* () {
            const actor = yield Actor.create(data);
            for (let skill of model.skills) {
                yield actor.createOwnedItem(skill);
            }
            for (let talent of model.talents) {
                yield actor.createOwnedItem(talent);
            }
            if (GenerateEffectOptionEnum.NONE !== model.options.generateMoneyEffect) {
                yield this.addGenerateTokenEffect(actor, 'WFRP4NPCGEN.trappings.money.label', GenerateEffectOptionEnum.DEFAULT_DISABLED ===
                    model.options.generateMoneyEffect, 'modules/wfrp4e-core/art/other/gold.webp');
            }
            if (GenerateEffectOptionEnum.NONE !== model.options.generateWeaponEffect) {
                yield this.addGenerateTokenEffect(actor, 'WFRP4NPCGEN.trappings.weapon.label', GenerateEffectOptionEnum.DEFAULT_DISABLED ===
                    model.options.generateWeaponEffect, 'modules/wfrp4e-core/art/other/weapons.webp');
            }
            return Promise.resolve(actor);
        });
    }
    static addGenerateTokenEffect(actor, label, disabled, icon) {
        return __awaiter(this, void 0, void 0, function* () {
            const generateEffect = {
                icon: icon,
                label: game.i18n.localize(label),
                disabled: disabled,
            };
            generateEffect['flags.wfrp4e.effectApplication'] = 'actor';
            yield actor.createEmbeddedEntity('ActiveEffect', generateEffect);
        });
    }
}
//# sourceMappingURL=actor-builder.js.map
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { GenerateEffectOptionEnum } from './util/generate-effect-option.enum.js';
import FolderUtil from './util/folder-util.js';
import TrappingUtil from './util/trapping-util.js';
import { i18n } from './constant.js';
import EntityUtil from './util/entity-util.js';
export class ActorBuilder {
    static buildActorData(model, type) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const actorData = {
                name: model.name,
                type: type,
                flags: {
                    autoCalcRun: true,
                    autoCalcWalk: true,
                    autoCalcWounds: true,
                    autoCalcCritW: true,
                    autoCalcCorruption: true,
                    autoCalcEnc: true,
                    autoCalcSize: true,
                },
                data: {
                    characteristics: model.chars,
                    details: {
                        move: {
                            value: model.move,
                        },
                        species: {
                            value: model.speciesValue,
                        },
                        status: {
                            value: model.status,
                        },
                    },
                },
                items: [...model.careerPath],
            };
            if (((_a = model.options) === null || _a === void 0 ? void 0 : _a.imagePath) != null &&
                model.options.imagePath.length > 0) {
                actorData.img = model.options.imagePath;
            }
            return Promise.resolve(actorData);
        });
    }
    static createActor(model, data) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s;
        return __awaiter(this, void 0, void 0, function* () {
            if (((_b = (_a = model === null || model === void 0 ? void 0 : model.options) === null || _a === void 0 ? void 0 : _a.genPath) === null || _b === void 0 ? void 0 : _b.length) > 0) {
                const genPaths = (_c = model === null || model === void 0 ? void 0 : model.options) === null || _c === void 0 ? void 0 : _c.genPath.split('/').filter((p) => p != null && p.length > 0);
                if ((_d = model === null || model === void 0 ? void 0 : model.options) === null || _d === void 0 ? void 0 : _d.withGenPathCareerName) {
                    const careerData = (_e = model.career) === null || _e === void 0 ? void 0 : _e.data;
                    genPaths.push((_f = careerData === null || careerData === void 0 ? void 0 : careerData.careergroup) === null || _f === void 0 ? void 0 : _f.value);
                }
                const folder = yield FolderUtil.createNamedFolder(genPaths.join('/'));
                data.folder = folder === null || folder === void 0 ? void 0 : folder.id;
            }
            let actor = yield Actor.create(data);
            yield actor.createEmbeddedDocuments(Item.metadata.name, EntityUtil.toRecords(model.skills));
            yield actor.createEmbeddedDocuments(Item.metadata.name, EntityUtil.toRecords(model.talents));
            if (model.traits.length > 0) {
                yield actor.createEmbeddedDocuments(Item.metadata.name, EntityUtil.toRecords(model.traits));
            }
            if (model.trappings.length > 0) {
                yield actor.createEmbeddedDocuments(Item.metadata.name, EntityUtil.toRecords(model.trappings));
            }
            if (model.spells.length > 0) {
                yield actor.createEmbeddedDocuments(Item.metadata.name, EntityUtil.toRecords(model.spells));
            }
            if (model.prayers.length > 0) {
                yield actor.createEmbeddedDocuments(Item.metadata.name, EntityUtil.toRecords(model.prayers));
            }
            if (model.physicalMutations.length > 0) {
                yield actor.createEmbeddedDocuments(Item.metadata.name, EntityUtil.toRecords(model.physicalMutations));
            }
            if (model.mentalMutations.length > 0) {
                yield actor.createEmbeddedDocuments(Item.metadata.name, EntityUtil.toRecords(model.mentalMutations));
            }
            for (const career of (_g = actor.itemCategories) === null || _g === void 0 ? void 0 : _g.career) {
                yield actor.updateEmbeddedDocuments(Item.metadata.name, [
                    {
                        _id: career.id,
                        'data.complete.value': true,
                    },
                ]);
            }
            yield TrappingUtil.initMoney(actor);
            if ((_h = model === null || model === void 0 ? void 0 : model.options) === null || _h === void 0 ? void 0 : _h.withInitialMoney) {
                yield TrappingUtil.generateMoney(actor);
            }
            if ((_j = model === null || model === void 0 ? void 0 : model.options) === null || _j === void 0 ? void 0 : _j.withInitialWeapons) {
                yield TrappingUtil.generateWeapons(actor);
            }
            if (!((_k = model === null || model === void 0 ? void 0 : model.options) === null || _k === void 0 ? void 0 : _k.withLinkedToken) &&
                !((_l = model === null || model === void 0 ? void 0 : model.options) === null || _l === void 0 ? void 0 : _l.withInitialMoney) &&
                GenerateEffectOptionEnum.NONE !== model.options.generateMoneyEffect) {
                yield this.addGenerateTokenEffect(actor, 'WFRP4NPCGEN.trappings.money.label', GenerateEffectOptionEnum.DEFAULT_DISABLED ===
                    model.options.generateMoneyEffect, 'modules/wfrp4e-core/art/other/gold.webp');
            }
            if (!((_m = model === null || model === void 0 ? void 0 : model.options) === null || _m === void 0 ? void 0 : _m.withLinkedToken) &&
                !((_o = model === null || model === void 0 ? void 0 : model.options) === null || _o === void 0 ? void 0 : _o.withInitialWeapons) &&
                GenerateEffectOptionEnum.NONE !== model.options.generateWeaponEffect) {
                yield this.addGenerateTokenEffect(actor, 'WFRP4NPCGEN.trappings.weapon.label', GenerateEffectOptionEnum.DEFAULT_DISABLED ===
                    model.options.generateWeaponEffect, 'modules/wfrp4e-core/art/other/weapons.webp');
            }
            const token = (_p = actor.data) === null || _p === void 0 ? void 0 : _p.token;
            const update = {};
            let performUpdate = false;
            if (token != null &&
                ((_q = model.options) === null || _q === void 0 ? void 0 : _q.tokenPath) != null &&
                model.options.tokenPath.length > 0) {
                performUpdate = true;
                update.img = model.options.tokenPath;
                update.randomImg = model.options.tokenPath.includes('*');
            }
            if (token != null && ((_r = model.options) === null || _r === void 0 ? void 0 : _r.withLinkedToken)) {
                performUpdate = true;
                update.actorLink = (_s = model.options) === null || _s === void 0 ? void 0 : _s.withLinkedToken;
            }
            if (performUpdate) {
                actor = (yield actor.update({
                    token: mergeObject(token, update, { inplace: false }),
                }));
            }
            return Promise.resolve(actor);
        });
    }
    static addGenerateTokenEffect(actor, label, disabled, icon) {
        return __awaiter(this, void 0, void 0, function* () {
            const generateEffect = {
                icon: icon,
                label: i18n().localize(label),
                disabled: disabled,
            };
            generateEffect['flags.wfrp4e.effectApplication'] = 'actor';
            yield actor.createEmbeddedDocuments(ActiveEffect.metadata.name, [
                generateEffect,
            ]);
        });
    }
}
//# sourceMappingURL=actor-builder.js.map
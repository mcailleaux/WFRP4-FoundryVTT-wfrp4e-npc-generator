export default class CheckDependencies {
    static check(callback) {
        var _a, _b, _c;
        const active = (_c = (_b = (_a = game.modules) === null || _a === void 0 ? void 0 : _a.get('wfrp4e-core')) === null || _b === void 0 ? void 0 : _b.active) !== null && _c !== void 0 ? _c : false;
        if (active) {
            callback(true);
        }
        else {
            new Dialog({
                title: game.i18n.localize('WFRP4NPCGEN.dependencies.miss.title'),
                content: `<form>
              <div class="form-group">
              <label>
                  ${game.i18n.localize('WFRP4NPCGEN.dependencies.miss.label')}          
              </label> 
              <input type="text" readonly value="wfrp4e-core"/>
              </div>
          </form>`,
                buttons: {
                    yes: {
                        icon: "<i class='fas fa-check'></i>",
                        label: game.i18n.localize('WFRP4NPCGEN.common.button.OK'),
                        callback: () => {
                            callback(false);
                        },
                    },
                },
                default: 'yes',
            }).render(true);
        }
    }
}
//# sourceMappingURL=check-dependencies.js.map
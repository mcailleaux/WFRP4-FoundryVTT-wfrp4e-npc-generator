import Options from './util/options.js';
export default class NpcModel {
    constructor() {
        this.selectedCareers = [];
        this.careerPath = [];
        this.careerForSkills = [];
        this.speciesSkills = {
            major: [],
            minor: [],
        };
        this.speciesTalents = [];
        this.speciesTraits = [];
        this.skills = [];
        this.talents = [];
        this.traits = [];
        this.trappingsStr = [];
        this.trappings = [];
        this.spells = [];
        this.prayers = [];
        this.physicalMutations = [];
        this.mentalMutations = [];
        this.chars = {};
        this.options = new Options();
    }
}
//# sourceMappingURL=npc-model.js.map
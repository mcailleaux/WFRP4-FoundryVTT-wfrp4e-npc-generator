import Options from './util/options.js';
export default class NpcModel {
    constructor() {
        this.careerPath = [];
        this.speciesSkills = {
            major: [],
            minor: [],
        };
        this.speciesTalents = [];
        this.skills = [];
        this.talents = [];
        this.trappingsStr = [];
        this.trappings = [];
        this.chars = {};
        this.options = new Options();
    }
}
//# sourceMappingURL=npc-model.js.map
import NpcModel from './npc-model.js';
export declare class ActorBuilder {
    static buildActorData(model: NpcModel, type: string): Promise<{
        name: string;
        type: string;
        flags: {
            autoCalcRun: boolean;
            autoCalcWalk: boolean;
            autoCalcWounds: boolean;
            autoCalcCritW: boolean;
            autoCalcCorruption: boolean;
            autoCalcEnc: boolean;
            autoCalcSize: boolean;
        };
        data: {
            characteristics: {
                [char: string]: {
                    initial: number;
                    advances: number;
                };
            };
            details: {
                move: {
                    value: string;
                };
                species: {
                    value: string;
                };
                status: {
                    value: string;
                };
            };
        };
        items: Item.Data<{}>[];
    }>;
    static createActor(model: NpcModel, data: any): Promise<Actor<{}, Item<{}>>>;
    private static addGenerateTokenEffect;
}

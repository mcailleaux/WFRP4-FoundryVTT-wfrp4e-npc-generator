import CreatureAbilities from './util/creature-abilities.js';
import CreatureTemplate from './util/creature-template.js';
import OptionsCreature from './util/options-creature.js';
export default class CreatureModel {
    constructor() {
        this.chars = {};
        this.creatureTemplate = new CreatureTemplate();
        this.abilities = new CreatureAbilities();
        this.trappings = [];
        this.spells = [];
        this.prayers = [];
        this.physicalMutations = [];
        this.mentalMutations = [];
        this.options = new OptionsCreature();
    }
}
//# sourceMappingURL=creature-model.js.map
import CreatureAbilities from './util/creature-abilities.js';
import CreatureTemplate from './util/creature-template.js';
import OptionsCreature from './util/options-creature.js';
import { ItemData } from '@league-of-foundry-developers/foundry-vtt-types/src/foundry/common/data/data.mjs';
export default class CreatureModel {
    name: string;
    chars: {
        [char: string]: {
            initial: number;
            advances: number;
        };
    };
    move: string;
    creatureTemplate: CreatureTemplate;
    abilities: CreatureAbilities;
    trappings: ItemData[];
    spells: ItemData[];
    prayers: ItemData[];
    physicalMutations: ItemData[];
    mentalMutations: ItemData[];
    others: ItemData[];
    options: OptionsCreature;
}

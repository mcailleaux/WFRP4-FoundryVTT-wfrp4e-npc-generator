import CreatureModel from './creature-model.js';
export default class CreatureBuilder {
    static buildCreatureData(model: CreatureModel): Promise<any>;
    static createCreature(model: CreatureModel, data: any): Promise<Actor>;
    private static addGenerateTokenEffect;
}

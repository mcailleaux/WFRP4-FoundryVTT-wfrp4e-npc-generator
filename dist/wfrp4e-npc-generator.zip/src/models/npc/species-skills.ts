export class SpeciesSkills {
  public majors: string[] = [];
  public minors: string[] = [];
}

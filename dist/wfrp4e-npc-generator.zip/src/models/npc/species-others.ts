export class SpeciesOthers {
  public others: string[] = [];
  public randomTalents: string[] = [];
  public originKey: string;
  public origin: string[] = [];
}

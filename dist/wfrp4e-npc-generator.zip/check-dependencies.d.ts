export default class CheckDependencies {
    static check(callback: (canRun: boolean) => void): void;
}

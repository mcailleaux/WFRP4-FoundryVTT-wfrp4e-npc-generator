import Options from './util/options.js';
import { ItemData } from '@league-of-foundry-developers/foundry-vtt-types/src/foundry/common/data/data.mjs';
export default class NpcModel {
    speciesKey: string;
    subSpeciesKey: string;
    speciesValue: string;
    cityBorn: string;
    selectedCareers: Item[];
    career: ItemData;
    status: string;
    careerPath: ItemData[];
    careerForSkills: ItemData[];
    speciesSkills: {
        major: string[];
        minor: string[];
    };
    speciesTalents: string[];
    speciesTraits: string[];
    name: string;
    skills: ItemData[];
    talents: ItemData[];
    traits: ItemData[];
    trappingsStr: string[];
    trappings: ItemData[];
    spells: ItemData[];
    prayers: ItemData[];
    physicalMutations: ItemData[];
    mentalMutations: ItemData[];
    chars: {
        [char: string]: {
            initial: number;
            advances: number;
        };
    };
    move: string;
    actor: Actor;
    options: Options;
}

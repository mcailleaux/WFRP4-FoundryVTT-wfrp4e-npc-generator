import Options from './util/options.js';
export default class NpcModel {
    speciesKey: string;
    subSpeciesKey: string;
    speciesValue: string;
    cityBorn: string;
    selectedCareers: Item[];
    career: Item.Data;
    status: string;
    careerPath: Item.Data[];
    careerForSkills: Item.Data[];
    speciesSkills: {
        major: string[];
        minor: string[];
    };
    speciesTalents: string[];
    speciesTraits: string[];
    name: string;
    skills: Item.Data[];
    talents: Item.Data[];
    traits: Item.Data[];
    trappingsStr: string[];
    trappings: Item.Data[];
    spells: Item.Data[];
    prayers: Item.Data[];
    physicalMutations: Item.Data[];
    mentalMutations: Item.Data[];
    chars: {
        [char: string]: {
            initial: number;
            advances: number;
        };
    };
    move: string;
    actor: Actor;
    options: Options;
}

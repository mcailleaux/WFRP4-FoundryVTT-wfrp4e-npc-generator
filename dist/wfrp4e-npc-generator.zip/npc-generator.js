var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import SpeciesChooser from './util/species-chooser.js';
import NpcModel from './npc-model.js';
import CheckDependencies from './check-dependencies.js';
import CareerChooser from './util/career-chooser.js';
import SpeciesSkillsChooser from './util/species-skills-chooser.js';
import SpeciesTalentsChooser from './util/species-talents-chooser.js';
import NameChooser from './util/name-chooser.js';
import RandomUtil from './util/random-util.js';
import { ActorBuilder } from './actor-builder.js';
import StringUtil from './util/string-util.js';
import TranslateErrorDetect from './util/translate-error-detect.js';
import ReferentialUtil from './util/referential-util.js';
import TrappingUtil from './util/trapping-util.js';
import OptionsChooser from './util/options.chooser.js';
import CompendiumUtil from './util/compendium-util.js';
export default class NpcGenerator {
    static generateNpc(callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield CompendiumUtil.initCompendium();
            yield this.generateNpcModel((model) => __awaiter(this, void 0, void 0, function* () {
                const actorData = yield ActorBuilder.buildActorData(model, 'npc');
                const actor = yield ActorBuilder.createActor(model, actorData);
                ui.notifications.info(game.i18n.format('WFRP4NPCGEN.notification.actor.created', {
                    name: actor.name,
                }));
                if (callback != null) {
                    callback(model, actorData, actor);
                }
            }));
        });
    }
    static generateNpcModel(callback) {
        return __awaiter(this, void 0, void 0, function* () {
            const npcModel = new NpcModel();
            CheckDependencies.check((canRun) => {
                if (canRun) {
                    this.selectSpecies(npcModel, callback);
                }
            });
        });
    }
    static selectSpecies(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.speciesChooser.selectSpecies(model.speciesKey, (key, value) => {
                model.speciesKey = key;
                model.speciesValue = value;
                this.selectCareer(model, callback);
            });
        });
    }
    static selectCareer(model, callback) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            yield this.careerChooser.selectCareer((_a = model.selectedCareer) === null || _a === void 0 ? void 0 : _a.name, model.speciesKey, (career) => {
                model.selectedCareer = career;
                this.selectSpeciesSkills(model, callback);
            }, () => {
                this.selectSpecies(model, callback);
            });
        });
    }
    static selectSpeciesSkills(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.speciesSkillsChooser.selectSpeciesSkills(model.speciesSkills.major, model.speciesSkills.minor, model.speciesKey, (major, minor) => {
                model.speciesSkills.major = major;
                model.speciesSkills.minor = minor;
                this.selectSpeciesTalents(model, callback);
            }, () => {
                this.selectCareer(model, callback);
            });
        });
    }
    static selectSpeciesTalents(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.speciesTalentsChooser.selectSpeciesTalents(model.speciesTalents, model.speciesKey, (talents) => {
                model.speciesTalents = talents;
                this.selectName(model, callback);
            }, () => {
                this.selectSpeciesSkills(model, callback);
            });
        });
    }
    static selectName(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            if (model.name == null) {
                model.name = `${model.selectedCareer.name} ${model.speciesValue}`;
            }
            yield this.nameChooser.selectName(model.name, model.speciesKey, (name) => {
                model.name = name;
                this.selectOptions(model, callback);
            }, () => {
                this.selectSpeciesTalents(model, callback);
            });
        });
    }
    static selectOptions(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.optionsChooser.selectOptions(model.options, (options) => {
                model.options = options;
                this.finalize(model, callback);
            }, () => {
                this.selectName(model, callback);
            });
        });
    }
    static finalize(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.addCareerPath(model);
            yield this.addStatus(model);
            yield this.addBasicSkill(model);
            yield this.addNativeTongueSkill(model);
            yield this.addCareerSkill(model);
            yield this.addSpeciesSkill(model);
            yield this.addSpeciesTalents(model);
            yield this.addCareerTalents(model);
            yield this.addBasicChars(model);
            yield this.addMovement(model);
            yield this.addAdvanceSkills(model);
            yield this.addAdvanceChars(model);
            if (model.options.withClassTrappings) {
                yield this.prepareClassTrappings(model);
            }
            if (model.options.withCareerTrappings) {
                yield this.prepareCareerTrappings(model);
            }
            if (model.trappingsStr.length > 0) {
                yield this.addTrappings(model);
            }
            callback(model);
        });
    }
    static addCareerPath(model) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const careers = yield this.referential.getCareerEntities();
            let career;
            if (model.selectedCareer.data != null) {
                career = model.selectedCareer.data;
            }
            else {
                career = (_a = (careers.find((c) => c.id === model.selectedCareer._id))) === null || _a === void 0 ? void 0 : _a.data;
            }
            model.career = career;
            const careerData = career === null || career === void 0 ? void 0 : career.data;
            if (((_b = careerData === null || careerData === void 0 ? void 0 : careerData.careergroup) === null || _b === void 0 ? void 0 : _b.value) != null) {
                model.careerPath = careers
                    .map((c) => c.data)
                    .filter((c) => {
                    var _a, _b, _c, _d;
                    const data = c === null || c === void 0 ? void 0 : c.data;
                    const levelStr = (_a = data === null || data === void 0 ? void 0 : data.level) === null || _a === void 0 ? void 0 : _a.value;
                    const selectLevelStr = (_b = careerData === null || careerData === void 0 ? void 0 : careerData.level) === null || _b === void 0 ? void 0 : _b.value;
                    const level = levelStr != null ? Number(levelStr) : 0;
                    const selectLevel = selectLevelStr != null ? Number(selectLevelStr) : 0;
                    return (((_c = data === null || data === void 0 ? void 0 : data.careergroup) === null || _c === void 0 ? void 0 : _c.value) === ((_d = careerData === null || careerData === void 0 ? void 0 : careerData.careergroup) === null || _d === void 0 ? void 0 : _d.value) &&
                        level <= selectLevel);
                })
                    .sort((a, b) => {
                    var _a, _b;
                    const aData = a === null || a === void 0 ? void 0 : a.data;
                    const bData = b === null || b === void 0 ? void 0 : b.data;
                    const aLevelStr = (_a = aData === null || aData === void 0 ? void 0 : aData.level) === null || _a === void 0 ? void 0 : _a.value;
                    const bLevelStr = (_b = bData === null || bData === void 0 ? void 0 : bData.level) === null || _b === void 0 ? void 0 : _b.value;
                    const aLevel = aLevelStr != null ? Number(aLevelStr) : 0;
                    const bLevel = bLevelStr != null ? Number(bLevelStr) : 0;
                    return aLevel - bLevel;
                });
            }
            else {
                model.careerPath = [career];
            }
            model.careerPath.forEach((c, i) => {
                const data = c === null || c === void 0 ? void 0 : c.data;
                if ((data === null || data === void 0 ? void 0 : data.current) != null) {
                    data.current.value = i === model.careerPath.length - 1;
                }
                if ((data === null || data === void 0 ? void 0 : data.complete) != null) {
                    data.complete.value = true;
                }
            });
        });
    }
    static addStatus(model) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const careerData = (_a = model.career) === null || _a === void 0 ? void 0 : _a.data;
            if ((careerData === null || careerData === void 0 ? void 0 : careerData.status) != null) {
                const statusTiers = this.referential.getStatusTiers();
                const standing = careerData.status.standing;
                const tier = statusTiers[careerData.status.tier];
                model.status = `${tier} ${standing}`;
            }
        });
    }
    static addBasicSkill(model) {
        return __awaiter(this, void 0, void 0, function* () {
            model.skills = yield this.referential.getAllBasicSkills();
        });
    }
    static addCareerSkill(model) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const careerData = (_a = model.career) === null || _a === void 0 ? void 0 : _a.data;
            const careerSkills = careerData === null || careerData === void 0 ? void 0 : careerData.skills;
            yield this.addSkills(model, careerSkills);
        });
    }
    static addSpeciesSkill(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const speciesSkill = model.speciesSkills.major.concat(model.speciesSkills.minor);
            yield this.addSkills(model, speciesSkill);
        });
    }
    static addNativeTongueSkill(model) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.addSkill(model, game.i18n.localize(`WFRP4NPCGEN.native.tongue.${model.speciesKey}`));
        });
    }
    static addSkills(model, names) {
        return __awaiter(this, void 0, void 0, function* () {
            if (names == null || names.length === 0) {
                return;
            }
            for (let name of names) {
                yield this.addSkill(model, name);
            }
        });
    }
    static addSkill(model, name) {
        return __awaiter(this, void 0, void 0, function* () {
            if (name == null || name.length === 0) {
                return;
            }
            if (!StringUtil.arrayIncludesDeburrIgnoreCase(model.skills.map((ms) => ms.name), name) ||
                (name.includes('(') &&
                    StringUtil.includesDeburrIgnoreCase(name, game.i18n.localize('WFRP4NPCGEN.item.any')))) {
                try {
                    const skillToAdd = yield this.referential.findSkill(name);
                    model.skills.push(skillToAdd.data);
                }
                catch (e) {
                    console.warn('Cant find Skill : ' + name);
                }
            }
        });
    }
    static addCareerTalents(model) {
        return __awaiter(this, void 0, void 0, function* () {
            for (let career of model.careerPath) {
                const data = career === null || career === void 0 ? void 0 : career.data;
                yield this.addTalents(model, data === null || data === void 0 ? void 0 : data.talents);
            }
        });
    }
    static addSpeciesTalents(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const speciesTalentsMap = this.referential.getSpeciesTalentsMap();
            const speciesTalent = speciesTalentsMap[model.speciesKey].filter((talent, index) => index !== speciesTalentsMap[model.speciesKey].length - 1 &&
                !talent.includes(','));
            yield this.addTalents(model, speciesTalent);
            yield this.addTalents(model, model.speciesTalents);
        });
    }
    static addTalents(model, names) {
        return __awaiter(this, void 0, void 0, function* () {
            if (names == null || names.length === 0) {
                return;
            }
            for (let name of names) {
                yield this.addTalent(model, name);
            }
        });
    }
    static addTalent(model, name) {
        return __awaiter(this, void 0, void 0, function* () {
            if (name == null || name.length === 0) {
                return;
            }
            if (!StringUtil.arrayIncludesDeburrIgnoreCase(model.talents.map((ms) => ms.name), name)) {
                try {
                    const talentToAdd = yield this.referential.findTalent(name);
                    model.talents.push(talentToAdd.data);
                }
                catch (e) {
                    console.warn('Cant find Talent : ' + name);
                }
            }
        });
    }
    static addBasicChars(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const averageChars = yield this.referential.getSpeciesCharacteristics(model.speciesKey);
            Object.entries(averageChars).forEach(([key, char]) => {
                const positive = RandomUtil.getRandomBoolean();
                const amplitude = RandomUtil.getRandomPositiveNumber(6);
                const adjust = (positive ? 1 : -1) * RandomUtil.getRandomPositiveNumber(amplitude);
                model.chars[key] = {
                    initial: char.value + adjust,
                    advances: 0,
                };
            });
        });
    }
    static addMovement(model) {
        return __awaiter(this, void 0, void 0, function* () {
            model.move = yield this.referential.getSpeciesMovement(model.speciesKey);
        });
    }
    static addAdvanceSkills(model) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const data = (_a = model.career) === null || _a === void 0 ? void 0 : _a.data;
            (_b = data === null || data === void 0 ? void 0 : data.skills) === null || _b === void 0 ? void 0 : _b.forEach((skill) => {
                const sk = model.skills.find((s) => s.name === skill && s.data.advances.value === 0);
                if (sk != null) {
                    sk.data.advances.value += model.careerPath.length * 5;
                }
            });
            model.speciesSkills.major.forEach((skill) => {
                const sk = model.skills.find((s) => s.name === skill);
                if (sk != null && sk.data.advances.value === 0) {
                    sk.data.advances.value += 5;
                }
            });
            model.speciesSkills.minor.forEach((skill) => {
                const sk = model.skills.find((s) => s.name === skill);
                if (sk != null && sk.data.advances.value === 0) {
                    sk.data.advances.value += 3;
                }
            });
        });
    }
    static addAdvanceChars(model) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const data = (_a = model.career) === null || _a === void 0 ? void 0 : _a.data;
            (_b = data === null || data === void 0 ? void 0 : data.characteristics) === null || _b === void 0 ? void 0 : _b.forEach((char) => {
                const ch = model.chars[char];
                if (ch != null) {
                    ch.advances += model.careerPath.length * 5;
                }
            });
        });
    }
    static prepareClassTrappings(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const careerClasses = [];
            model.careerPath.forEach((cp) => {
                const careerClass = ReferentialUtil.getClassKeyFromCareer(cp);
                if (careerClass != null && !careerClasses.includes(careerClass)) {
                    careerClasses.push(careerClass);
                }
            });
            const classTrappings = ReferentialUtil.getClassTrappings();
            careerClasses.forEach((cc) => {
                const tps = classTrappings[cc];
                if (tps != null) {
                    tps
                        .split(',')
                        .map((t) => t.toLowerCase().trim())
                        .forEach((t) => {
                        if (!model.trappingsStr.includes(t)) {
                            model.trappingsStr.push(t);
                        }
                    });
                }
            });
        });
    }
    static prepareCareerTrappings(model) {
        return __awaiter(this, void 0, void 0, function* () {
            for (let cp of model.careerPath) {
                for (let tr of cp.data.trappings.map((t) => t.toLowerCase().trim())) {
                    if (!model.trappingsStr.includes(tr)) {
                        model.trappingsStr.push(tr);
                    }
                }
            }
        });
    }
    static addTrappings(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const trappingCompendiums = yield ReferentialUtil.getTrappingEntities(true);
            const trappingIds = [];
            for (let tr of model.trappingsStr) {
                const trappings = yield ReferentialUtil.findTrappings(tr, trappingCompendiums);
                for (let trapping of trappings) {
                    if (trapping != null &&
                        !trappingIds.includes(trapping._id) &&
                        trapping.type !== 'money') {
                        trappingIds.push(trapping._id);
                        model.trappings.push(trapping);
                    }
                }
            }
        });
    }
}
NpcGenerator.speciesChooser = SpeciesChooser;
NpcGenerator.careerChooser = CareerChooser;
NpcGenerator.speciesSkillsChooser = SpeciesSkillsChooser;
NpcGenerator.speciesTalentsChooser = SpeciesTalentsChooser;
NpcGenerator.nameChooser = NameChooser;
NpcGenerator.optionsChooser = OptionsChooser;
NpcGenerator.actorBuilder = ActorBuilder;
NpcGenerator.referential = ReferentialUtil;
NpcGenerator.trapping = TrappingUtil;
NpcGenerator.translateErrorDetect = TranslateErrorDetect;
//# sourceMappingURL=npc-generator.js.map
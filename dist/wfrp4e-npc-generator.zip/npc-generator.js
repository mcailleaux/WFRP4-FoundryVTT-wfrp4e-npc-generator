var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import SpeciesChooser from './util/species-chooser.js';
import NpcModel from './npc-model.js';
import CheckDependencies from './check-dependencies.js';
import CareerChooser from './util/career-chooser.js';
import SpeciesSkillsChooser from './util/species-skills-chooser.js';
import SpeciesTalentsChooser from './util/species-talents-chooser.js';
import NameChooser from './util/name-chooser.js';
import RandomUtil from './util/random-util.js';
import { ActorBuilder } from './actor-builder.js';
import StringUtil from './util/string-util.js';
import ReferentialUtil from './util/referential-util.js';
import TrappingUtil from './util/trapping-util.js';
import OptionsChooser from './util/options.chooser.js';
import CompendiumUtil from './util/compendium-util.js';
import TrappingChooser from './util/trapping-chooser.js';
import WaiterUtil from './util/waiter-util.js';
import MagicsChooser from './util/magics-chooser.js';
import MutationsChooser from './util/mutations-chooser.js';
import NpcAbilitiesChooser from './util/npc-abilities-chooser.js';
import { i18n, notifications } from './constant.js';
export default class NpcGenerator {
    static generateNpc(callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.referential.initReferential(() => __awaiter(this, void 0, void 0, function* () {
                yield this.generateNpcModel((model) => __awaiter(this, void 0, void 0, function* () {
                    const actorData = yield ActorBuilder.buildActorData(model, 'npc');
                    const actor = yield ActorBuilder.createActor(model, actorData);
                    notifications().info(i18n().format('WFRP4NPCGEN.notification.actor.created', {
                        name: actor.name,
                    }));
                    yield WaiterUtil.hide();
                    if (callback != null) {
                        callback(model, actorData, actor);
                    }
                }));
            }));
        });
    }
    static generateNpcModel(callback) {
        return __awaiter(this, void 0, void 0, function* () {
            const npcModel = new NpcModel();
            CheckDependencies.check((canRun) => {
                if (canRun) {
                    this.selectSpecies(npcModel, callback);
                }
            });
        });
    }
    static selectSpecies(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.speciesChooser.selectSpecies(model.speciesKey, model.subSpeciesKey, model.cityBorn, (key, value, subKey, cityBorn) => {
                if (model.speciesKey != null && model.speciesKey !== key) {
                    model.speciesSkills = {
                        major: [],
                        minor: [],
                    };
                    model.speciesTalents = [];
                }
                model.speciesKey = key;
                model.speciesValue = value;
                model.subSpeciesKey = subKey;
                model.cityBorn = cityBorn;
                this.selectCareer(model, callback);
            });
        });
    }
    static selectCareer(model, callback) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            yield this.careerChooser.selectCareer((_a = model.selectedCareers) === null || _a === void 0 ? void 0 : _a.map((c) => { var _a; return (_a = c.name) !== null && _a !== void 0 ? _a : ''; }), model.speciesKey, model.subSpeciesKey, (careers) => {
                model.selectedCareers = careers;
                this.selectSpeciesSkills(model, callback);
            }, () => {
                this.selectSpecies(model, callback);
            });
        });
    }
    static selectSpeciesSkills(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.speciesSkillsChooser.selectSpeciesSkills(model.speciesSkills.major, model.speciesSkills.minor, model.speciesKey, model.subSpeciesKey, (major, minor) => {
                model.speciesSkills.major = major;
                model.speciesSkills.minor = minor;
                this.selectSpeciesTalents(model, callback);
            }, () => {
                this.selectCareer(model, callback);
            });
        });
    }
    static selectSpeciesTalents(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.speciesTalentsChooser.selectSpeciesTalents(model.speciesTalents, model.speciesTraits, model.speciesKey, model.subSpeciesKey, (talents, traits) => {
                model.speciesTalents = talents;
                model.speciesTraits = traits;
                this.selectName(model, callback);
            }, () => {
                this.selectSpeciesSkills(model, callback);
            });
        });
    }
    static selectName(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            if (model.name == null) {
                model.name = `${model.selectedCareers[model.selectedCareers.length - 1].name} ${model.speciesValue}`;
            }
            yield this.nameChooser.selectName(model.name, model.speciesKey, true, (name) => {
                model.name = name;
                this.selectOptions(model, callback);
            }, () => {
                this.selectSpeciesTalents(model, callback);
            });
        });
    }
    static selectOptions(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.optionsChooser.selectOptions(false, model.options, model.speciesKey, (options) => {
                model.options = options;
                this.finalize(model, callback);
            }, () => {
                this.selectName(model, callback);
            });
        });
    }
    static finalize(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield WaiterUtil.show('WFRP4NPCGEN.npc.generation.inprogress.title', 'WFRP4NPCGEN.npc.generation.inprogress.hint', () => __awaiter(this, void 0, void 0, function* () {
                console.info('Prepare Career Path');
                yield this.addCareerPath(model);
                console.info('Prepare Status');
                yield this.addStatus(model);
                console.info('Prepare Basic skills');
                yield this.addBasicSkill(model);
                console.info('Prepare Native Tongue');
                yield this.addNativeTongueSkill(model);
                console.info('Prepare City Born');
                yield this.addCityBornSkill(model);
                console.info('Prepare Career Skills');
                yield this.addCareerSkill(model);
                console.info('Prepare Species Skills');
                yield this.addSpeciesSkill(model);
                console.info('Prepare Species Talents');
                yield this.addSpeciesTalents(model);
                console.info('Prepare Career Talents');
                yield this.addCareerTalents(model);
                console.info('Prepare Species Traits');
                yield this.addSpeciesTraits(model);
                console.info('Prepare Basic Chars');
                yield this.addBasicChars(model);
                console.info('Prepare Movement');
                yield this.addMovement(model);
                console.info('Prepare Skills Advances');
                yield this.addAdvanceSkills(model);
                console.info('Prepare Chars Advances');
                yield this.addAdvanceChars(model);
                if (model.options.withClassTrappings) {
                    console.info('Prepare Class Trappings');
                    yield this.prepareClassTrappings(model);
                }
                if (model.options.withCareerTrappings) {
                    console.info('Prepare Career Trappings');
                    yield this.prepareCareerTrappings(model);
                }
                console.info('Prepare Trappings');
                yield this.addTrappings(model);
                yield this.editAbilities(model, callback);
            }));
        });
    }
    static editAbilities(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            if (model.options.editAbilities) {
                yield CompendiumUtil.getCompendiumActors();
                yield WaiterUtil.hide(false);
                yield this.abilitiesChooser.selectNpcAbilities(model.skills, model.talents, model.traits, (skills, talents, traits) => __awaiter(this, void 0, void 0, function* () {
                    model.skills = skills;
                    model.talents = talents;
                    model.traits = traits;
                    yield this.editTrappings(model, callback);
                }));
            }
            else {
                yield this.editTrappings(model, callback);
            }
        });
    }
    static editTrappings(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            if (model.options.editTrappings) {
                const undo = model.options.editAbilities
                    ? () => {
                        this.editAbilities(model, callback);
                    }
                    : undefined;
                yield WaiterUtil.hide(false);
                yield this.trappingChooser.selectTrappings(model.trappings, (trappings) => __awaiter(this, void 0, void 0, function* () {
                    model.trappings = trappings;
                    yield this.editMagics(model, callback);
                }), undo);
            }
            else {
                yield this.editMagics(model, callback);
            }
        });
    }
    static editMagics(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            if (model.options.addMagics) {
                const undo = model.options.editTrappings
                    ? () => {
                        this.editTrappings(model, callback);
                    }
                    : undefined;
                yield WaiterUtil.hide(false);
                yield this.magicsChooser.selectMagics(model.spells, model.prayers, (spells, prayers) => __awaiter(this, void 0, void 0, function* () {
                    model.spells = spells;
                    model.prayers = prayers;
                    yield this.editMutations(model, callback);
                }), undo);
            }
            else {
                yield this.editMutations(model, callback);
            }
        });
    }
    static editMutations(model, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            if (model.options.addMutations) {
                const undo = model.options.addMagics
                    ? () => {
                        this.editMagics(model, callback);
                    }
                    : model.options.editTrappings
                        ? () => {
                            this.editTrappings(model, callback);
                        }
                        : undefined;
                yield WaiterUtil.hide(false);
                yield this.mutationsChooser.selectMutations(model.physicalMutations, model.mentalMutations, (physicals, mentals) => __awaiter(this, void 0, void 0, function* () {
                    yield WaiterUtil.show('WFRP4NPCGEN.npc.generation.inprogress.title', 'WFRP4NPCGEN.npc.generation.inprogress.hint', () => __awaiter(this, void 0, void 0, function* () {
                        model.physicalMutations = physicals;
                        model.mentalMutations = mentals;
                        callback(model);
                    }));
                }), undo);
            }
            else {
                yield WaiterUtil.show('WFRP4NPCGEN.npc.generation.inprogress.title', 'WFRP4NPCGEN.npc.generation.inprogress.hint', () => __awaiter(this, void 0, void 0, function* () {
                    callback(model);
                }));
            }
        });
    }
    static addCareerPath(model) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j;
        return __awaiter(this, void 0, void 0, function* () {
            const careers = yield this.referential.getCareerEntities();
            let career;
            const lastCareer = model.selectedCareers[model.selectedCareers.length - 1];
            if ((lastCareer === null || lastCareer === void 0 ? void 0 : lastCareer.data) != null) {
                career = lastCareer.data;
            }
            else {
                career = (_a = careers.find((c) => c.id === (lastCareer === null || lastCareer === void 0 ? void 0 : lastCareer.id))) === null || _a === void 0 ? void 0 : _a.data;
            }
            model.career = career;
            const careerData = career === null || career === void 0 ? void 0 : career.data;
            if (model.selectedCareers.length > 1) {
                model.careerPath = [];
                for (let customCareerPath of model.selectedCareers) {
                    if ((customCareerPath === null || customCareerPath === void 0 ? void 0 : customCareerPath.data) != null) {
                        model.careerPath.push(customCareerPath === null || customCareerPath === void 0 ? void 0 : customCareerPath.data);
                    }
                    else {
                        model.careerPath.push((_b = careers.find((c) => c.id === (customCareerPath === null || customCareerPath === void 0 ? void 0 : customCareerPath.id))) === null || _b === void 0 ? void 0 : _b.data);
                    }
                }
            }
            else if (((_c = careerData === null || careerData === void 0 ? void 0 : careerData.careergroup) === null || _c === void 0 ? void 0 : _c.value) != null) {
                model.careerPath = careers
                    .map((c) => c.data)
                    .filter((c) => {
                    var _a, _b, _c, _d;
                    const data = c === null || c === void 0 ? void 0 : c.data;
                    const levelStr = (_a = data === null || data === void 0 ? void 0 : data.level) === null || _a === void 0 ? void 0 : _a.value;
                    const selectLevelStr = (_b = careerData === null || careerData === void 0 ? void 0 : careerData.level) === null || _b === void 0 ? void 0 : _b.value;
                    const level = levelStr != null ? Number(levelStr) : 0;
                    const selectLevel = selectLevelStr != null ? Number(selectLevelStr) : 0;
                    return (((_c = data === null || data === void 0 ? void 0 : data.careergroup) === null || _c === void 0 ? void 0 : _c.value) === ((_d = careerData === null || careerData === void 0 ? void 0 : careerData.careergroup) === null || _d === void 0 ? void 0 : _d.value) &&
                        level <= selectLevel);
                })
                    .sort((a, b) => {
                    var _a, _b;
                    const aData = a === null || a === void 0 ? void 0 : a.data;
                    const bData = b === null || b === void 0 ? void 0 : b.data;
                    const aLevelStr = (_a = aData === null || aData === void 0 ? void 0 : aData.level) === null || _a === void 0 ? void 0 : _a.value;
                    const bLevelStr = (_b = bData === null || bData === void 0 ? void 0 : bData.level) === null || _b === void 0 ? void 0 : _b.value;
                    const aLevel = aLevelStr != null ? Number(aLevelStr) : 0;
                    const bLevel = bLevelStr != null ? Number(bLevelStr) : 0;
                    return aLevel - bLevel;
                });
            }
            else {
                model.careerPath = [career];
            }
            model.careerPath.forEach((c, i) => {
                const data = c === null || c === void 0 ? void 0 : c.data;
                if ((data === null || data === void 0 ? void 0 : data.current) != null) {
                    data.current.value = i === model.careerPath.length - 1;
                }
                if ((data === null || data === void 0 ? void 0 : data.complete) != null) {
                    data.complete.value = true;
                }
            });
            const careerSkillsMap = {};
            for (let career of model.careerPath) {
                const data = career.data;
                const level = (_e = (_d = data === null || data === void 0 ? void 0 : data.level) === null || _d === void 0 ? void 0 : _d.value) !== null && _e !== void 0 ? _e : 0;
                const group = (_g = (_f = data === null || data === void 0 ? void 0 : data.careergroup) === null || _f === void 0 ? void 0 : _f.value) !== null && _g !== void 0 ? _g : '';
                const careerSkill = careerSkillsMap[group];
                if (careerSkill == null) {
                    careerSkillsMap[group] = career;
                }
                else {
                    const csData = careerSkill.data;
                    const csLevel = (_j = (_h = csData === null || csData === void 0 ? void 0 : csData.level) === null || _h === void 0 ? void 0 : _h.value) !== null && _j !== void 0 ? _j : 0;
                    if (level > csLevel) {
                        careerSkillsMap[group] = career;
                    }
                }
            }
            model.careerForSkills.push(...Object.values(careerSkillsMap));
        });
    }
    static addStatus(model) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const careerData = (_a = model.career) === null || _a === void 0 ? void 0 : _a.data;
            if ((careerData === null || careerData === void 0 ? void 0 : careerData.status) != null) {
                const statusTiers = this.referential.getStatusTiers();
                const standing = careerData.status.standing;
                const tier = statusTiers[careerData.status.tier];
                model.status = `${tier} ${standing}`;
            }
        });
    }
    static addBasicSkill(model) {
        return __awaiter(this, void 0, void 0, function* () {
            model.skills = yield this.referential.getAllBasicSkills();
        });
    }
    static addCareerSkill(model) {
        return __awaiter(this, void 0, void 0, function* () {
            for (let career of model.careerForSkills) {
                const data = career === null || career === void 0 ? void 0 : career.data;
                yield this.addSkills(model, data === null || data === void 0 ? void 0 : data.skills);
            }
        });
    }
    static addSpeciesSkill(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const speciesSkill = model.speciesSkills.major.concat(model.speciesSkills.minor);
            yield this.addSkills(model, speciesSkill);
        });
    }
    static addNativeTongueSkill(model) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.addSkill(model, i18n().localize(`WFRP4NPCGEN.native.tongue.${model.speciesKey}`));
        });
    }
    static addCityBornSkill(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const loreSkill = yield ReferentialUtil.findSkill('Lore');
            if (model.cityBorn != null &&
                model.cityBorn.length > 0 &&
                loreSkill != null) {
                yield this.addSkill(model, `${StringUtil.getSimpleName(loreSkill.name)} (${model.cityBorn})`);
            }
        });
    }
    static addSkills(model, names) {
        return __awaiter(this, void 0, void 0, function* () {
            if (names == null || names.length === 0) {
                return;
            }
            for (let name of names) {
                yield this.addSkill(model, name);
            }
        });
    }
    static addSkill(model, name) {
        return __awaiter(this, void 0, void 0, function* () {
            if (name == null || name.length === 0) {
                return;
            }
            try {
                const skillToAdd = yield this.referential.findSkill(name);
                if (!StringUtil.arrayIncludesDeburrIgnoreCase(model.skills.map((ms) => ms.name), skillToAdd.name) ||
                    (skillToAdd.name.includes('(') &&
                        StringUtil.includesDeburrIgnoreCase(skillToAdd.name, i18n().localize('WFRP4NPCGEN.item.any')))) {
                    model.skills.push(skillToAdd);
                }
            }
            catch (e) {
                console.warn('Cant find Skill : ' + name);
            }
        });
    }
    static addCareerTalents(model) {
        return __awaiter(this, void 0, void 0, function* () {
            for (let career of model.careerPath) {
                const data = career === null || career === void 0 ? void 0 : career.data;
                yield this.addTalents(model, data === null || data === void 0 ? void 0 : data.talents);
            }
        });
    }
    static addSpeciesTalents(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const traitPrefix = i18n().localize('Trait');
            const speciesTalentsMap = this.referential.getOldSpeciesTalentsMap();
            const speciesTalent = speciesTalentsMap[model.speciesKey].filter((talent, index) => index !== speciesTalentsMap[model.speciesKey].length - 1 &&
                !(talent.startsWith(traitPrefix) && talent.includes('-')) &&
                !talent.includes(','));
            yield this.addTalents(model, speciesTalent);
            yield this.addTalents(model, model.speciesTalents);
        });
    }
    static addTalents(model, names) {
        return __awaiter(this, void 0, void 0, function* () {
            if (names == null || names.length === 0) {
                return;
            }
            for (let name of names) {
                yield this.addTalent(model, name);
            }
        });
    }
    static addTalent(model, name) {
        return __awaiter(this, void 0, void 0, function* () {
            if (name == null || name.length === 0) {
                return;
            }
            try {
                const talentToAdd = yield this.referential.findTalent(name);
                if (!StringUtil.arrayIncludesDeburrIgnoreCase(model.talents.map((ms) => ms.name), talentToAdd.name)) {
                    model.talents.push(talentToAdd);
                }
            }
            catch (e) {
                console.warn('Cant find Talent : ' + name);
            }
        });
    }
    static addSpeciesTraits(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const traitPrefix = i18n().localize('Trait');
            const speciesTalentsMap = this.referential.getOldSpeciesTalentsMap();
            const speciesTraits = speciesTalentsMap[model.speciesKey]
                .filter((talent, index) => index !== speciesTalentsMap[model.speciesKey].length - 1 &&
                talent.startsWith(traitPrefix) &&
                talent.includes('-') &&
                !talent.includes(','))
                .map((trait) => trait.substr(trait.indexOf('-') + 1).trim());
            yield this.addTraits(model, speciesTraits);
            yield this.addTraits(model, model.speciesTraits.map((trait) => trait.substr(trait.indexOf('-') + 1).trim()));
        });
    }
    static addTraits(model, names) {
        return __awaiter(this, void 0, void 0, function* () {
            if (names == null || names.length === 0) {
                return;
            }
            for (let name of names) {
                yield this.addTrait(model, name);
            }
        });
    }
    static addTrait(model, name) {
        return __awaiter(this, void 0, void 0, function* () {
            if (name == null || name.length === 0) {
                return;
            }
            try {
                const traitToAdd = yield this.referential.findTrait(name);
                if (!StringUtil.arrayIncludesDeburrIgnoreCase(model.traits.map((ms) => ms.name), traitToAdd.name)) {
                    model.traits.push(traitToAdd);
                }
            }
            catch (e) {
                console.warn('Cant find Trait : ' + name);
            }
        });
    }
    static addBasicChars(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const averageChars = yield this.referential.getSpeciesCharacteristics(model.speciesKey);
            Object.entries(averageChars).forEach(([key, char]) => {
                const positive = RandomUtil.getRandomBoolean();
                const amplitude = RandomUtil.getRandomPositiveNumber(6);
                const adjust = (positive ? 1 : -1) * RandomUtil.getRandomPositiveNumber(amplitude);
                model.chars[key] = {
                    initial: char.value + adjust,
                    advances: 0,
                };
            });
        });
    }
    static addMovement(model) {
        return __awaiter(this, void 0, void 0, function* () {
            model.move = yield this.referential.getSpeciesMovement(model.speciesKey);
        });
    }
    static addAdvanceSkills(model) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            if (model.selectedCareers.length === 1) {
                const data = (_a = model.career) === null || _a === void 0 ? void 0 : _a.data;
                (_b = data === null || data === void 0 ? void 0 : data.skills) === null || _b === void 0 ? void 0 : _b.forEach((skill) => {
                    const sk = model.skills.find((s) => s.name === skill && s.data.advances.value === 0);
                    if (sk != null) {
                        sk.data.advances.value += model.careerPath.length * 5;
                    }
                });
            }
            else {
                for (let career of model.careerPath) {
                    const data = career === null || career === void 0 ? void 0 : career.data;
                    const level = Number((_c = data.level) === null || _c === void 0 ? void 0 : _c.value);
                    const maxAdvance = level * 5;
                    for (let skill of data === null || data === void 0 ? void 0 : data.skills) {
                        const sk = model.skills.find((s) => s.name === skill && s.data.advances.value < maxAdvance);
                        if (sk != null) {
                            sk.data.advances.value = maxAdvance;
                        }
                    }
                }
            }
            model.speciesSkills.major.forEach((skill) => {
                const sk = model.skills.find((s) => s.name === skill);
                if (sk != null && sk.data.advances.value === 0) {
                    sk.data.advances.value += 5;
                }
            });
            model.speciesSkills.minor.forEach((skill) => {
                const sk = model.skills.find((s) => s.name === skill);
                if (sk != null && sk.data.advances.value === 0) {
                    sk.data.advances.value += 3;
                }
            });
        });
    }
    static addAdvanceChars(model) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            if (model.selectedCareers.length === 1) {
                const data = (_a = model.career) === null || _a === void 0 ? void 0 : _a.data;
                (_b = data === null || data === void 0 ? void 0 : data.characteristics) === null || _b === void 0 ? void 0 : _b.forEach((char) => {
                    const ch = model.chars[char];
                    if (ch != null) {
                        ch.advances += model.careerPath.length * 5;
                    }
                });
            }
            else {
                for (let career of model.careerPath) {
                    const data = career === null || career === void 0 ? void 0 : career.data;
                    const level = Number((_c = data.level) === null || _c === void 0 ? void 0 : _c.value);
                    const maxAdvance = level * 5;
                    for (let char of data === null || data === void 0 ? void 0 : data.characteristics) {
                        const ch = model.chars[char];
                        if (ch != null && ch.advances < maxAdvance) {
                            ch.advances = maxAdvance;
                        }
                    }
                }
            }
        });
    }
    static prepareClassTrappings(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const careerClasses = [];
            model.careerPath.forEach((cp) => {
                const careerClass = ReferentialUtil.getClassKeyFromCareer(cp);
                if (careerClass != null && !careerClasses.includes(careerClass)) {
                    careerClasses.push(careerClass);
                }
            });
            const classTrappings = ReferentialUtil.getClassTrappings();
            careerClasses.forEach((cc) => {
                const tps = classTrappings[cc];
                if (tps != null) {
                    tps
                        .split(',')
                        .map((t) => t.toLowerCase().trim())
                        .forEach((t) => {
                        if (!model.trappingsStr.includes(t)) {
                            model.trappingsStr.push(t);
                        }
                    });
                }
            });
        });
    }
    static prepareCareerTrappings(model) {
        return __awaiter(this, void 0, void 0, function* () {
            for (let cp of model.careerPath) {
                for (let tr of cp.data.trappings.map((t) => t.toLowerCase().trim())) {
                    if (!model.trappingsStr.includes(tr)) {
                        model.trappingsStr.push(tr);
                    }
                }
            }
        });
    }
    static addTrappings(model) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const trappingCompendiums = yield ReferentialUtil.getTrappingEntities(true);
            const trappingIds = [];
            const moneyItems = yield ReferentialUtil.getAllMoneyItems();
            model.trappings.push(...moneyItems);
            for (let tr of model.trappingsStr) {
                const trappings = yield ReferentialUtil.findTrappings(tr, trappingCompendiums);
                for (let trapping of trappings) {
                    if (trapping != null &&
                        !trappingIds.includes((_a = trapping._id) !== null && _a !== void 0 ? _a : '') &&
                        trapping.type !== 'money') {
                        trappingIds.push((_b = trapping._id) !== null && _b !== void 0 ? _b : '');
                        model.trappings.push(trapping);
                    }
                }
            }
        });
    }
}
NpcGenerator.speciesChooser = SpeciesChooser;
NpcGenerator.careerChooser = CareerChooser;
NpcGenerator.speciesSkillsChooser = SpeciesSkillsChooser;
NpcGenerator.speciesTalentsChooser = SpeciesTalentsChooser;
NpcGenerator.nameChooser = NameChooser;
NpcGenerator.optionsChooser = OptionsChooser;
NpcGenerator.actorBuilder = ActorBuilder;
NpcGenerator.referential = ReferentialUtil;
NpcGenerator.compendium = CompendiumUtil;
NpcGenerator.trapping = TrappingUtil;
NpcGenerator.abilitiesChooser = NpcAbilitiesChooser;
NpcGenerator.trappingChooser = TrappingChooser;
NpcGenerator.magicsChooser = MagicsChooser;
NpcGenerator.mutationsChooser = MutationsChooser;
//# sourceMappingURL=npc-generator.js.map